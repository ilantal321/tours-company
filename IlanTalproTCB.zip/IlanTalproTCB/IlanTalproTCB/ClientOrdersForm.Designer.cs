﻿namespace IlanTalproTCB
{
    partial class ClientOrdersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClientOrdersForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.LDays = new System.Windows.Forms.Label();
            this.LCountry = new System.Windows.Forms.Label();
            this.LTourDate = new System.Windows.Forms.Label();
            this.LFlightNumber = new System.Windows.Forms.Label();
            this.LTotal = new System.Windows.Forms.Label();
            this.LPlaces = new System.Windows.Forms.Label();
            this.LPrice = new System.Windows.Forms.Label();
            this.LWName = new System.Windows.Forms.Label();
            this.LTourName = new System.Windows.Forms.Label();
            this.LRFlight_number = new System.Windows.Forms.Label();
            this.LRPaymentStatus = new System.Windows.Forms.Label();
            this.LPayStatus = new System.Windows.Forms.Label();
            this.CBReceiptList = new System.Windows.Forms.ComboBox();
            this.LRTourName = new System.Windows.Forms.Label();
            this.LRTourDate = new System.Windows.Forms.Label();
            this.LRCountry = new System.Windows.Forms.Label();
            this.LRDays = new System.Windows.Forms.Label();
            this.LRWName = new System.Windows.Forms.Label();
            this.LRPrice = new System.Windows.Forms.Label();
            this.LRPlaces = new System.Windows.Forms.Label();
            this.LRTotal = new System.Windows.Forms.Label();
            this.PBPlus = new System.Windows.Forms.PictureBox();
            this.PBMinus = new System.Windows.Forms.PictureBox();
            this.PBMakePDFOrder = new System.Windows.Forms.PictureBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPlus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMinus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMakePDFOrder)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 7);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(197, 40);
            this.LHeader.TabIndex = 1;
            this.LHeader.Text = "Orders history:";
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 761);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // LDays
            // 
            this.LDays.AutoSize = true;
            this.LDays.BackColor = System.Drawing.Color.Transparent;
            this.LDays.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDays.ForeColor = System.Drawing.Color.Black;
            this.LDays.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LDays.Location = new System.Drawing.Point(14, 188);
            this.LDays.Name = "LDays";
            this.LDays.Size = new System.Drawing.Size(62, 29);
            this.LDays.TabIndex = 56;
            this.LDays.Text = "Days:";
            // 
            // LCountry
            // 
            this.LCountry.AutoSize = true;
            this.LCountry.BackColor = System.Drawing.Color.Transparent;
            this.LCountry.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCountry.ForeColor = System.Drawing.Color.Black;
            this.LCountry.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCountry.Location = new System.Drawing.Point(14, 147);
            this.LCountry.Name = "LCountry";
            this.LCountry.Size = new System.Drawing.Size(86, 29);
            this.LCountry.TabIndex = 54;
            this.LCountry.Text = "Country:";
            // 
            // LTourDate
            // 
            this.LTourDate.AutoSize = true;
            this.LTourDate.BackColor = System.Drawing.Color.Transparent;
            this.LTourDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourDate.ForeColor = System.Drawing.Color.Black;
            this.LTourDate.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourDate.Location = new System.Drawing.Point(14, 106);
            this.LTourDate.Name = "LTourDate";
            this.LTourDate.Size = new System.Drawing.Size(105, 29);
            this.LTourDate.TabIndex = 52;
            this.LTourDate.Text = "Tour Date:";
            // 
            // LFlightNumber
            // 
            this.LFlightNumber.AutoSize = true;
            this.LFlightNumber.BackColor = System.Drawing.Color.Transparent;
            this.LFlightNumber.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFlightNumber.ForeColor = System.Drawing.Color.Black;
            this.LFlightNumber.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFlightNumber.Location = new System.Drawing.Point(14, 230);
            this.LFlightNumber.Name = "LFlightNumber";
            this.LFlightNumber.Size = new System.Drawing.Size(65, 29);
            this.LFlightNumber.TabIndex = 50;
            this.LFlightNumber.Text = "Flight:";
            // 
            // LTotal
            // 
            this.LTotal.AutoSize = true;
            this.LTotal.BackColor = System.Drawing.Color.Transparent;
            this.LTotal.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTotal.ForeColor = System.Drawing.Color.Black;
            this.LTotal.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTotal.Location = new System.Drawing.Point(438, 188);
            this.LTotal.Name = "LTotal";
            this.LTotal.Size = new System.Drawing.Size(61, 29);
            this.LTotal.TabIndex = 48;
            this.LTotal.Text = "Total:";
            // 
            // LPlaces
            // 
            this.LPlaces.AutoSize = true;
            this.LPlaces.BackColor = System.Drawing.Color.Transparent;
            this.LPlaces.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPlaces.ForeColor = System.Drawing.Color.Black;
            this.LPlaces.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPlaces.Location = new System.Drawing.Point(438, 145);
            this.LPlaces.Name = "LPlaces";
            this.LPlaces.Size = new System.Drawing.Size(77, 29);
            this.LPlaces.TabIndex = 46;
            this.LPlaces.Text = "Palces:";
            // 
            // LPrice
            // 
            this.LPrice.AutoSize = true;
            this.LPrice.BackColor = System.Drawing.Color.Transparent;
            this.LPrice.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPrice.ForeColor = System.Drawing.Color.Black;
            this.LPrice.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPrice.Location = new System.Drawing.Point(438, 104);
            this.LPrice.Name = "LPrice";
            this.LPrice.Size = new System.Drawing.Size(63, 29);
            this.LPrice.TabIndex = 44;
            this.LPrice.Text = "Price:";
            // 
            // LWName
            // 
            this.LWName.AutoSize = true;
            this.LWName.BackColor = System.Drawing.Color.Transparent;
            this.LWName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LWName.ForeColor = System.Drawing.Color.Black;
            this.LWName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LWName.Location = new System.Drawing.Point(438, 65);
            this.LWName.Name = "LWName";
            this.LWName.Size = new System.Drawing.Size(140, 29);
            this.LWName.TabIndex = 42;
            this.LWName.Text = "Worker Name:";
            // 
            // LTourName
            // 
            this.LTourName.AutoSize = true;
            this.LTourName.BackColor = System.Drawing.Color.Transparent;
            this.LTourName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourName.ForeColor = System.Drawing.Color.Black;
            this.LTourName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourName.Location = new System.Drawing.Point(14, 65);
            this.LTourName.Name = "LTourName";
            this.LTourName.Size = new System.Drawing.Size(116, 29);
            this.LTourName.TabIndex = 38;
            this.LTourName.Text = "Tour Name:";
            // 
            // LRFlight_number
            // 
            this.LRFlight_number.AutoSize = true;
            this.LRFlight_number.BackColor = System.Drawing.Color.Transparent;
            this.LRFlight_number.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRFlight_number.ForeColor = System.Drawing.Color.Black;
            this.LRFlight_number.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRFlight_number.Location = new System.Drawing.Point(130, 230);
            this.LRFlight_number.Name = "LRFlight_number";
            this.LRFlight_number.Size = new System.Drawing.Size(0, 29);
            this.LRFlight_number.TabIndex = 65;
            // 
            // LRPaymentStatus
            // 
            this.LRPaymentStatus.AutoSize = true;
            this.LRPaymentStatus.BackColor = System.Drawing.Color.Transparent;
            this.LRPaymentStatus.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRPaymentStatus.ForeColor = System.Drawing.Color.Black;
            this.LRPaymentStatus.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRPaymentStatus.Location = new System.Drawing.Point(601, 230);
            this.LRPaymentStatus.Name = "LRPaymentStatus";
            this.LRPaymentStatus.Size = new System.Drawing.Size(0, 29);
            this.LRPaymentStatus.TabIndex = 76;
            // 
            // LPayStatus
            // 
            this.LPayStatus.AutoSize = true;
            this.LPayStatus.BackColor = System.Drawing.Color.Transparent;
            this.LPayStatus.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPayStatus.ForeColor = System.Drawing.Color.Black;
            this.LPayStatus.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPayStatus.Location = new System.Drawing.Point(438, 230);
            this.LPayStatus.Name = "LPayStatus";
            this.LPayStatus.Size = new System.Drawing.Size(94, 29);
            this.LPayStatus.TabIndex = 75;
            this.LPayStatus.Text = "Payment:";
            // 
            // CBReceiptList
            // 
            this.CBReceiptList.FormattingEnabled = true;
            this.CBReceiptList.Location = new System.Drawing.Point(238, 23);
            this.CBReceiptList.Name = "CBReceiptList";
            this.CBReceiptList.Size = new System.Drawing.Size(750, 24);
            this.CBReceiptList.TabIndex = 79;
            this.CBReceiptList.SelectedIndexChanged += new System.EventHandler(this.CBReceiptList_SelectedIndexChanged);
            // 
            // LRTourName
            // 
            this.LRTourName.AutoSize = true;
            this.LRTourName.BackColor = System.Drawing.Color.Transparent;
            this.LRTourName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRTourName.ForeColor = System.Drawing.Color.Black;
            this.LRTourName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRTourName.Location = new System.Drawing.Point(132, 65);
            this.LRTourName.Name = "LRTourName";
            this.LRTourName.Size = new System.Drawing.Size(0, 29);
            this.LRTourName.TabIndex = 80;
            // 
            // LRTourDate
            // 
            this.LRTourDate.AutoSize = true;
            this.LRTourDate.BackColor = System.Drawing.Color.Transparent;
            this.LRTourDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRTourDate.ForeColor = System.Drawing.Color.Black;
            this.LRTourDate.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRTourDate.Location = new System.Drawing.Point(132, 104);
            this.LRTourDate.Name = "LRTourDate";
            this.LRTourDate.Size = new System.Drawing.Size(0, 29);
            this.LRTourDate.TabIndex = 81;
            // 
            // LRCountry
            // 
            this.LRCountry.AutoSize = true;
            this.LRCountry.BackColor = System.Drawing.Color.Transparent;
            this.LRCountry.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRCountry.ForeColor = System.Drawing.Color.Black;
            this.LRCountry.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRCountry.Location = new System.Drawing.Point(132, 147);
            this.LRCountry.Name = "LRCountry";
            this.LRCountry.Size = new System.Drawing.Size(0, 29);
            this.LRCountry.TabIndex = 82;
            // 
            // LRDays
            // 
            this.LRDays.AutoSize = true;
            this.LRDays.BackColor = System.Drawing.Color.Transparent;
            this.LRDays.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRDays.ForeColor = System.Drawing.Color.Black;
            this.LRDays.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRDays.Location = new System.Drawing.Point(130, 188);
            this.LRDays.Name = "LRDays";
            this.LRDays.Size = new System.Drawing.Size(0, 29);
            this.LRDays.TabIndex = 83;
            // 
            // LRWName
            // 
            this.LRWName.AutoSize = true;
            this.LRWName.BackColor = System.Drawing.Color.Transparent;
            this.LRWName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRWName.ForeColor = System.Drawing.Color.Black;
            this.LRWName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRWName.Location = new System.Drawing.Point(601, 65);
            this.LRWName.Name = "LRWName";
            this.LRWName.Size = new System.Drawing.Size(0, 29);
            this.LRWName.TabIndex = 84;
            // 
            // LRPrice
            // 
            this.LRPrice.AutoSize = true;
            this.LRPrice.BackColor = System.Drawing.Color.Transparent;
            this.LRPrice.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRPrice.ForeColor = System.Drawing.Color.Black;
            this.LRPrice.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRPrice.Location = new System.Drawing.Point(601, 104);
            this.LRPrice.Name = "LRPrice";
            this.LRPrice.Size = new System.Drawing.Size(0, 29);
            this.LRPrice.TabIndex = 85;
            // 
            // LRPlaces
            // 
            this.LRPlaces.AutoSize = true;
            this.LRPlaces.BackColor = System.Drawing.Color.Transparent;
            this.LRPlaces.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRPlaces.ForeColor = System.Drawing.Color.Black;
            this.LRPlaces.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRPlaces.Location = new System.Drawing.Point(601, 147);
            this.LRPlaces.Name = "LRPlaces";
            this.LRPlaces.Size = new System.Drawing.Size(0, 29);
            this.LRPlaces.TabIndex = 86;
            // 
            // LRTotal
            // 
            this.LRTotal.AutoSize = true;
            this.LRTotal.BackColor = System.Drawing.Color.Transparent;
            this.LRTotal.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRTotal.ForeColor = System.Drawing.Color.Black;
            this.LRTotal.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRTotal.Location = new System.Drawing.Point(601, 192);
            this.LRTotal.Name = "LRTotal";
            this.LRTotal.Size = new System.Drawing.Size(0, 29);
            this.LRTotal.TabIndex = 87;
            // 
            // PBPlus
            // 
            this.PBPlus.BackColor = System.Drawing.Color.Transparent;
            this.PBPlus.Image = ((System.Drawing.Image)(resources.GetObject("PBPlus.Image")));
            this.PBPlus.Location = new System.Drawing.Point(251, 261);
            this.PBPlus.Name = "PBPlus";
            this.PBPlus.Size = new System.Drawing.Size(59, 62);
            this.PBPlus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBPlus.TabIndex = 89;
            this.PBPlus.TabStop = false;
            this.PBPlus.Click += new System.EventHandler(this.PBPlus_Click);
            this.PBPlus.MouseLeave += new System.EventHandler(this.PBPlus_MouseLeave);
            this.PBPlus.MouseHover += new System.EventHandler(this.PBPlus_MouseHover);
            // 
            // PBMinus
            // 
            this.PBMinus.BackColor = System.Drawing.Color.Transparent;
            this.PBMinus.Image = ((System.Drawing.Image)(resources.GetObject("PBMinus.Image")));
            this.PBMinus.Location = new System.Drawing.Point(158, 261);
            this.PBMinus.Name = "PBMinus";
            this.PBMinus.Size = new System.Drawing.Size(59, 62);
            this.PBMinus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBMinus.TabIndex = 88;
            this.PBMinus.TabStop = false;
            this.PBMinus.Click += new System.EventHandler(this.PBMinus_Click);
            this.PBMinus.MouseLeave += new System.EventHandler(this.PBMinus_MouseLeave);
            this.PBMinus.MouseHover += new System.EventHandler(this.PBMinus_MouseHover);
            // 
            // PBMakePDFOrder
            // 
            this.PBMakePDFOrder.BackColor = System.Drawing.Color.Transparent;
            this.PBMakePDFOrder.Image = ((System.Drawing.Image)(resources.GetObject("PBMakePDFOrder.Image")));
            this.PBMakePDFOrder.Location = new System.Drawing.Point(443, 274);
            this.PBMakePDFOrder.Name = "PBMakePDFOrder";
            this.PBMakePDFOrder.Size = new System.Drawing.Size(100, 80);
            this.PBMakePDFOrder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBMakePDFOrder.TabIndex = 90;
            this.PBMakePDFOrder.TabStop = false;
            this.PBMakePDFOrder.Click += new System.EventHandler(this.PBMakePDFOrder_Click);
            this.PBMakePDFOrder.MouseLeave += new System.EventHandler(this.PBMakePDFOrder_MouseLeave);
            this.PBMakePDFOrder.MouseHover += new System.EventHandler(this.PBMakePDFOrder_MouseHover);
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // ClientOrdersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.PBMakePDFOrder);
            this.Controls.Add(this.PBPlus);
            this.Controls.Add(this.PBMinus);
            this.Controls.Add(this.LRTotal);
            this.Controls.Add(this.LRPlaces);
            this.Controls.Add(this.LRPrice);
            this.Controls.Add(this.LRWName);
            this.Controls.Add(this.LRDays);
            this.Controls.Add(this.LRCountry);
            this.Controls.Add(this.LRTourDate);
            this.Controls.Add(this.LRTourName);
            this.Controls.Add(this.CBReceiptList);
            this.Controls.Add(this.LRPaymentStatus);
            this.Controls.Add(this.LPayStatus);
            this.Controls.Add(this.LRFlight_number);
            this.Controls.Add(this.LDays);
            this.Controls.Add(this.LCountry);
            this.Controls.Add(this.LTourDate);
            this.Controls.Add(this.LFlightNumber);
            this.Controls.Add(this.LTotal);
            this.Controls.Add(this.LPlaces);
            this.Controls.Add(this.LPrice);
            this.Controls.Add(this.LWName);
            this.Controls.Add(this.LTourName);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ClientOrdersForm";
            this.Text = "Client Orders";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPlus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMinus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMakePDFOrder)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.Label LDays;
        private System.Windows.Forms.Label LCountry;
        private System.Windows.Forms.Label LTourDate;
        private System.Windows.Forms.Label LFlightNumber;
        private System.Windows.Forms.Label LTotal;
        private System.Windows.Forms.Label LPlaces;
        private System.Windows.Forms.Label LPrice;
        private System.Windows.Forms.Label LWName;
        private System.Windows.Forms.Label LTourName;
        private System.Windows.Forms.Label LRFlight_number;
        private System.Windows.Forms.Label LRPaymentStatus;
        private System.Windows.Forms.Label LPayStatus;
        private System.Windows.Forms.ComboBox CBReceiptList;
        private System.Windows.Forms.Label LRTourName;
        private System.Windows.Forms.Label LRTourDate;
        private System.Windows.Forms.Label LRCountry;
        private System.Windows.Forms.Label LRDays;
        private System.Windows.Forms.Label LRWName;
        private System.Windows.Forms.Label LRPrice;
        private System.Windows.Forms.Label LRPlaces;
        private System.Windows.Forms.Label LRTotal;
        private System.Windows.Forms.PictureBox PBPlus;
        private System.Windows.Forms.PictureBox PBMinus;
        private System.Windows.Forms.PictureBox PBMakePDFOrder;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}