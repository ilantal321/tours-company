﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
namespace IlanTalproTCB
{
    class Tour
    {
        private int TourID;
        private string Tour_Name;
        private string Flight_number;
        private int Price;
        private string Country;
        private string disdescription;
        private int Days;
        private string Date;
        private int Capacity;
        private string TimeHM;
        private string TimeHMReturn;
        private int Gate;
        private string Flight_number_Return;
        private int Gate_Return;
        /*
        empty constractor
        */
        public Tour()
        {

        }
        /*
        constractor
        */
        public Tour (int TID,string tn,string fn,int Pric,string c,string dis,int daytime,string d, int cap,string t, int g,string tReturn,string FNR,int GR)
        {
            TourID = TID;
            Tour_Name = tn;
            Flight_number = fn;
            Price = Pric;
            Country = c;
            disdescription = dis;
            Days = daytime;
            Date = d;
            Capacity = cap;
            TimeHM = t;
            Gate = g;
            TimeHMReturn = tReturn;
            Flight_number_Return = FNR;
            Gate_Return = GR;
        }
        /*
        add to the database
        */
        public void AddTourToDB()
        {
            OleDbDataReader dr;
            Flight_Ticket FT = new Flight_Ticket();
            Myconn connec = new Myconn();
            int m,i,j=1;
            char c='A';
            Function f1 = new Function();
            dr = connec.SandQuery("INSERT INTO Tours VALUES ( '" + TourID + "', '" + Tour_Name + "', '" + Country + "', '" + Flight_number + "', " + Price + "," + Days + ", " + Capacity + ", '" + Date + "', '" + disdescription + "', '"+TimeHM+"', "+Gate+", '"+TimeHMReturn+"', '"+Flight_number_Return+ "', "+Gate_Return+");");
            dr.Close();
            connec.closeCon();
            //connec = new Myconn();
            m = f1.MakePKID("Flight_Ticket") + 1;
            for (i=0; i< Capacity;i++)
            {
                FT = new Flight_Ticket(m,0, c + j.ToString(),TourID);
                FT.Add_Flight_Ticket_TODB();
                j++;
                m++;
                if (j > 12)
                {
                    c++;
                    j = 1;
                }
            }
        }
        /*
        update cap in the database
        */
        public void UpdateCapacity()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("UPDATE Tours SET Capacity = "+Capacity+ " WHERE PKID = "+TourID+"; ");
            dr.Close();
            connec.closeCon();
        }
        /*
        set and get
        */
        public void SetTourID(int TID)
        {
            TourID = TID;
        }
        public void SetTourName(string tN)
        {
            Tour_Name = tN;
        }
        public void SetFlight_numberID(string FN)
        {
            Flight_number = FN;
        }
        public void SetPrice(int p)
        {
            Price = p;
        }
        public void SetCountry(string c)
        {
            Country = c;
        }
        public void Setdisdescription(string d)
        {
            disdescription = d;
        }
        public void SetDays(int n)
        {
            Days = n;
        }
        public void SetDate(string d)
        {
            Date = d;
        }
        public void SetCapacity(int c)
        {
            Capacity = c;
        }
        public void SetTimeHM(string t)
        {
            TimeHM = t;
        }
        public void SetTimeHMReturn(string t)
        {
            TimeHMReturn = t;
        }
        public void SetFlight_number_Return(string fnr)
        {
            Flight_number_Return = fnr;
        }
        public void SetGate(int g)
        {
            Gate = g;
        }
        public void SetGateReturn(int g)
        {
            Gate_Return = g;
        }
        public int GetTourID()
        {
            return TourID;
        }
        public string GetTourname()
        {
            return Tour_Name;
        }
        public string GetFlight_numberID()
        {
            return Flight_number;
        }
        public int GetPrice()
        {
            return Price;
        }
        public string GetCountry()
        {
            return Country;
        }
        public string GetCountryName()
        {
            Country c = new Country(Country);
            return c.GetCountryName();
        }
        public string Getdisdescription()
        {
            return disdescription;
        }
        public int GetDay()
        {
            return Days;
        }
        public string GetDate()
        {
            return Date;
        }
        public int GetCapacity()
        {
            return Capacity;
        }
        public string GetTimeHM()
        {
            return TimeHM;
        }
        public string GetTimeHMReturn()
        {
            return TimeHMReturn;
        }
        public int GetGate()
        {
            return Gate;
        }
        public string getFlight_number_Return()
        {
            return Flight_number_Return;
        }
        public int GetGateReturn()
        {
            return Gate_Return;
        }
        /*
        print data for other uses
        */
        public string PrintTour()
        {
            string str = "";
            Country c = new Country(Country);
            Continent co=new Continent(c.GetContinentPKID().ToString());
            str = "Tour PKID is: " + TourID.ToString() + "\nTour Name is: " + Tour_Name + " \nFlight number: " + Flight_number + " \nPrice: " + Price.ToString() + "$\nContinent:" +co.GetContinentName() +" \nCountry: " + c.GetCountryName() + " \nDays:" + Days + " \nDate:" + Date.ToString()  +" \nTime:" + TimeHM + "\nGate:" + Gate + "\nReturn Flight number:" + Flight_number_Return + "\nreturn time:" + TimeHMReturn + "\nreturn Gate:" + Gate_Return;
            return str;
        }
        public string PrintTourForClientPDF()
        {
            string str = "";
            Country c = new Country(Country);
            str = "Tour PKID is: " + TourID.ToString() + "\nTour Name is: " + Tour_Name + " \nFlight number: " + Flight_number + " \nPrice for a seat: " + Price.ToString() + "$ \nCountry: " + c.GetCountryName()  + " \nDays:" + Days + " \nDate:" + Date.ToString() + " \nTime:" + TimeHM + "\nGate:" + Gate + "\nReturn Flight number:" + Flight_number_Return + "\nreturn time:" + TimeHMReturn + "\nreturn Gate:" + Gate_Return;
            return str;
        }
        public string PrintTourForticket()
        {
            string str = "";
            Country c = new Country(Country);
            str = "PKID: " + TourID.ToString() + " Name: " + Tour_Name + " Flight number: " + Flight_number + " Country: " + c.GetCountryName() + " Date:" + Date.ToString()+" " + TimeHM + " Gate:" + Gate + " Return Flight number:" + Flight_number_Return + " return time:" + TimeHMReturn + " return Gate:" + Gate_Return;
            return str;
        }
        /*
        get tour taken places
        */
        public int getTourTakenSeats()
        {
            int Count = 0;
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            try
            {
                dr = connec.SandQuery("SELECT sum(Quantity) AS [counter] FROM Orders Where TourPKID = " + TourID + " and  Active=True;");
                while (dr.Read())
                {
                    Count = int.Parse(dr["counter"].ToString());
                }
                dr.Close();
                connec.closeCon();
                return Count;
            }
            catch
            {
                return 0;
            }
        }
        /*
        make PDF file for client
        */
        public void PrintTourDataPDFClient(string fileName, string FileLocation)
        {
            int i;
            Document doc = new Document(iTextSharp.text.PageSize.A4, 10, 10, 42, 35);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(FileLocation + "/" + fileName + ".pdf", FileMode.Create));
            doc.Open();

            iTextSharp.text.Image image = iTextSharp.text.Image.GetInstance("pic/plane.png");
            image.SetAbsolutePosition(doc.LeftMargin, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            image.ScaleAbsolute(40f, 40f);
            doc.Add(image);

            image = iTextSharp.text.Image.GetInstance("pic/IT.png");
            image.ScaleAbsolute(50f, 50f);
            image.SetAbsolutePosition((PageSize.A4.Width - image.ScaledWidth) / 2, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            doc.Add(image);

            Paragraph p = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, BaseColor.BLACK, Element.ALIGN_LEFT, 1)));
            doc.Add(p);

            Paragraph paragraph1 = new Paragraph("Tour Data From \nTour: " +Tour_Name + "\nPrint Time:" + DateTime.Now);
            paragraph1.Alignment = Element.ALIGN_CENTER;
            doc.Add(paragraph1);


            Paragraph paragraph2 = new Paragraph(PrintTour());
            doc.Add(paragraph2);
            paragraph1 = new Paragraph(disdescription+"\n\n\n");
            paragraph1.Alignment = Element.ALIGN_CENTER;
            doc.Add(paragraph1);
            PdfPTable table = new PdfPTable(3);
            table.DefaultCell.Border = Rectangle.NO_BORDER;
            PdfPCell cell = new PdfPCell();
            cell.Colspan = 3;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            PicsTourList ptl = new PicsTourList(TourID.ToString());
            int counter = ptl.GetTourPicList().Count;
            for (i = 0; i < counter; i++)
            {
                image = iTextSharp.text.Image.GetInstance(@"pic/Tours/" + ptl.GetTourPicList()[i].GetPicName());
                table.AddCell(image);
            }
            table.CompleteRow();
            doc.Add(table);
            doc.Close();
        }
        /*
        make PDF file for worker and manager
        */
        public void PrintTourDataPDF(string fileName, string ChartLocation, string FileLocation)
        {
            Document doc = new Document(iTextSharp.text.PageSize.A4, 10, 10, 42, 35);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(FileLocation + "/" + fileName + ".pdf", FileMode.Create));
            int i,sum=0;
            doc.Open();

            iTextSharp.text.Image image = iTextSharp.text.Image.GetInstance("pic/plane.png");
            image.SetAbsolutePosition(doc.LeftMargin, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            image.ScaleAbsolute(40f, 40f);
            doc.Add(image);

            image = iTextSharp.text.Image.GetInstance("pic/IT.png");
            image.ScaleAbsolute(50f, 50f);
            image.SetAbsolutePosition((PageSize.A4.Width - image.ScaledWidth) / 2, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            doc.Add(image);

            Paragraph p = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, BaseColor.BLACK, Element.ALIGN_LEFT, 1)));
            doc.Add(p);

            Paragraph paragraph1 = new Paragraph("Tour Data From \nTour: " + Tour_Name+"\nPrint Time:"+DateTime.Now);
            paragraph1.Alignment = Element.ALIGN_CENTER;
            doc.Add(paragraph1);


            Paragraph paragraph2 = new Paragraph(PrintTour());
            doc.Add(paragraph2);
            image = iTextSharp.text.Image.GetInstance(ChartLocation);
            image.ScaleAbsolute(250f, 250f);
            image.SetAbsolutePosition((PageSize.A4.Width - image.ScaledWidth) / 2, (PageSize.A4.Height - image.ScaledHeight) / 2);
            doc.Add(image);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            ReceiptList rl = new ReceiptList();
            PdfPTable table = new PdfPTable(8);
            PdfPCell cell = new PdfPCell(new Phrase(TourID+" "+Tour_Name + " paid Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Client Name");
            table.AddCell("Worker Name");
            table.AddCell("Tour Date");
            table.AddCell("Order Date");
            table.AddCell("Payment");
            table.AddCell("Quantity");
            table.AddCell("Total");
            rl.BuildReceiptsByTourPaid(TourID);
            int counter = rl.GetReceiptsList().Count;
            for (i = 0; i < counter; i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetClient().GetFirstName().ToString()+" "+ rl.GetReceiptsList()[i].GetClient().GetLastName().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetWorker().GetFirstName()+" "+ rl.GetReceiptsList()[i].GetWorker().GetLastName());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderDate().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetPaymentDate().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString() + "$");
                sum += (rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString() + "$");
            doc.Add(table);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            rl.BuildReceiptsByTourUnPaidActive(TourID);
            table = new PdfPTable(8);
            cell = new PdfPCell(new Phrase(TourID + " " + Tour_Name + " unpaid Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Client Name");
            table.AddCell("Worker Name");
            table.AddCell("Tour Date");
            table.AddCell("Order Date");
            table.AddCell("Payment");
            table.AddCell("Quantity");
            table.AddCell("Total");
            counter = rl.GetReceiptsList().Count;
            sum = 0;
            for (i = 0; i < counter; i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetClient().GetFirstName().ToString() + " " + rl.GetReceiptsList()[i].GetClient().GetLastName().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetWorker().GetFirstName() + " " + rl.GetReceiptsList()[i].GetWorker().GetLastName());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderDate().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetPaymentDate().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString() + "$");
                sum += (rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString() + "$");
            doc.Add(table);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            rl.BuildReceiptsByClientUnpaidUnActive(TourID);
            table = new PdfPTable(8);
            cell = new PdfPCell(new Phrase(TourID + " " + Tour_Name + " Canceled Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Client Name");
            table.AddCell("Worker Name");
            table.AddCell("Tour Date");
            table.AddCell("Order Date");
            table.AddCell("Payment");
            table.AddCell("Quantity");
            table.AddCell("Total");
            counter = rl.GetReceiptsList().Count;
            sum = 0;
            for (i = 0; i < counter; i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetClient().GetFirstName().ToString() + " " + rl.GetReceiptsList()[i].GetClient().GetLastName().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetWorker().GetFirstName() + " " + rl.GetReceiptsList()[i].GetWorker().GetLastName());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderDate().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetPaymentDate().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString() + "$");
                sum += (rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString() + "$");
            doc.Add(table);
            doc.Close();
        }
        
    }

}
