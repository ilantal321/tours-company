﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class TourList
    {
        public List<Tour> Tours = new List<Tour>();
        /*
        constractor
        */
        public TourList()
        {
            Tours.Clear();
            Tour t = new Tour();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Tours ORDER BY PKID");
            while (dr.Read())
            {
                t= new Tour(int.Parse(dr["PKID"].ToString()),dr["Tour_Name"].ToString(), dr["Flight_number"].ToString(), int.Parse(dr["price"].ToString()), dr["Country"].ToString(), dr["Disdescription"].ToString(), int.Parse(dr["Days"].ToString()), dr["Tour_Date"].ToString(), int.Parse(dr["Capacity"].ToString()), dr["HandM"].ToString(),int.Parse(dr["Gate"].ToString()), dr["HandMReturn"].ToString(), dr["Flight_number_Return"].ToString(),int.Parse(dr["Gate_Return"].ToString()));
                Tours.Add(t);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        copy constractor
        */
        public TourList(List<Tour> tl)
        {
            Tours.AddRange(tl);
        }
        /*
        put all tours in the list
        */
        public void BuildToutlist()
        {
            Tours.Clear();
            Tour t = new Tour();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Tours ORDER BY PKID");
            while (dr.Read())
            {
                t = new Tour(int.Parse(dr["PKID"].ToString()), dr["Tour_Name"].ToString(), dr["Flight_number"].ToString(), int.Parse(dr["price"].ToString()), dr["Country"].ToString(), dr["Disdescription"].ToString(), int.Parse(dr["Days"].ToString()), dr["Tour_Date"].ToString(), int.Parse(dr["Capacity"].ToString()), dr["HandM"].ToString(), int.Parse(dr["Gate"].ToString()), dr["HandMReturn"].ToString(),dr["Flight_number_Return"].ToString(), int.Parse(dr["Gate_Return"].ToString()));
                Tours.Add(t);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        only Future tours
        */
        public void GetToursByDate()
        {
            TourList temp = new TourList(Tours);
            Tours.Clear();
            DateTime d = DateTime.Now;
            var result = from s in temp.GetTourList() where DateTime.Parse(s.GetDate()) > d select s;
            foreach (var tour in result)
            {
                Tours.Add(tour);
            }
        }
        /*
        only Continent tours
        */
        public TourList GetToursByContinent(int con)
        {
            TourList temp = new TourList(Tours);
            temp.GetTourList().Clear();
            DateTime d = DateTime.Now;
            CountryList cl = new CountryList(con);
            for (int i = 0; i < cl.getCountryList().Count; i++)
            { 
            var result = from s in Tours where int.Parse(s.GetCountry()) == cl.getCountryList()[i].GetPKID() select s ;
                foreach (var tour in result)
                {
                    temp.GetTourList().Add(tour);
                }

            }
            temp.SetTourList(temp.GetTourList().OrderBy(q => q.GetTourID()).ToList());
            return temp;
        }
        /*
        find tourby id
        */
        public Tour FindTourtbyID(string ID)
        {
            Tour t = new Tour();
            var result = from s in Tours where s.GetTourID().ToString() == ID select s;
            foreach (var tours in result)
            {
                t = tours;
            }
            return t;
        }
        /*
        get and set
        */
        public void SetTourList(List<Tour> t)
        {
            Tours = t;
        }
        public List<Tour> GetTourList()
        {
            return Tours;
        }

    }
}
