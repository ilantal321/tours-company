﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    add tour form user enter data and make a new tour
    */
    public partial class AddTourForm : Form
    {
        sha1ceypto sh = new sha1ceypto();
        Function f1 = new Function();
        Tour t = new Tour();
        int i = 0;
        CountryList cl = new CountryList();
        Country c = new Country();
        public AddTourForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                DTPTour.Value = DateTime.Now;
                DTPTour.MinDate = DateTime.Now;
                FillCBCountry();
                FillCBTime();
                OFDAddPic.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";//filter to get only picters
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill the combobox with countries 
        */
        public void FillCBCountry()
        {
            CBCountry.Items.Clear();
            foreach (Country i in cl.getCountryList())
            {
                CBCountry.Items.Add(i.GetCountryName());
            }
            CBCountry.SelectedIndex = i;
        }
        /*
        fill the comboboxs with the hours and minutes times
        */
        public void FillCBTime()
        {
            for (int num=0;num<60;num++)
            {
                if (num < 10)
                {
                    CBHour.Items.Add("0" + num.ToString());
                    CBMinutes.Items.Add("0" + num.ToString());
                    CBHourReturn.Items.Add("0" + num.ToString());
                    CBMinutesReturn.Items.Add("0" + num.ToString());
                }
                else if (num < 24)
                {
                    CBHour.Items.Add(num.ToString());
                    CBHourReturn.Items.Add(num.ToString());
                    CBMinutesReturn.Items.Add(num.ToString());
                    CBMinutes.Items.Add(num.ToString());
                }
                else
                {
                    CBMinutesReturn.Items.Add(num.ToString());
                    CBMinutes.Items.Add(num.ToString());
                }
            }
            CBHour.SelectedIndex = 0;
            CBMinutes.SelectedIndex = 0;
            CBHourReturn.SelectedIndex = 0;
            CBMinutesReturn.SelectedIndex = 0;
        }
        /*can add pics only after the tour was added*/
        public void ShowPicdata()
        {
            PBAddTourPic.Visible = true;
            PBAddPic.Visible = true;
            LPic.Visible = true;
            PBTourPic.Visible = true;
        }
        public void HidePicdata()
        {
            PBAddTourPic.Visible = false;
            PBAddPic.Visible = false;
            LPic.Visible = false;
            PBTourPic.Visible = false;
        }
        /*add tour to the database only if the input data good*/
        private void PBAddTour_Click(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckFNumber(TBFlightnumber.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Flight number need 8 characters long\n";
            }
            f1.CheckFNumber(TBRFN.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Return Flight number need 8 characters long\n";
            }
            f1.CheckPrice(TBPrice.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Price need start at least with 300$\n";
            }
            f1.CheckDays(TBDays.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Enter days\n";
            }
            f1.CheckDays(TBCapacity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Enter Capacity\n";
            }
            f1.CheckName(TBTourName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Tour name Start with Capital letter and more then 3 letters long\n";
            }
            if (TBGate.Text == "" || TBGate.Text == "0" && int.Parse(TBGate.Text) < 1000)
            {
                flag = false;
                str += "Enter gate number less then 1000\n";
            }
            if (TBGate.Text == "" || TBGate.Text == "0" && int.Parse(TBGate.Text) < 1000)
            {
                flag = false;
                str += "Enter return gate number less then 1000\n";
            }
            if (flag == false)
            {
                LError.Text = str;
                HidePicdata();
            }
            else
            {
                f1.Checkdup(TBTourName.Text, "Tour_Name", "Tours");
                if (f1.GetAnswer() == false)
                {
                    str += "There is a tour with the same name on the same date!\n";
                }
                else
                {
                    f1.CheckTourdupFN(String.Format("{0:dd/MM/yyyy}", DTPTour.Value),TBFlightnumber.Text);
                    if (f1.GetAnswer() == false)
                    {
                        str += "There is a tour with the same FlightNumber on the same date!\n";
                    }

                    else
                    {
                        f1.CheckTourdupRFN(String.Format("{0:dd/MM/yyyy}", DTPTour.Value), TBRFN.Text, TBDays.Text);
                        if (f1.GetAnswer() == false)
                        {
                            str += "There is a tour with the same Return FlightNumber on the same date!\n";
                        }
                        else
                        {
                            int m = f1.MakePKID("Tours") + 1;
                            t = new Tour(m, TBTourName.Text, TBFlightnumber.Text, int.Parse(TBPrice.Text), c.GetPKID().ToString(), RTBDisdescription.Text, int.Parse(TBDays.Text), String.Format("{0:dd/MM/yyyy}", DTPTour.Value), int.Parse(TBCapacity.Text), CBHour.SelectedItem.ToString() + ":" + CBMinutes.SelectedItem.ToString(), int.Parse(TBGate.Text), CBHourReturn.SelectedItem.ToString() + ":" + CBMinutesReturn.SelectedItem.ToString(), TBRFN.Text, int.Parse(TBRGate.Text));
                            t.AddTourToDB();
                            LError.Text = t.PrintTour();
                            ShowPicdata();
                        }
                    }
                }
            }
            LError.Text = str;
        }
        /*add pic to the tour*/
        private void PBAddTourPic_Click(object sender, EventArgs e)
        {
            if (LPicName.Text.Length<3)
            {
                LError.Text = "Add picture to tour";
            }
            else
            {
                f1.CheckPicdup(LPicName.Text, t.GetTourID().ToString());
                if (f1.GetAnswer() == false)
                {
                    LError.Text = "The picture is in the tour\n";
                }
                else
                {
                    int m = f1.MakePKID("Pics_Tours") + 1;
                    PicsTours p = new PicsTours(m, t.GetTourID(), LPicName.Text);
                    p.AddPicToDB();
                    LError.Text = "Picture added\n";
                }
            }
        }
        /*user pick a pic to add*/
        private void PBAddPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                LPicName.Text = OFDAddPic.SafeFileName;
                if (!new System.IO.FileInfo(@"Pic\Tours\" + LPicName.Text).Exists)
                {
                    System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Tours\" + LPicName.Text);
                }
                PBTourPic.Image = Image.FromFile(@"Pic\Tours\" + LPicName.Text);
            }
        }
        /*cloack and date*/
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*Exit with fade timer*/
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*go to last form*/
        private void PBBack_Click(object sender, EventArgs e)
        {
            if (LoginForm.Permission == "Worker")
            {
                var WorkerMenuForm = new WorkerMenuForm();
                WorkerMenuForm.Closed += (s, args) => this.Close();
                WorkerMenuForm.Show();
                this.Hide();
            }
            else if (LoginForm.Permission == "Manager")
            {
                var ManagerMenuForm = new ManagerMenuForm();
                ManagerMenuForm.Closed += (s, args) => this.Close();
                ManagerMenuForm.Show();
                this.Hide();
            }

        }
        /*flight numbers, gates, price,cap and days are only digits*/
        private void TBFlightnumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBCapacity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBGate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBRFN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TBRGate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        /*hover and tooltip withmouse*/
        private void PBAddClient_MouseLeave(object sender, EventArgs e)
        {
            PBAddTour.BackColor = Color.Transparent;
        }
        private void PBAddTourPic_MouseLeave(object sender, EventArgs e)
        {
            PBAddTourPic.BackColor = Color.Transparent;
        }
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {

            PBExit.BackColor = Color.Transparent;
        }
        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }
        private void PBAddPic_MouseHover(object sender, EventArgs e)
        {
            PBAddPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Search pic", PBAddPic);
        }
        private void PBAddPic_MouseLeave(object sender, EventArgs e)
        {
            PBAddPic.BackColor = Color.Transparent;
        }
        private void PBAddTourPic_MouseHover(object sender, EventArgs e)
        {
            PBAddTourPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add pic",PBAddTourPic );
        }
        private void PBAddTour_MouseHover(object sender, EventArgs e)
        {
            PBAddTour.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add Tour", PBAddTour);
        }
        /*chhange selected country*/
        private void CBCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            i = CBCountry.SelectedIndex;
            c = cl.getCountryList()[i];
        }
        /*fade timer*/
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*tooltip background*/
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }


    }
}
