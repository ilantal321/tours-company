﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    /*
     this is the client order tours form the client can see the tours in the future and can order places to the tour
    */
    public partial class ClientOrderTourForm : Form
    {
        Function f1 = new Function();
        Tour t = new Tour();
        TourList tours = new TourList();
        TourList Toursbycon = new TourList();
        Order o = new Order();
        PicsTourList picsTour = new PicsTourList();
        PicsTourList picsToTour= new PicsTourList();
        Country con = new Country();
        ContinentList cl = new ContinentList();
        PicsTours pictour = new PicsTours();
        Continent c = new Continent();
        int i = 0;
        int j = 0;
        int k = 0;
        public ClientOrderTourForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                FillCBContinent();
                tours.GetToursByDate();
                if (Toursbycon.GetTourList().Count > 0)//no tours
                {
                    t = Toursbycon.GetTourList()[i];
                    fillTourdata();
                }
                else
                {
                    EmptyTourdata();
                }
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill the Continent combobox
        */
        public void FillCBContinent()
        {
            CBContinent.Items.Clear();
            foreach (Continent cont in cl.GetContinentsList())
            {
                CBContinent.Items.Add(cont.GetContinentName());
            }
            CBContinent.SelectedIndex = k;
        }
        /*
        fill the tour in the same Continent in the combobox 
        */
        public void FillCBTours()
        {
            bool flag = false;
            CBToursList.Items.Clear();
            foreach (Tour i in Toursbycon.GetTourList())
            {
                Country tempc = new Country(i.GetCountry());
                flag = true;
                CBToursList.Items.Add(i.GetTourID() + " " + i.GetTourname() + " " + tempc.GetCountryName() + " " + i.GetPrice());
            }
            if (flag)
            {
                CBToursList.SelectedIndex = 0;
                LError.Text = "";
                PBTourPic.Visible = true;
                PBPrintTourPDF.Visible = true;
            }
            else
            {
                PBPrintTourPDF.Visible = false;
                PBTourPic.Visible = false;
                LError.Text = "No Tours on that Continent";
                EmptyTourdata();
                CBToursList.ResetText();
            }
        }
        /*
        if there is no tour empty the data
        */
        public void EmptyTourdata()
        {
            TBTourID.Text = "";
            LTourFN.Text = "";
            LTourPrice.Text = "";
            LTourDays.Text = "";
            LTourCap.Text = "";
            LTourDatein.Text = "";
            LTourN.Text = "";
            LTourCountry.Text = "";
            LShowDisdescription.Text = "";
        }
        /*
        put tour of the tour
        */
        public void fillTourdata()
        {
            TBTourID.Text = Toursbycon.GetTourList()[i].GetTourID().ToString();
            LTourFN.Text = Toursbycon.GetTourList()[i].GetFlight_numberID();
            LTourPrice.Text = Toursbycon.GetTourList()[i].GetPrice().ToString()+"$";
            LTourDays.Text = Toursbycon.GetTourList()[i].GetDay().ToString();
            LTourCap.Text = Toursbycon.GetTourList()[i].GetCapacity().ToString();
            LTourDatein.Text = Toursbycon.GetTourList()[i].GetDate()+" "+Toursbycon.GetTourList()[i].GetTimeHM();
            LTourN.Text = Toursbycon.GetTourList()[i].GetTourname();
            LTourCountry.Text = Toursbycon.GetTourList()[i].GetCountryName();
            LShowDisdescription.Text = Toursbycon.GetTourList()[i].Getdisdescription();
            if (Toursbycon.GetTourList()[i].GetCapacity()==0)
            {
                PBAddOrder.Visible = false;
                LError.Text = "Tour full";
            }
            else
            {
                PBAddOrder.Visible = true;
            }
        }
        /*
        client order tour check if there is enugh places in the tour
        add the order in the database
        sub the tour places
        */
        private void PBAddOrder_Click(object sender, EventArgs e)
        {
            if (Toursbycon.GetTourList().Count != 0)
            {
                if (int.Parse(TBQuantity.Text) < 1)
                {
                    LError.Text = "Enter Quantity!";
                }
                else
                {
                    if (int.Parse(TBQuantity.Text) > t.GetCapacity())
                    {
                        LError.Text = "There are not enough places on the trip";
                    }
                    else
                    {
                        int m = f1.MakePKID("Orders") + 1;
                        if (LoginForm.Permission == "Client")
                        {
                            o = new Order(m, int.Parse(LoginForm.PKID.ToString()), 8, t.GetTourID(), false, int.Parse(TBQuantity.Text));
                        }
                        else
                        {
                            o = new Order(m, int.Parse(FindClientForm.clientid.ToString()), int.Parse(LoginForm.PKID.ToString()), t.GetTourID(), false, int.Parse(TBQuantity.Text));
                        }
                            o.AddOrderToDB();
                        t.SetCapacity(t.GetCapacity() - int.Parse(TBQuantity.Text));
                        t.UpdateCapacity();
                        fillTourdata();
                        LError.Text = o.PrintOrder();
                    }
                }
            }
        }
        /*
        move to the next/last tour 
        */
        private void PBPlus_Click(object sender, EventArgs e)
        {
            if (Toursbycon.GetTourList().Count != 0)
            {
                i++;
                if (i == Toursbycon.GetTourList().Count)
                {
                    i = 0;
                }
                t = Toursbycon.GetTourList()[i];
                CBToursList.SelectedIndex = i;
            }
        }
        private void PBMinus_Click(object sender, EventArgs e)
        {
            if (Toursbycon.GetTourList().Count != 0)
            {
                i--;
                if (i < 0)
                {
                    i = Toursbycon.GetTourList().Count - 1;
                }
                t = Toursbycon.GetTourList()[i];
                CBToursList.SelectedIndex = i;
            }
        }
        /*
        move to the next/last picters
        */
        private void PBPicPlus_Click(object sender, EventArgs e)
        {
            if (Toursbycon.GetTourList().Count != 0)
            {
                if (picsToTour.GetTourPicList().Count != 0)
                {
                    j++;
                    if (j >= picsToTour.GetTourPicList().Count)
                    {
                        j = 0;
                    }
                    LPicName.Text = picsToTour.GetTourPicList()[j].GetPicName();
                    PBTourPic.Image = Image.FromFile(@"Pic\Tours\" + LPicName.Text);
                }
            }
        }
        private void PBPicMinus_Click(object sender, EventArgs e)
        {
            if (Toursbycon.GetTourList().Count != 0)
            {
                if (picsToTour.GetTourPicList().Count != 0)
                {
                    j--;
                    if (j < 0)
                    {
                        j = picsToTour.GetTourPicList().Count - 1;
                    }
                    LPicName.Text = picsToTour.GetTourPicList()[j].GetPicName();
                    PBTourPic.Image = Image.FromFile(@"Pic\Tours\" + LPicName.Text);
                }
            }
        }
        /*
        make a PDF wite tour data in PDf for clients 
        */ 
        private void PBPrintTourPDF_Click(object sender, EventArgs e)
        {
            if (SFDTourPDF.ShowDialog() == DialogResult.OK)
            {
                string Path = SFDTourPDF.FileName;
                t.PrintTourDataPDFClient(System.IO.Path.GetFileNameWithoutExtension(SFDTourPDF.FileName), System.IO.Path.GetDirectoryName(Path));
            }
        }
        /*
        change Continent change the tour list with the same Continent
        */
        private void CBContinent_SelectedIndexChanged(object sender, EventArgs e)
        {
            k = CBContinent.SelectedIndex;
            c = cl.GetContinentsList()[k];
            Toursbycon = tours.GetToursByContinent(c.GetPKID());
            FillCBTours();
        }
        /*
        change tour and put the tour data in form
        */
        private void CBToursList_SelectedIndexChanged(object sender, EventArgs e)
        {
            i = CBToursList.SelectedIndex;
            t = Toursbycon.GetTourList()[i];
            picsToTour.SetTourPicList(picsTour.FindPicByTourID(t.GetTourID()));
            j = 0;
            con = new Country(tours.GetTourList()[i].GetCountry());
            fillTourdata();
            
            if (picsToTour.GetTourPicList().Count != 0)
            {
                LPicName.Text = picsToTour.GetTourPicList()[j].GetPicName();
                PBTourPic.Image = Image.FromFile(@"Pic\Tours\" + LPicName.Text);
            }
            else
            {
                LPicName.Text ="";
                PBTourPic.Image = null;
            }
        }
        /*
        find tour by tour id
        */
        private void PBFTID_Click(object sender, EventArgs e)
        {
            string str = "";
            if (TBTourID.Text=="")
            {
                str = "Enter Tour ID\n";
            }
            else
            {
                int temp = int.Parse(TBTourID.Text);
                Tour newt = new Tour();
                t = tours.FindTourtbyID(TBTourID.Text);
                i = tours.GetTourList().IndexOf(t);
                if (t.GetTourID() != 0)
                {
                    Country c = new Country(t.GetCountry());
                    CBContinent.SelectedIndex = c.GetContinentPKID() - 1;
                    newt = Toursbycon.FindTourtbyID(temp.ToString());
                    i = Toursbycon.GetTourList().IndexOf(newt);
                }
                if (i != -1)
                {
                    CBToursList.SelectedIndex = i;
                    str = "Tour Found";
                }
                else
                {
                    str = "Tour with that ID dont exist";
                    EmptyTourdata();
                }
            }
            LError.Text = str;
        }
        /*
        Exit form with fade
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        return to last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            if (LoginForm.Permission == "Client")
            {
                var ClientrMenuForm = new ClientMenuForm();
                ClientrMenuForm.Closed += (s, args) => this.Close();
                ClientrMenuForm.Show();
                this.Hide();
            }
            else
            {
                var FindClientForm = new FindClientForm();
                FindClientForm.Closed += (s, args) => this.Close();
                FindClientForm.Show();
                this.Hide();
            }

        }
        /*
        Textbox and labels that get only digits
        */
        private void TBTourID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        /*
        hover and leave mouse
        */
        private void PBAddClient_MouseHover(object sender, EventArgs e)
        {
            PBAddOrder.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Order tour", PBAddOrder);
        }
        private void PBAddClient_MouseLeave(object sender, EventArgs e)
        {
            PBAddOrder.BackColor = Color.Transparent;
        }

        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }

        private void PBPicPlus_MouseHover(object sender, EventArgs e)
        {
            PBPicPlus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Next pic", PBPicPlus);
        }
        private void PBPicPlus_MouseLeave(object sender, EventArgs e)
        {
            PBPicPlus.BackColor = Color.Transparent;
        }

        private void PBPicMinus_MouseHover(object sender, EventArgs e)
        {
            PBPicMinus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("previous pic", PBPicMinus);
        }
        private void PBPicMinus_MouseLeave(object sender, EventArgs e)
        {
            PBPicMinus.BackColor = Color.Transparent;
        }

        private void PBPlus_MouseHover(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Next Tour",PBPlus);
        }
        private void PBPlus_MouseLeave(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.Transparent;
        }

        private void PBMinus_MouseHover(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("previous Tour", PBMinus);
        }
        private void PBMinus_MouseLeave(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.Transparent;
        }

        private void PBFTID_MouseHover(object sender, EventArgs e)
        {
            PBFTID.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find tour by tour ID", PBFTID);
        }
        private void PBFTID_MouseLeave(object sender, EventArgs e)
        {
            PBFTID.BackColor = Color.Transparent;
        }

        private void PBPrintTourPDF_MouseHover(object sender, EventArgs e)
        {
            PBPrintTourPDF.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Data in PDF", PBPrintTourPDF);
        }
        private void PBPrintTourPDF_MouseLeave(object sender, EventArgs e)
        {
            PBPrintTourPDF.BackColor = Color.Transparent;
        }
        /*
        exit fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        clock timer
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        Tool tip get background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
