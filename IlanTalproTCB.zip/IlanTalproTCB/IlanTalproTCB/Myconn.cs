﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace IlanTalproTCB
{
    class Myconn
    {
        private OleDbConnection conn;
        /*
        open connection
        */
        public OleDbDataReader SandQuery(string str)
        {
                string strDb = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=ITDB.accdb;" + "Persist Security Info=False";
                conn = new OleDbConnection(strDb);
                conn.Open();
                OleDbDataReader dr;
                OleDbCommand cmd = new OleDbCommand(str, conn); //command sq;
                dr = cmd.ExecuteReader(); // pointer to table
                return dr;
        }
        /*
        empty constractor
        */
        public Myconn ()
        {

        }
        /*
        get and set
        */
        public void Setconn(OleDbConnection c)
        {
            conn = c;
        }
        public OleDbConnection Getconn()
        {
            return conn;
        }
        /*
        close connection
        */
        public void closeCon()
        {
            if (conn.State == System.Data.ConnectionState.Open)
            {
                conn.Close();
            }
        }
    }
}
