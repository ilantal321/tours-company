﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class ContinentList
    {
        public List<Continent> Continents = new List<Continent>();
        /*
        constractor
        */
        public ContinentList()
        {
            Continents.Clear();
            Continent c = new Continent();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Continents ORDER BY PKID");
            while (dr.Read())
            {
                c = new Continent(int.Parse(dr["PKID"].ToString()), dr["ContinentName"].ToString());
                Continents.Add(c);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        set and get
        */
        public void SetContinentsList(List<Continent> c)
        {
            Continents = c;
        }
        public List<Continent> GetContinentsList()
        {
            return Continents;
        }
    }
}
