﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    Flight ticket form 
    print tickets by client orders
    */
    public partial class FlightTicketForm : Form
    {
        ReceiptList rl = new ReceiptList();
        Flight_TicketList FTL = new Flight_TicketList();
        Flight_TicketList FTLTaken = new Flight_TicketList();
        Function f1 = new Function();
        int i = 0,j=0;
        public FlightTicketForm()
        {
            try
            {
                InitializeComponent();
                rl.BuildReceiptsByClientForFlightTicket(FindClientForm.clientid);
                if (rl.GetReceiptsList().Count != 0)
                {
                    fillCBOrders();
                    TDate.Start();
                    LFromAT.Text = "Israel";
                    LFromBP.Text = "Israel";
                    CBClass.SelectedIndex = 0;
                    CBTours.SelectedIndex = 0;
                    CBSeats.SelectedIndex = 0;
                }
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        put tour data in the form
        */
        public void PutData()
        {
            i = CBTours.SelectedIndex;
            LDateAT.Text = rl.GetReceiptsList()[i].GetTour().GetDate();
            LDateBP.Text = rl.GetReceiptsList()[i].GetTour().GetDate();
            LCountryAT.Text = rl.GetReceiptsList()[i].GetTour().GetCountryName();
            LCountryBP.Text = rl.GetReceiptsList()[i].GetTour().GetCountryName();
            LTimeAT.Text = rl.GetReceiptsList()[i].GetTour().GetTimeHM();
            LTimeBP.Text = rl.GetReceiptsList()[i].GetTour().GetTimeHM();
            LFNAT.Text = rl.GetReceiptsList()[i].GetTour().GetFlight_numberID();
            LFNBP.Text = rl.GetReceiptsList()[i].GetTour().GetFlight_numberID();
            LGateAT.Text = rl.GetReceiptsList()[i].GetTour().GetGate().ToString();
            LGateBP.Text = rl.GetReceiptsList()[i].GetTour().GetGate().ToString();
            CBSeats.Items.Clear();
            FTL.Flight_TicketListByTourID(rl.GetReceiptsList()[i].GetTour().GetTourID());
            FTLTaken.Flight_TicketTakenListByTourID(rl.GetReceiptsList()[i].GetTour().GetTourID(), rl.GetReceiptsList()[i].GetOrder().GetOrderNumber());
            CBSeats.Items.Clear();
            CBSeatsTaken.Items.Clear();
            foreach (Flight_Ticket r in FTL.GetFlightTicketList())
            {
                CBSeats.Items.Add(r.GetSeat());
            }
            foreach (Flight_Ticket r in FTLTaken.GetFlightTicketList())
            {
                CBSeatsTaken.Items.Add(r.GetSeat());
            }
            if (FTLTaken.GetFlightTicketList().Count==rl.GetReceiptsList()[i].GetOrder().GetQuantity())
            {
                CBSeats.Visible = false;
                PBPrintTicket.Visible = false;
                CBSeatsTaken.Visible = true;
                PBPrintTForTaken.Visible = true;
                CBSeatsTaken.SelectedIndex = 0;

            }
            else if (FTLTaken.GetFlightTicketList().Count == 0)
            {
                CBSeats.Visible = true;
                PBPrintTicket.Visible = true;
                CBSeatsTaken.Visible = false;
                PBPrintTForTaken.Visible = false;
                CBSeats.SelectedIndex = 0;
            }
            else 
            {
                CBSeats.Visible = true;
                PBPrintTicket.Visible = true;
                CBSeatsTaken.Visible = true;
                PBPrintTForTaken.Visible = true;
                CBSeats.SelectedIndex = 0;
                CBSeatsTaken.SelectedIndex = 0;
            }

        }
        /*
        fill combobox with orders 
        */
        public void fillCBOrders()
        {
            CBTours.Items.Clear();
            foreach (Receipt r in rl.GetReceiptsList())
            {
                CBTours.Items.Add(r.PrintDataForWorkerMenu());
            }
        }
        /*
        date and clock
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        Exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        go to last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            
            var FindClientForm = new FindClientForm();
            FindClientForm.Closed += (s, args) => this.Close();
            FindClientForm.Show();
            this.Hide();
        }
        /*
        change items in the combo box
        */
        private void CBTours_SelectedIndexChanged(object sender, EventArgs e)
        {
            PutData();
        }
        private void CBSeats_SelectedIndexChanged(object sender, EventArgs e)
        {
            j = CBSeats.SelectedIndex;
        }
        /*
        make 2 flight tickets in and back
        and save the seat for that client
        */
        private void PBPrintTicket_Click(object sender, EventArgs e)
        {
            f1.CheckName(TBPName.Text);
            if (f1.GetAnswer() == true)
            {
                if (SFDPDFTicket.ShowDialog() == DialogResult.OK)
            {
                    string Path = SFDPDFTicket.FileName;
                    rl.GetReceiptsList()[i].PrintTicketPDF(TBPName.Text, CBClass.SelectedItem.ToString(), CBSeats.SelectedItem.ToString(), System.IO.Path.GetFileNameWithoutExtension(SFDPDFTicket.FileName), System.IO.Path.GetDirectoryName(Path));
                    FTL.GetFlightTicketList()[j].SetOrderID(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber());
                    FTL.GetFlightTicketList()[j].Update_Flight_Ticket_TODB();
                    FTL.GetFlightTicketList().RemoveAt(j);
                    CBSeats.Items.RemoveAt(j);
                    PutData();
                }
            }
        }
        /*
        remake 2 flight tickets in and back
        for saved client ticket
        */
        private void PBPrintTForTaken_Click(object sender, EventArgs e)
        {
            f1.CheckName(TBPName.Text);
            if (f1.GetAnswer() == true)
            {
                if (SFDPDFTicket.ShowDialog() == DialogResult.OK)
                {
                    string Path = SFDPDFTicket.FileName;
                    rl.GetReceiptsList()[i].PrintTicketPDF(TBPName.Text, CBClass.SelectedItem.ToString(), CBSeatsTaken.SelectedItem.ToString(), System.IO.Path.GetFileNameWithoutExtension(SFDPDFTicket.FileName), System.IO.Path.GetDirectoryName(Path));
                }
            }
        }
        /*
        Hover and tooltip with mouse
        */
        private void PBPrintTForTaken_MouseHover(object sender, EventArgs e)
        {
            PBPrintTForTaken.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Reprint Filght Ticket", PBPrintTForTaken);
        }

        private void PBPrintTForTaken_MouseLeave(object sender, EventArgs e)
        {
            PBPrintTForTaken.BackColor = Color.Transparent;
        }

        private void PBPrintTicket_MouseHover(object sender, EventArgs e)
        {
            PBPrintTicket.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Print new Filght Ticket", PBPrintTicket);
        }
        private void PBPrintTicket_MouseLeave(object sender, EventArgs e)
        {
            PBPrintTicket.BackColor = Color.Transparent;
        }
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }

        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }
        /*
        fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tooltip background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
