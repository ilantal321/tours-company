﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
namespace IlanTalproTCB
{
    class Receipt
    {
        private Order o;
        private Client c;
        private Tour t;
        private Worker w;
        /*
        empty constractor
        */
        public Receipt() { }
        /*
        function for flight ticket pdf to put data in pdf
        */
        public static void filldataticet(PdfContentByte cb, int x, int y, string text)
        {
            cb.BeginText();
            cb.MoveText(x, y);
            cb.ShowText(text);
            cb.EndText();
        }
        /*
        constractor from database
        */
        public Receipt (int Orderpkid)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("SELECT *FROM((Orders INNER JOIN Clients ON Orders.ClientPKID = Clients.PKID) INNER JOIN Tours ON Orders.TourPKID = Tours.PKID) INNER JOIN Workers ON Orders.WorkerPKID = Workers.PKID WHERE Orders.PKID="+Orderpkid+" ;");
            while (dr.Read())
            {
                o = new Order(int.Parse(dr["Orders.PKID"].ToString()), int.Parse(dr["ClientPKID"].ToString()), int.Parse(dr["WorkerPKID"].ToString()), int.Parse(dr["TourPKID"].ToString()), bool.Parse(dr["Payment"].ToString()), int.Parse(dr["Quantity"].ToString()), DateTime.Parse(dr["OrderDate"].ToString()), DateTime.Parse(dr["PaymentDate"].ToString()) ,bool.Parse(dr["Orders.Active"].ToString()));
                c = new Client(int.Parse(dr["ClientPKID"].ToString()), dr["Clients.FirstName"].ToString(), dr["Clients.LastName"].ToString(), dr["Clients.Address"].ToString(), dr["Clients.Birthdate"].ToString(), dr["Clients.City"].ToString(), dr["Clients.UserName"].ToString(), dr["Clients.Passw"].ToString(), dr["Clients.Pic"].ToString(), dr["Clients.ID"].ToString(), dr["Email"].ToString(), dr["PhoneNumber"].ToString(), bool.Parse(dr["Clients.active"].ToString()));
                w = new Worker(int.Parse(dr["WorkerPKID"].ToString()), dr["Workers.FirstName"].ToString(), dr["Workers.LastName"].ToString(), dr["Workers.Address"].ToString(), dr["Workers.Birthdate"].ToString(), dr["Workers.City"].ToString(), dr["Workers.UserName"].ToString(), dr["Workers.Passw"].ToString(), dr["Workers.Pic"].ToString(), dr["Workers.ID"].ToString(), int.Parse(dr["Salary"].ToString()), bool.Parse(dr["Workers.active"].ToString()),DateTime.Parse(dr["DateAbsorption"].ToString()));
                t = new Tour(int.Parse(dr["Tours.PKID"].ToString()), dr["Tour_Name"].ToString(), dr["Flight_number"].ToString(), int.Parse(dr["price"].ToString()), dr["Country"].ToString(), dr["Disdescription"].ToString(), int.Parse(dr["Days"].ToString()), dr["Tour_Date"].ToString(), int.Parse(dr["Capacity"].ToString()), dr["HandM"].ToString(),int.Parse(dr["Gate"].ToString()), dr["HandMReturn"].ToString(), dr["Flight_number_Return"].ToString(), int.Parse(dr["Gate_Return"].ToString()));

            }
            dr.Close();
            connec.closeCon();
        }
        /*
        print for other uses
        */
        public string printData()
        {
            return (o.PrintOrder() + "\n" + c.PrintClient + "\n" + t.PrintTour() + "\n" + w.PrintWorker);
        }
        public string printDataPDF()
        {
            string workerData;
            if (w.GetPKID() ==4)
            {
                workerData = "Client Orderd the Tour";
            }
            else
            {
                workerData = w.PrintWorkerForClietPDF();
            }
            return ("Order:\n"+o.PrintOrderForClientPDF()  + "\nTour:\n" + t.PrintTourForClientPDF() + "\nWorker:\n" + workerData);
        }
        public string PrintDataForclientMenu()
        {
            return ("Order num: " + o.GetOrderNumber() + " OrderDate: " + o.GetOrderDate() + " Tour Date:" + t.GetDate() + " tour Price: " + o.GetQuantity() * t.GetPrice() + "$");
        }
        public string PrintDataForWorkerMenu()
        {
            return ("Order num: " + o.GetOrderNumber() + " Tour Date:" + t.GetDate() + " tour Price: " + o.GetQuantity() * t.GetPrice() + "$ Clent name:" + c.GetFirstName()+" "+c.GetLastName()+ " Client Phone: "+c.GetPhoneNumber()+" Client Mail: "+ c.GetMail());
        }
        /*
        get and set
        */
        public Order GetOrder()
        {
            return o;
        }
        public Client GetClient()
        {
            return c;
        }
        public Tour GetTour()
        {
            return t;
        }
        public Worker GetWorker()
        {
            return w;
        }
        /*
        print pdf Recipt for clint
        */
        public void PrintReciptDataPDF(string fileName, string FileLocation)
        {
            ReceiptList rl = new ReceiptList();
            Document doc = new Document(iTextSharp.text.PageSize.A4, 10, 10, 42, 35);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(FileLocation + "/" + fileName + ".pdf", FileMode.Create));
            doc.Open();

            iTextSharp.text.Image image = iTextSharp.text.Image.GetInstance("pic/plane.png");
            image.SetAbsolutePosition(doc.LeftMargin, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            image.ScaleAbsolute(40f, 40f);
            doc.Add(image);

            image = iTextSharp.text.Image.GetInstance("pic/IT.png");
            image.ScaleAbsolute(50f, 50f);
            image.SetAbsolutePosition((PageSize.A4.Width - image.ScaledWidth) / 2, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            doc.Add(image);

            Paragraph p = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, BaseColor.BLACK, Element.ALIGN_LEFT, 1)));
            doc.Add(p);

            Paragraph paragraph1 = new Paragraph("Receipt For Tour:" + t.GetTourID() + "\nfor: " + c.GetFirstName() + " " + c.GetLastName() + " ID:" + c.GetID());
            paragraph1.Alignment = Element.ALIGN_CENTER;
            doc.Add(paragraph1);

            Paragraph paragraph2 = new Paragraph(printDataPDF());
            doc.Add(paragraph2);

            paragraph1 = new Paragraph("Total payment:" + o.GetQuantity()*t.GetPrice()+"$ For "+o.GetQuantity()+" Places.");
            paragraph1.Alignment = Element.ALIGN_CENTER;
            doc.Add(paragraph1);
            doc.Close();
        }
        /*
        print pdf flight ticket for client for clint
        */
        public void PrintTicketPDF(string PName, string FClass, string seat, string fileName, string FileLocation)
        {
            Country c = new Country(t.GetCountry());
            iTextSharp.text.Image imageFilePath = iTextSharp.text.Image.GetInstance("pic/AirTicket.jpg");

            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            Document doc = new Document(iTextSharp.text.PageSize.A6.Rotate(), 0, 0, 0, 0);

            jpg.ScaleToFit(420, 620);

            jpg.Alignment = iTextSharp.text.Image.UNDERLYING;

            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(FileLocation + "/" + fileName + ".pdf", FileMode.Create));

            doc.Open();

            doc.NewPage();

            doc.Add(jpg);
            PdfContentByte cb = wri.DirectContent;
            BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            cb.SaveState();
            cb.SetFontAndSize(bf, 8);
            filldataticet(cb, 35, 190, PName);
            filldataticet(cb, 35, 166, FClass);
            filldataticet(cb, 35, 142, "Israel");
            filldataticet(cb, 35, 118, c.GetCountryName());
            filldataticet(cb, 170, 190, t.GetDate());
            filldataticet(cb, 170, 166, t.GetGate().ToString());
            filldataticet(cb, 170, 142, t.GetFlight_numberID());
            filldataticet(cb, 235, 190, t.GetTimeHM());
            filldataticet(cb, 235, 166, seat);
            filldataticet(cb, 320, 201, PName);
            filldataticet(cb, 320, 188, "Israel");
            filldataticet(cb, 320, 174, c.GetCountryName());
            filldataticet(cb, 312, 159, t.GetDate());
            filldataticet(cb, 320, 145, t.GetGate().ToString());
            filldataticet(cb, 320, 131, t.GetFlight_numberID());
            filldataticet(cb, 365, 159, t.GetTimeHM());
            filldataticet(cb, 366, 143, seat);
            cb.RestoreState();
            doc.NewPage();
            cb = wri.DirectContent;
            cb.SaveState();
            cb.SetFontAndSize(bf, 8);
            doc.Add(jpg);
            filldataticet(cb, 35, 190, PName);
            filldataticet(cb, 35, 166, FClass);
            filldataticet(cb, 35, 142, c.GetCountryName());
            filldataticet(cb, 35, 118, "Israel");
            filldataticet(cb, 170, 190, (DateTime.Parse(t.GetDate()).AddDays(t.GetDay()).ToString("dd/MM/yyyy")).ToString());
            filldataticet(cb, 170, 166, t.GetGateReturn().ToString());
            filldataticet(cb, 170, 142, t.getFlight_number_Return());
            filldataticet(cb, 235, 190, t.GetTimeHMReturn().ToString());
            filldataticet(cb, 235, 166, seat);
            filldataticet(cb, 320, 201, PName);
            filldataticet(cb, 320, 188, c.GetCountryName());
            filldataticet(cb, 320, 174, "Israel");
            filldataticet(cb, 312, 159, (DateTime.Parse(t.GetDate()).AddDays(t.GetDay()).ToString("dd/MM/yyyy")).ToString());
            filldataticet(cb, 320, 145, t.GetGateReturn().ToString());
            filldataticet(cb, 320, 131, t.getFlight_number_Return());
            filldataticet(cb, 365, 159, t.GetTimeHMReturn().ToString());
            filldataticet(cb, 366, 143, seat);
            cb.RestoreState();
            doc.Close();
        }
    }
}
