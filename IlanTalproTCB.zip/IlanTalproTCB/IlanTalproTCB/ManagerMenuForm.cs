﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{        
    /*
     manager menu form manager can go to other forms
     can see close unpaid orders and oreders for pased tours
    */
    public partial class ManagerMenuForm : Form
    {
        sha1ceypto sh = new sha1ceypto();
        Function f1 = new Function();
        Manager m = new Manager( LoginForm.PKID.ToString());
        ReceiptList rl = new ReceiptList();
        public ManagerMenuForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                rl.BuildReceiptsByUnpaid();
                Lda.Text = rl.PrintReceiptsDataWorker();
                LHeader.Text = "Welcome " + m.GetFirstName() + " "+m.GetLastName()+ " to I.T travel company";
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*date and clock*/
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*Exit with fade timer*/
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*go to last form*/
        private void PBBack_Click(object sender, EventArgs e)
        {
            
            var LoginForm = new LoginForm();
            LoginForm.Closed += (s, args) => this.Close();
            LoginForm.Show();
            this.Hide();
        }
        /*go to other form*/
        private void PBUpDataManager_Click(object sender, EventArgs e)
        {
            var UPManagerForm = new UpdateManagerForm();
            UPManagerForm.Closed += (s, args) => this.Close();
            UPManagerForm.Show();
            this.Hide();
        }

        private void PBAddCountries_Click(object sender, EventArgs e)
        {
            var AddCountryForm = new AddCountryForm();
            AddCountryForm.Closed += (s, args) => this.Close();
            AddCountryForm.Show();
            this.Hide();
        }

        private void PBAddClient_Click(object sender, EventArgs e)
        {
            var AddClientForm = new AddClientForm();
            AddClientForm.Closed += (s, args) => this.Close();
            AddClientForm.Show();
            this.Hide();
        }

        private void PBFindClient_Click(object sender, EventArgs e)
        {
            var UPManagerClientForm = new FindClientForm();
            UPManagerClientForm.Closed += (s, args) => this.Close();
            UPManagerClientForm.Show();
            this.Hide();
        }



        private void PBAddWorker_Click(object sender, EventArgs e)
        {
            var AddWorkerForm = new AddWorkerForm();
            AddWorkerForm.Closed += (s, args) => this.Close();
            AddWorkerForm.Show();
            this.Hide();
        }

        private void PBFindWorkers_Click(object sender, EventArgs e)
        {
            var FindWorkerForm = new FindWorkerForm();
            FindWorkerForm.Closed += (s, args) => this.Close();
            FindWorkerForm.Show();
            this.Hide();
        }
        private void PBAddTour_Click(object sender, EventArgs e)
        {
            var AddtourForm = new AddTourForm();
            AddtourForm.Closed += (s, args) => this.Close();
            AddtourForm.Show();
            this.Hide();
        }

        private void PBFindTour_Click(object sender, EventArgs e)
        {
            var UpdateTourForm = new FindTour();
            UpdateTourForm.Closed += (s, args) => this.Close();
            UpdateTourForm.Show();
            this.Hide();
        }
        private void PBUpDateClient_Click(object sender, EventArgs e)
        {
            var UpdateClientForm = new UpdateWorkerForm();
            UpdateClientForm.Closed += (s, args) => this.Close();
            UpdateClientForm.Show();
            this.Hide();
        }

        private void BtnAddClient_Click(object sender, EventArgs e)
        {
            var AddClientForm = new AddClientForm();
            AddClientForm.Closed += (s, args) => this.Close();
            AddClientForm.Show();
            this.Hide();
        }
        private void BtnFindClient_Click(object sender, EventArgs e)
        {
            var UPManagerClientForm = new FindClientForm();
            UPManagerClientForm.Closed += (s, args) => this.Close();
            UPManagerClientForm.Show();
            this.Hide();
        }
        private void BtnWorkers_Click(object sender, EventArgs e)
        {
            var AddWorkerForm = new AddWorkerForm();
            AddWorkerForm.Closed += (s, args) => this.Close();
            AddWorkerForm.Show();
            this.Hide();
        }
        private void BtnFindWorker_Click(object sender, EventArgs e)
        {
            var FindWorkerForm = new FindWorkerForm();
            FindWorkerForm.Closed += (s, args) => this.Close();
            FindWorkerForm.Show();
            this.Hide();
        }
        private void BtnAddTour_Click(object sender, EventArgs e)
        {
            var AddtourForm = new AddTourForm();
            AddtourForm.Closed += (s, args) => this.Close();
            AddtourForm.Show();
            this.Hide();
        }
        private void BtnFindTour_Click(object sender, EventArgs e)
        {
            var UpdateTourForm = new FindTour();
            UpdateTourForm.Closed += (s, args) => this.Close();
            UpdateTourForm.Show();
            this.Hide();
        }
        /*hover and tooltip with mouse hover*/
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }
        private void PBUpDataManager_MouseHover(object sender, EventArgs e)
        {
            PBUpDataManager.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update your data", PBUpDataManager);
        }
        private void PBUpDataManager_MouseLeave(object sender, EventArgs e)
        {
            PBUpDataManager.BackColor = Color.Transparent;
        }

        private void PBAddCountries_MouseHover(object sender, EventArgs e)
        {
            PBAddCountries.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add country", PBAddCountries);
        }
        private void PBAddCountries_MouseLeave(object sender, EventArgs e)
        {
            PBAddCountries.BackColor = Color.Transparent;
        }
        private void PBAddClient_MouseHover(object sender, EventArgs e)
        {
            PBAddClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add client", PBAddClient);
        }
        private void PBAddClient_MouseLeave(object sender, EventArgs e)
        {
            PBAddClient.BackColor = Color.Transparent;
        }

        private void PBFindClient_MouseHover(object sender, EventArgs e)
        {
            PBFindClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find client", PBFindClient);
        }
        private void PBFindClient_MouseLeave(object sender, EventArgs e)
        {
            PBFindClient.BackColor = Color.Transparent;
        }
        private void PBAddWorker_MouseHover(object sender, EventArgs e)
        {
            PBAddWorker.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add Worker", PBAddWorker);
        }
        private void PBAddWorker_MouseLeave(object sender, EventArgs e)
        {
            PBAddWorker.BackColor = Color.Transparent;
        }

        private void PBFindWorkers_MouseHover(object sender, EventArgs e)
        {
            PBFindWorkers.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find Worker", PBFindWorkers);
        }
        private void PBFindWorkers_MouseLeave(object sender, EventArgs e)
        {
            PBFindWorkers.BackColor = Color.Transparent;
        }

        private void PBAddTour_MouseHover(object sender, EventArgs e)
        {
            PBAddTour.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add tour", PBAddTour);
        }
        private void PBAddTour_MouseLeave(object sender, EventArgs e)
        {
            PBAddTour.BackColor = Color.Transparent;
        }

        private void PBFindTour_MouseHover(object sender, EventArgs e)
        {
            PBFindTour.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find tour", PBFindTour);
        }
        private void PBFindTour_MouseLeave(object sender, EventArgs e)
        {
            PBFindTour.BackColor = Color.Transparent;
        }
        


        /*Fade timer*/
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }

        /*tooltip background*/
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
