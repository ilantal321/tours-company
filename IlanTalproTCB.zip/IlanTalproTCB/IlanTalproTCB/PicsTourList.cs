﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class PicsTourList
    {
        public List<PicsTours> PicTourl = new List<PicsTours>();
        /*
        constractor
        */
        public PicsTourList()
        {
            PicTourl.Clear();
            PicsTours t = new PicsTours();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Pics_Tours");
            while (dr.Read())
            {
                t = new PicsTours(int.Parse(dr["PKID"].ToString()), int.Parse(dr["TourID"].ToString()), dr["Pic_Name"].ToString());
                PicTourl.Add(t);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by tour id
        */
        public PicsTourList(string TourID)
        {
            PicTourl.Clear();
            PicsTours t = new PicsTours();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Pics_Tours where TourID="+TourID);
            while (dr.Read())
            {
                t = new PicsTours(int.Parse(dr["PKID"].ToString()), int.Parse(dr["TourID"].ToString()), dr["Pic_Name"].ToString());
                PicTourl.Add(t);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        get and set
        */
        public void SetTourPicList(List<PicsTours> t)
        {
            PicTourl = t;
        }
        public List<PicsTours> GetTourPicList()
        {
            return PicTourl;
        }
        /*
        change list by tour id
        */
        public List<PicsTours> FindPicByTourID(int tourID)
        {
            List<PicsTours> t = new List<PicsTours>();
            var result = from s in PicTourl where s.GetTourID() == tourID select s;
            foreach (var Tours in result)
            {
                t.Add(Tours);
            }
            return t;
        }
    }
}
