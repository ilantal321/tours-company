﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Security.Cryptography;

namespace IlanTalproTCB
{
    class WorkerList
    {
        public List<Worker> Workers = new List<Worker>();
        /*
        constrctor
        */
        public WorkerList()
        {
            Workers.Clear();
            Worker w = new Worker();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Workers  where NOT PKID=8 ORDER BY PKID");
            while (dr.Read())
            {
                w = new Worker(int.Parse(dr["PKID"].ToString()), dr["FirstName"].ToString(), dr["LastName"].ToString(), dr["Address"].ToString(), dr["Birthdate"].ToString(), dr["City"].ToString(), dr["UserName"].ToString(), dr["Passw"].ToString(), dr["Pic"].ToString(), dr["ID"].ToString(),int.Parse(dr["Salary"].ToString()), bool.Parse(dr["active"].ToString()));
                Workers.Add(w);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        set and get
        */
        public void SetWorkerList(List<Worker> w)
        {
            Workers = w;
        }
        public List<Worker> GetWorkerList()
        {
            return Workers;
        }
        /*
        find worker by id
        */
        public Worker FindWorkerbyID(string ID)
        {
            Worker w = new Worker();
            var result = from s in Workers where s.GetID() == ID select s;
            foreach (var Workers in result)
            {
                w = Workers;
            }
            return w;
        }
        /*
        find worker by username
        */
        public Worker FindWorkerbyUN(string UN)
        {
            Worker w = new Worker();
            var result = from s in Workers where s.GetUserName() == UN select s;
            foreach (var Workers in result)
            {
                w = Workers;
            }
            return w;
        }
    }

}
