﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    update Manager
    Manager can update his data
    */
    public partial class UpdateManagerForm : Form
    {
        sha1ceypto sh = new sha1ceypto();
        Function f1 = new Function();
        Myconn connec = new Myconn();
        Manager m = new Manager(LoginForm.PKID.ToString());
        public UpdateManagerForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                OFDAddPic.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
                TDate.Start();
                fillWorkerdata();
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill manager data in form
        */
        public void fillWorkerdata()
        {
            TBAddress.Text = m.GeteAddress();
            TBUsername.Text = m.GetUserName();
            TBLName.Text = m.GetLastName();
            TBFName.Text = m.GetFirstName();
            LShowSalary.Text = m.GetSalary().ToString();
            LAddDate.Text = m.GetADate().ToString("dd/MM/yyyy");
            TBCity.Text = m.GetCity();
            LShowAge.Text = m.GetBirthdate();
            LShowID.Text = m.GetID();
            PBClientPic.Image = Image.FromFile(@"Pic\Managers\" + m.GetPic());
            LPicName.Text = m.GetPic();
            TBJob.Text = m.GetJob();
            LShowDepartment.Text = m.GetDepartment();
        }
        /*
        date and clock
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        to last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            
            var ManagerMenuForm = new ManagerMenuForm();
            ManagerMenuForm.Closed += (s, args) => this.Close();
            ManagerMenuForm.Show();
            this.Hide();
        }
        /*
        update pic
        */
        private void PBUpdPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                if (!new System.IO.FileInfo(@"Pic\Managers\" + OFDAddPic.SafeFileName).Exists)
                {
                    System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Managers\" + OFDAddPic.SafeFileName);
                }
                PBClientPic.Image = Image.FromFile(@"Pic\Managers\" + OFDAddPic.SafeFileName);
                LPicName.Text = OFDAddPic.SafeFileName;
            }
        }
        /*
        update data
        */
        private void PBUpDateManager_Click_1(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "User name needs 8-4 characters long and first 3 characters are letters \n";
            }
            f1.CheckName(TBFName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "First name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckName(TBLName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Last name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckName(TBJob.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Job must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckAddress(TBAddress.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Address must have lest 6 chars long and no number in the first 3 chars and finish with number\n";
            }
            f1.CheckName(TBCity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "City must Start with Capital letter and more then 3 letters long\n";
            }
            if (LPicName.Text.Length < 2)
            {
                flag = false;
                str += "Add picture\n";
            }
            LError.Text = str;
            if (flag)
            {
                if (TBUsername.Text != m.GetUserName())
                {
                    f1.Checkdup(TBUsername.Text, "UserName", "Managers");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Manager with the same User name \n";
                    }
                }
                if (TBJob.Text != m.GetJob())
                {
                    f1.Checkdup(TBJob.Text, "Job", "Managers");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Manager with the same Job \n";
                    }
                }
                if (flag)
                {
                    m.SetUserName(TBUsername.Text);
                    m.SetFirstName(TBFName.Text);
                    m.SetLastName(TBLName.Text);
                    m.SetAddress(TBAddress.Text);
                    m.SetCity(TBCity.Text);
                    m.SetPic(LPicName.Text);
                    m.SetJob(TBJob.Text);
                    m.UpdateManagerToDB();
                    str = "User updated";
                }
                LError.Text = str;
            }
        }
        /*
        update password
        */
        private void PBUpDatePassword_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckPassword(TBNP.Text);
            if (f1.GetAnswer() == false)
            {
                str += "new Password must have 10 chars long \n";
            }
            else
            {
                string pass1 = sh.GetSHA1(TBOP.Text);
                if (pass1 == m.GetPassword())
                {
                    if (TBCNP.Text == TBNP.Text)
                    {
                        m.UpdateManagerPasswordToDB(sh.GetSHA1(TBNP.Text));
                        str = "Password Updated";
                        m = new Manager(LoginForm.PKID.ToString());
                    }
                    else
                    {
                        str = "New password and confirm password are not the same\n";
                    }
                }
                else
                {
                    str = "Old Password Wrong\n";
                }
            }
            LError.Text = str;
        }
        /*
        hover and tooltip mouse hover
        */
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }

        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor =Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }

        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor =Color.Transparent;
        }
        private void PBUpdPic_MouseHover(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update pic", PBUpdPic);
        }

        private void PBUpdPic_MouseLeave(object sender, EventArgs e)
        {
            PBUpdPic.BackColor =Color.Transparent;
        }

        private void PBUpDateClient_MouseHover(object sender, EventArgs e)
        {
            PBUpDateManager.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update data", PBUpDateManager);
        }

        private void PBUpDateClient_MouseLeave(object sender, EventArgs e)
        {
            PBUpDateManager.BackColor =Color.Transparent;
        }



        private void PBUpDatePassword_MouseHover(object sender, EventArgs e)
        {
            PBUpDatePassword.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Change password", PBUpDatePassword);
        }

        private void PBUpDatePassword_MouseLeave(object sender, EventArgs e)
        {
            PBUpDatePassword.BackColor =Color.Transparent;
        }
        /*
        fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tooltip background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
