﻿namespace IlanTalproTCB
{
    partial class ManagerMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManagerMenuForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.Lda = new System.Windows.Forms.Label();
            this.LAddCountries = new System.Windows.Forms.Label();
            this.PBAddCountries = new System.Windows.Forms.PictureBox();
            this.PBUpDataManager = new System.Windows.Forms.PictureBox();
            this.LUpdateData = new System.Windows.Forms.Label();
            this.LClients = new System.Windows.Forms.Label();
            this.LFindClient = new System.Windows.Forms.Label();
            this.PBFindClient = new System.Windows.Forms.PictureBox();
            this.PBAddClient = new System.Windows.Forms.PictureBox();
            this.LAddClient = new System.Windows.Forms.Label();
            this.LWorker = new System.Windows.Forms.Label();
            this.LFindWorker = new System.Windows.Forms.Label();
            this.PBAddWorker = new System.Windows.Forms.PictureBox();
            this.LAddWorker = new System.Windows.Forms.Label();
            this.PBFindWorkers = new System.Windows.Forms.PictureBox();
            this.LTours = new System.Windows.Forms.Label();
            this.LFindTour = new System.Windows.Forms.Label();
            this.PBFindTour = new System.Windows.Forms.PictureBox();
            this.PBAddTour = new System.Windows.Forms.PictureBox();
            this.LAddTour = new System.Windows.Forms.Label();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddCountries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpDataManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddWorker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindWorkers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindTour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddTour)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 9);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(0, 40);
            this.LHeader.TabIndex = 1;
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 761);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // Lda
            // 
            this.Lda.AutoSize = true;
            this.Lda.BackColor = System.Drawing.Color.Transparent;
            this.Lda.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lda.ForeColor = System.Drawing.Color.Black;
            this.Lda.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.Lda.Location = new System.Drawing.Point(54, 438);
            this.Lda.Name = "Lda";
            this.Lda.Size = new System.Drawing.Size(0, 29);
            this.Lda.TabIndex = 37;
            // 
            // LAddCountries
            // 
            this.LAddCountries.AutoSize = true;
            this.LAddCountries.BackColor = System.Drawing.Color.Transparent;
            this.LAddCountries.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddCountries.ForeColor = System.Drawing.Color.Black;
            this.LAddCountries.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddCountries.Location = new System.Drawing.Point(317, 61);
            this.LAddCountries.Name = "LAddCountries";
            this.LAddCountries.Size = new System.Drawing.Size(192, 40);
            this.LAddCountries.TabIndex = 88;
            this.LAddCountries.Text = "Add countries:";
            // 
            // PBAddCountries
            // 
            this.PBAddCountries.BackColor = System.Drawing.Color.Transparent;
            this.PBAddCountries.Image = ((System.Drawing.Image)(resources.GetObject("PBAddCountries.Image")));
            this.PBAddCountries.Location = new System.Drawing.Point(324, 119);
            this.PBAddCountries.Name = "PBAddCountries";
            this.PBAddCountries.Size = new System.Drawing.Size(150, 96);
            this.PBAddCountries.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddCountries.TabIndex = 87;
            this.PBAddCountries.TabStop = false;
            this.PBAddCountries.Click += new System.EventHandler(this.PBAddCountries_Click);
            this.PBAddCountries.MouseLeave += new System.EventHandler(this.PBAddCountries_MouseLeave);
            this.PBAddCountries.MouseHover += new System.EventHandler(this.PBAddCountries_MouseHover);
            // 
            // PBUpDataManager
            // 
            this.PBUpDataManager.BackColor = System.Drawing.Color.Transparent;
            this.PBUpDataManager.Image = ((System.Drawing.Image)(resources.GetObject("PBUpDataManager.Image")));
            this.PBUpDataManager.Location = new System.Drawing.Point(59, 119);
            this.PBUpDataManager.Name = "PBUpDataManager";
            this.PBUpDataManager.Size = new System.Drawing.Size(150, 96);
            this.PBUpDataManager.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBUpDataManager.TabIndex = 86;
            this.PBUpDataManager.TabStop = false;
            this.PBUpDataManager.Click += new System.EventHandler(this.PBUpDataManager_Click);
            this.PBUpDataManager.MouseLeave += new System.EventHandler(this.PBUpDataManager_MouseLeave);
            this.PBUpDataManager.MouseHover += new System.EventHandler(this.PBUpDataManager_MouseHover);
            // 
            // LUpdateData
            // 
            this.LUpdateData.AutoSize = true;
            this.LUpdateData.BackColor = System.Drawing.Color.Transparent;
            this.LUpdateData.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LUpdateData.ForeColor = System.Drawing.Color.Black;
            this.LUpdateData.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LUpdateData.Location = new System.Drawing.Point(52, 61);
            this.LUpdateData.Name = "LUpdateData";
            this.LUpdateData.Size = new System.Drawing.Size(235, 40);
            this.LUpdateData.TabIndex = 85;
            this.LUpdateData.Text = "Update your data:";
            // 
            // LClients
            // 
            this.LClients.AutoSize = true;
            this.LClients.BackColor = System.Drawing.Color.Transparent;
            this.LClients.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LClients.ForeColor = System.Drawing.Color.Black;
            this.LClients.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LClients.Location = new System.Drawing.Point(578, 24);
            this.LClients.Name = "LClients";
            this.LClients.Size = new System.Drawing.Size(109, 40);
            this.LClients.TabIndex = 94;
            this.LClients.Text = "Clients:";
            // 
            // LFindClient
            // 
            this.LFindClient.AutoSize = true;
            this.LFindClient.BackColor = System.Drawing.Color.Transparent;
            this.LFindClient.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFindClient.ForeColor = System.Drawing.Color.Black;
            this.LFindClient.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFindClient.Location = new System.Drawing.Point(850, 64);
            this.LFindClient.Name = "LFindClient";
            this.LFindClient.Size = new System.Drawing.Size(111, 40);
            this.LFindClient.TabIndex = 93;
            this.LFindClient.Text = "Search:";
            // 
            // PBFindClient
            // 
            this.PBFindClient.BackColor = System.Drawing.Color.Transparent;
            this.PBFindClient.Image = ((System.Drawing.Image)(resources.GetObject("PBFindClient.Image")));
            this.PBFindClient.Location = new System.Drawing.Point(857, 119);
            this.PBFindClient.Name = "PBFindClient";
            this.PBFindClient.Size = new System.Drawing.Size(150, 96);
            this.PBFindClient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFindClient.TabIndex = 92;
            this.PBFindClient.TabStop = false;
            this.PBFindClient.Click += new System.EventHandler(this.PBFindClient_Click);
            this.PBFindClient.MouseLeave += new System.EventHandler(this.PBFindClient_MouseLeave);
            this.PBFindClient.MouseHover += new System.EventHandler(this.PBFindClient_MouseHover);
            // 
            // PBAddClient
            // 
            this.PBAddClient.BackColor = System.Drawing.Color.Transparent;
            this.PBAddClient.Image = ((System.Drawing.Image)(resources.GetObject("PBAddClient.Image")));
            this.PBAddClient.Location = new System.Drawing.Point(585, 119);
            this.PBAddClient.Name = "PBAddClient";
            this.PBAddClient.Size = new System.Drawing.Size(150, 96);
            this.PBAddClient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddClient.TabIndex = 91;
            this.PBAddClient.TabStop = false;
            this.PBAddClient.Click += new System.EventHandler(this.PBAddClient_Click);
            this.PBAddClient.MouseLeave += new System.EventHandler(this.PBAddClient_MouseLeave);
            this.PBAddClient.MouseHover += new System.EventHandler(this.PBAddClient_MouseHover);
            // 
            // LAddClient
            // 
            this.LAddClient.AutoSize = true;
            this.LAddClient.BackColor = System.Drawing.Color.Transparent;
            this.LAddClient.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddClient.ForeColor = System.Drawing.Color.Black;
            this.LAddClient.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddClient.Location = new System.Drawing.Point(578, 64);
            this.LAddClient.Name = "LAddClient";
            this.LAddClient.Size = new System.Drawing.Size(73, 40);
            this.LAddClient.TabIndex = 90;
            this.LAddClient.Text = "Add:";
            // 
            // LWorker
            // 
            this.LWorker.AutoSize = true;
            this.LWorker.BackColor = System.Drawing.Color.Transparent;
            this.LWorker.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LWorker.ForeColor = System.Drawing.Color.Black;
            this.LWorker.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LWorker.Location = new System.Drawing.Point(52, 239);
            this.LWorker.Name = "LWorker";
            this.LWorker.Size = new System.Drawing.Size(127, 40);
            this.LWorker.TabIndex = 99;
            this.LWorker.Text = "Workers:";
            // 
            // LFindWorker
            // 
            this.LFindWorker.AutoSize = true;
            this.LFindWorker.BackColor = System.Drawing.Color.Transparent;
            this.LFindWorker.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFindWorker.ForeColor = System.Drawing.Color.Black;
            this.LFindWorker.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFindWorker.Location = new System.Drawing.Point(317, 279);
            this.LFindWorker.Name = "LFindWorker";
            this.LFindWorker.Size = new System.Drawing.Size(111, 40);
            this.LFindWorker.TabIndex = 98;
            this.LFindWorker.Text = "Search:";
            // 
            // PBAddWorker
            // 
            this.PBAddWorker.BackColor = System.Drawing.Color.Transparent;
            this.PBAddWorker.Image = ((System.Drawing.Image)(resources.GetObject("PBAddWorker.Image")));
            this.PBAddWorker.Location = new System.Drawing.Point(59, 329);
            this.PBAddWorker.Name = "PBAddWorker";
            this.PBAddWorker.Size = new System.Drawing.Size(150, 96);
            this.PBAddWorker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddWorker.TabIndex = 96;
            this.PBAddWorker.TabStop = false;
            this.PBAddWorker.Click += new System.EventHandler(this.PBAddWorker_Click);
            this.PBAddWorker.MouseLeave += new System.EventHandler(this.PBAddWorker_MouseLeave);
            this.PBAddWorker.MouseHover += new System.EventHandler(this.PBAddWorker_MouseHover);
            // 
            // LAddWorker
            // 
            this.LAddWorker.AutoSize = true;
            this.LAddWorker.BackColor = System.Drawing.Color.Transparent;
            this.LAddWorker.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddWorker.ForeColor = System.Drawing.Color.Black;
            this.LAddWorker.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddWorker.Location = new System.Drawing.Point(52, 279);
            this.LAddWorker.Name = "LAddWorker";
            this.LAddWorker.Size = new System.Drawing.Size(73, 40);
            this.LAddWorker.TabIndex = 95;
            this.LAddWorker.Text = "Add:";
            // 
            // PBFindWorkers
            // 
            this.PBFindWorkers.BackColor = System.Drawing.Color.Transparent;
            this.PBFindWorkers.Image = ((System.Drawing.Image)(resources.GetObject("PBFindWorkers.Image")));
            this.PBFindWorkers.Location = new System.Drawing.Point(324, 329);
            this.PBFindWorkers.Name = "PBFindWorkers";
            this.PBFindWorkers.Size = new System.Drawing.Size(150, 96);
            this.PBFindWorkers.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFindWorkers.TabIndex = 97;
            this.PBFindWorkers.TabStop = false;
            this.PBFindWorkers.Click += new System.EventHandler(this.PBFindWorkers_Click);
            this.PBFindWorkers.MouseLeave += new System.EventHandler(this.PBFindWorkers_MouseLeave);
            this.PBFindWorkers.MouseHover += new System.EventHandler(this.PBFindWorkers_MouseHover);
            // 
            // LTours
            // 
            this.LTours.AutoSize = true;
            this.LTours.BackColor = System.Drawing.Color.Transparent;
            this.LTours.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTours.ForeColor = System.Drawing.Color.Black;
            this.LTours.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTours.Location = new System.Drawing.Point(578, 239);
            this.LTours.Name = "LTours";
            this.LTours.Size = new System.Drawing.Size(95, 40);
            this.LTours.TabIndex = 104;
            this.LTours.Text = "Tours:";
            // 
            // LFindTour
            // 
            this.LFindTour.AutoSize = true;
            this.LFindTour.BackColor = System.Drawing.Color.Transparent;
            this.LFindTour.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFindTour.ForeColor = System.Drawing.Color.Black;
            this.LFindTour.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFindTour.Location = new System.Drawing.Point(850, 279);
            this.LFindTour.Name = "LFindTour";
            this.LFindTour.Size = new System.Drawing.Size(111, 40);
            this.LFindTour.TabIndex = 103;
            this.LFindTour.Text = "Search:";
            // 
            // PBFindTour
            // 
            this.PBFindTour.BackColor = System.Drawing.Color.Transparent;
            this.PBFindTour.Image = ((System.Drawing.Image)(resources.GetObject("PBFindTour.Image")));
            this.PBFindTour.Location = new System.Drawing.Point(857, 329);
            this.PBFindTour.Name = "PBFindTour";
            this.PBFindTour.Size = new System.Drawing.Size(150, 96);
            this.PBFindTour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFindTour.TabIndex = 102;
            this.PBFindTour.TabStop = false;
            this.PBFindTour.Click += new System.EventHandler(this.PBFindTour_Click);
            this.PBFindTour.MouseLeave += new System.EventHandler(this.PBFindTour_MouseLeave);
            this.PBFindTour.MouseHover += new System.EventHandler(this.PBFindTour_MouseHover);
            // 
            // PBAddTour
            // 
            this.PBAddTour.BackColor = System.Drawing.Color.Transparent;
            this.PBAddTour.Image = ((System.Drawing.Image)(resources.GetObject("PBAddTour.Image")));
            this.PBAddTour.Location = new System.Drawing.Point(585, 329);
            this.PBAddTour.Name = "PBAddTour";
            this.PBAddTour.Size = new System.Drawing.Size(150, 96);
            this.PBAddTour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddTour.TabIndex = 101;
            this.PBAddTour.TabStop = false;
            this.PBAddTour.Click += new System.EventHandler(this.PBAddTour_Click);
            this.PBAddTour.MouseLeave += new System.EventHandler(this.PBAddTour_MouseLeave);
            this.PBAddTour.MouseHover += new System.EventHandler(this.PBAddTour_MouseHover);
            // 
            // LAddTour
            // 
            this.LAddTour.AutoSize = true;
            this.LAddTour.BackColor = System.Drawing.Color.Transparent;
            this.LAddTour.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddTour.ForeColor = System.Drawing.Color.Black;
            this.LAddTour.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddTour.Location = new System.Drawing.Point(578, 279);
            this.LAddTour.Name = "LAddTour";
            this.LAddTour.Size = new System.Drawing.Size(73, 40);
            this.LAddTour.TabIndex = 100;
            this.LAddTour.Text = "Add:";
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // ManagerMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.LTours);
            this.Controls.Add(this.LFindTour);
            this.Controls.Add(this.PBFindTour);
            this.Controls.Add(this.PBAddTour);
            this.Controls.Add(this.LAddTour);
            this.Controls.Add(this.LWorker);
            this.Controls.Add(this.LFindWorker);
            this.Controls.Add(this.PBFindWorkers);
            this.Controls.Add(this.PBAddWorker);
            this.Controls.Add(this.LAddWorker);
            this.Controls.Add(this.LClients);
            this.Controls.Add(this.LFindClient);
            this.Controls.Add(this.PBFindClient);
            this.Controls.Add(this.PBAddClient);
            this.Controls.Add(this.LAddClient);
            this.Controls.Add(this.LAddCountries);
            this.Controls.Add(this.PBAddCountries);
            this.Controls.Add(this.PBUpDataManager);
            this.Controls.Add(this.LUpdateData);
            this.Controls.Add(this.Lda);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ManagerMenuForm";
            this.Text = "Manager menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddCountries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpDataManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddWorker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindWorkers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindTour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddTour)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.Label Lda;
        private System.Windows.Forms.Label LAddCountries;
        private System.Windows.Forms.PictureBox PBAddCountries;
        private System.Windows.Forms.PictureBox PBUpDataManager;
        private System.Windows.Forms.Label LUpdateData;
        private System.Windows.Forms.Label LClients;
        private System.Windows.Forms.Label LFindClient;
        private System.Windows.Forms.PictureBox PBFindClient;
        private System.Windows.Forms.PictureBox PBAddClient;
        private System.Windows.Forms.Label LAddClient;
        private System.Windows.Forms.Label LWorker;
        private System.Windows.Forms.Label LFindWorker;
        private System.Windows.Forms.PictureBox PBAddWorker;
        private System.Windows.Forms.Label LAddWorker;
        private System.Windows.Forms.PictureBox PBFindWorkers;
        private System.Windows.Forms.Label LTours;
        private System.Windows.Forms.Label LFindTour;
        private System.Windows.Forms.PictureBox PBFindTour;
        private System.Windows.Forms.PictureBox PBAddTour;
        private System.Windows.Forms.Label LAddTour;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}