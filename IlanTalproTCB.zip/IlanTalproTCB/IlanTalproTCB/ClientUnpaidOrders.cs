﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    in this form client can pay his unpaid orders
    he get a list of his unpaid orders
    workers and managers can cancel orders and the tour add places to the tour
    */
    public partial class ClientUnpaidOrders : Form
    {
        Function f1 = new Function();
        Myconn connec = new Myconn();
        Receipt r = new Receipt();
        ReceiptList rl = new ReceiptList();
        Country con = new Country();
        int i = 0;
        public ClientUnpaidOrders()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                if (LoginForm.Permission == "Client")
                {
                    rl.BuildReceiptsByClientUnpaid(LoginForm.PKID);
                    PBDeleteOrder.Visible = false;
                }
                else
                {
                    rl.BuildReceiptsByClientUnpaid(FindClientForm.clientid);
                }
                if (rl.GetReceiptsList().Count != 0)
                {
                    r = rl.GetReceiptsList()[i];
                    FillCBReceipt();
                }
                else
                {
                    PBPayOrder.Visible = false;
                    PBPlus.Visible = false;
                    PBMinus.Visible = false;
                    CBReceiptList.Visible = false;
                    PBDeleteOrder.Visible = false;
                    LHeader.Text = "There Not Unpaid Orders";
                }
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill unpaid orders combo box
        */
        public void FillCBReceipt()
        {
            CBReceiptList.Items.Clear();
            foreach (Receipt i in rl.GetReceiptsList())
            {
                CBReceiptList.Items.Add("Order:"+i.GetOrder().GetOrderNumber() + " On:" + i.GetTour().GetDate() + " To:" + con.GetCountryName() + " Number of people:" + i.GetOrder().GetQuantity() + " Price:" + i.GetTour().GetPrice()+" Total Price:"+(i.GetTour().GetPrice()* i.GetOrder().GetQuantity()));
            }
            CBReceiptList.SelectedIndex = i;
        }
        /*
        put order data in the form
        */
        public void fillReceiptdata()
        {
            LRTourName.Text = r.GetTour().GetTourname();
            LRTourDate.Text = r.GetTour().GetDate()+ r.GetTour().GetTimeHM();
            LRCountry.Text = con.GetCountryName();
            LRDays.Text = r.GetTour().GetDay().ToString();
            LRFlight_number.Text = r.GetTour().GetFlight_numberID();
            if (r.GetWorker().GetPKID() == 4)
            {
                LRWName.Text = "Client ordered the tour";
            }
            else
            {
                LRWName.Text = r.GetWorker().GetFirstName() + " " + r.GetWorker().GetLastName();
            }
            LRPrice.Text = r.GetTour().GetPrice().ToString()+"$";
            LRPlaces.Text = r.GetOrder().GetQuantity().ToString();
            LRTotal.Text = (r.GetTour().GetPrice() * r.GetOrder().GetQuantity()).ToString()+"$";
            if (r.GetOrder().GetActive())
            {
                LRActive.Text = "Order Active";
                PBPayOrder.Visible = true;
                if (LoginForm.Permission == "Client")
                {
                    PBDeleteOrder.Visible = false;
                }
                else
                {
                    PBDeleteOrder.Visible = true;
                }
            }
            else
            {
                LRActive.Text = "Order Inactive";
                PBPayOrder.Visible = false;
                PBDeleteOrder.Visible = false;
            }
        }
        /*
        if no orders in the list it empty the form
        */
        public void ClearReceiptdata()
        {
            LRTourName.Text = "";
            LRTourDate.Text = "";
            LRCountry.Text = "";
            LRDays.Text = "";
            LRFlight_number.Text = "";
            LRWName.Text = "";
            LRPrice.Text = "";
            LRPlaces.Text = "";
            LRTotal.Text = "";
            PBPayOrder.Visible = false;
            PBPlus.Visible = false;
            PBMinus.Visible = false;
            CBReceiptList.Visible = false;
        }
        /*
        date and clock
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        move to last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            if (LoginForm.Permission == "Client")
            {
                var ClientMenuForm = new ClientMenuForm();
                ClientMenuForm.Closed += (s, args) => this.Close();
                ClientMenuForm.Show();
                this.Hide();
            }
            else
            {
                var FindClientForm = new FindClientForm();
                FindClientForm.Closed += (s, args) => this.Close();
                FindClientForm.Show();
                this.Hide();
            }
        }
        /*
        move orders
        */
        private void PBPlus_Click(object sender, EventArgs e)
        {
            i++;
            if (i == rl.GetReceiptsList().Count)
            {
                i = 0;
            }
            r = rl.GetReceiptsList()[i];
            CBReceiptList.SelectedIndex = i;
        }
        private void PBMinus_Click(object sender, EventArgs e)
        {
            i--;
            if (i < 0)
            {
                i = rl.GetReceiptsList().Count - 1;
            }
            r = rl.GetReceiptsList()[i];
            CBReceiptList.SelectedIndex = i;
        }
        /*
        pay orders
        */
        private void PBPayOrder_Click(object sender, EventArgs e)
        {
            r.GetOrder().PayOrder();
            rl.GetReceiptsList().RemoveAt(i);
            CBReceiptList.Items.RemoveAt(i);
            if (rl.GetReceiptsList().Count == 0)
            {
                PBPayOrder.Visible = false;
                LHeader.Text = "There Not Unpaid Orders";
                ClearReceiptdata();
                CBReceiptList.ResetText();
                CBReceiptList.Items.Clear();
            }
            else
            {
                i = 0;
                r = rl.GetReceiptsList()[i];
                CBReceiptList.SelectedIndex = i;
            }
        }
        /*
        Delete orders
        */
        private void PBDeleteOrder_Click(object sender, EventArgs e)
        {
            r.GetOrder().UnActiveOrder();
            rl.GetReceiptsList()[i].GetTour().SetCapacity(rl.GetReceiptsList()[i].GetTour().GetCapacity() + rl.GetReceiptsList()[i].GetOrder().GetQuantity());
            rl.GetReceiptsList()[i].GetTour().UpdateCapacity();
            rl.GetReceiptsList()[i].GetOrder().SetActive(false);
            r = rl.GetReceiptsList()[i];
            fillReceiptdata();
        }
        /*
        mouse hover
        */
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }


        private void PBON_MouseHover(object sender, EventArgs e)
        {
            PBPayOrder.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Pay order", PBPayOrder);
        }
        private void PBON_MouseLeave(object sender, EventArgs e)
        {
            PBPayOrder.BackColor = Color.Transparent;
        }

        private void PBMinus_MouseHover(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Last order", PBMinus);
        }

        private void PBMinus_MouseLeave(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.Transparent;
        }

        private void PBPlus_MouseHover(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Next order", PBPlus);
        }

        private void PBPlus_MouseLeave(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.Transparent;
        }

        private void PBDeleteOrder_MouseHover(object sender, EventArgs e)
        {
            PBDeleteOrder.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Cancel order", PBDeleteOrder);
        }
        private void PBDeleteOrder_MouseLeave(object sender, EventArgs e)
        {
            PBDeleteOrder.BackColor = Color.Transparent;
        }
        /*
        Change item in Receipt List
        */
        private void CBReceiptList_SelectedIndexChanged(object sender, EventArgs e)
        {
            i = CBReceiptList.SelectedIndex;
            r = rl.GetReceiptsList()[i];
            con = new Country(r.GetTour().GetCountry());
            fillReceiptdata();
        }
        /*
        fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        Tooltip backgound
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
