﻿namespace IlanTalproTCB
{
    partial class AddCountryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCountryForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.LPassword = new System.Windows.Forms.Label();
            this.TBCountryName = new System.Windows.Forms.TextBox();
            this.LCountryName = new System.Windows.Forms.Label();
            this.CBContinent = new System.Windows.Forms.ComboBox();
            this.PBAddCountry = new System.Windows.Forms.PictureBox();
            this.LError = new System.Windows.Forms.Label();
            this.CBCountrys = new System.Windows.Forms.ComboBox();
            this.LCN = new System.Windows.Forms.Label();
            this.PBUpdateCountry = new System.Windows.Forms.PictureBox();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddCountry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpdateCountry)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 9);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(169, 40);
            this.LHeader.TabIndex = 1;
            this.LHeader.Text = "Add Country";
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 761);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // LPassword
            // 
            this.LPassword.AutoSize = true;
            this.LPassword.BackColor = System.Drawing.Color.Transparent;
            this.LPassword.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPassword.ForeColor = System.Drawing.Color.Black;
            this.LPassword.Location = new System.Drawing.Point(14, 126);
            this.LPassword.Name = "LPassword";
            this.LPassword.Size = new System.Drawing.Size(101, 29);
            this.LPassword.TabIndex = 17;
            this.LPassword.Text = "Continent:";
            // 
            // TBCountryName
            // 
            this.TBCountryName.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBCountryName.Location = new System.Drawing.Point(181, 89);
            this.TBCountryName.MaxLength = 25;
            this.TBCountryName.Name = "TBCountryName";
            this.TBCountryName.Size = new System.Drawing.Size(151, 27);
            this.TBCountryName.TabIndex = 16;
            // 
            // LCountryName
            // 
            this.LCountryName.AutoSize = true;
            this.LCountryName.BackColor = System.Drawing.Color.Transparent;
            this.LCountryName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCountryName.ForeColor = System.Drawing.Color.Black;
            this.LCountryName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCountryName.Location = new System.Drawing.Point(14, 87);
            this.LCountryName.Name = "LCountryName";
            this.LCountryName.Size = new System.Drawing.Size(143, 29);
            this.LCountryName.TabIndex = 15;
            this.LCountryName.Text = "Country Name:";
            // 
            // CBContinent
            // 
            this.CBContinent.FormattingEnabled = true;
            this.CBContinent.Location = new System.Drawing.Point(181, 129);
            this.CBContinent.Name = "CBContinent";
            this.CBContinent.Size = new System.Drawing.Size(151, 24);
            this.CBContinent.TabIndex = 18;
            this.CBContinent.SelectedIndexChanged += new System.EventHandler(this.CBContinent_SelectedIndexChanged);
            // 
            // PBAddCountry
            // 
            this.PBAddCountry.BackColor = System.Drawing.Color.Transparent;
            this.PBAddCountry.Image = ((System.Drawing.Image)(resources.GetObject("PBAddCountry.Image")));
            this.PBAddCountry.Location = new System.Drawing.Point(181, 174);
            this.PBAddCountry.Name = "PBAddCountry";
            this.PBAddCountry.Size = new System.Drawing.Size(96, 88);
            this.PBAddCountry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddCountry.TabIndex = 19;
            this.PBAddCountry.TabStop = false;
            this.PBAddCountry.Click += new System.EventHandler(this.PBAddCountry_Click);
            this.PBAddCountry.MouseLeave += new System.EventHandler(this.PBAddCountry_MouseLeave);
            this.PBAddCountry.MouseHover += new System.EventHandler(this.PBAddCountry_MouseHover);
            // 
            // LError
            // 
            this.LError.AutoSize = true;
            this.LError.BackColor = System.Drawing.Color.Transparent;
            this.LError.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LError.ForeColor = System.Drawing.Color.Black;
            this.LError.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LError.Location = new System.Drawing.Point(391, 89);
            this.LError.Name = "LError";
            this.LError.Size = new System.Drawing.Size(0, 29);
            this.LError.TabIndex = 64;
            // 
            // CBCountrys
            // 
            this.CBCountrys.FormattingEnabled = true;
            this.CBCountrys.Location = new System.Drawing.Point(181, 299);
            this.CBCountrys.Name = "CBCountrys";
            this.CBCountrys.Size = new System.Drawing.Size(151, 24);
            this.CBCountrys.TabIndex = 65;
            this.CBCountrys.SelectedIndexChanged += new System.EventHandler(this.CBCountrys_SelectedIndexChanged);
            // 
            // LCN
            // 
            this.LCN.AutoSize = true;
            this.LCN.BackColor = System.Drawing.Color.Transparent;
            this.LCN.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCN.ForeColor = System.Drawing.Color.Black;
            this.LCN.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCN.Location = new System.Drawing.Point(14, 294);
            this.LCN.Name = "LCN";
            this.LCN.Size = new System.Drawing.Size(143, 29);
            this.LCN.TabIndex = 66;
            this.LCN.Text = "Country Name:";
            // 
            // PBUpdateCountry
            // 
            this.PBUpdateCountry.BackColor = System.Drawing.Color.Transparent;
            this.PBUpdateCountry.Image = ((System.Drawing.Image)(resources.GetObject("PBUpdateCountry.Image")));
            this.PBUpdateCountry.Location = new System.Drawing.Point(309, 174);
            this.PBUpdateCountry.Name = "PBUpdateCountry";
            this.PBUpdateCountry.Size = new System.Drawing.Size(96, 88);
            this.PBUpdateCountry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBUpdateCountry.TabIndex = 67;
            this.PBUpdateCountry.TabStop = false;
            this.PBUpdateCountry.Click += new System.EventHandler(this.PBUpdateCountry_Click);
            this.PBUpdateCountry.MouseLeave += new System.EventHandler(this.PBUpdateCountry_MouseLeave);
            this.PBUpdateCountry.MouseHover += new System.EventHandler(this.PBUpdateCountry_MouseHover);
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // AddCountryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.PBUpdateCountry);
            this.Controls.Add(this.LCN);
            this.Controls.Add(this.CBCountrys);
            this.Controls.Add(this.LError);
            this.Controls.Add(this.PBAddCountry);
            this.Controls.Add(this.CBContinent);
            this.Controls.Add(this.LPassword);
            this.Controls.Add(this.TBCountryName);
            this.Controls.Add(this.LCountryName);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddCountryForm";
            this.Text = "Add Country";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddCountry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpdateCountry)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.Label LPassword;
        private System.Windows.Forms.TextBox TBCountryName;
        private System.Windows.Forms.Label LCountryName;
        private System.Windows.Forms.ComboBox CBContinent;
        private System.Windows.Forms.PictureBox PBAddCountry;
        private System.Windows.Forms.Label LError;
        private System.Windows.Forms.ComboBox CBCountrys;
        private System.Windows.Forms.Label LCN;
        private System.Windows.Forms.PictureBox PBUpdateCountry;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}