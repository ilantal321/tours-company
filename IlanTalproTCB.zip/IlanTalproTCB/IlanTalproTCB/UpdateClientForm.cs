﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    update client form
    client can update his data
    */
    public partial class UpdateClientForm : Form
    {
        sha1ceypto sh = new sha1ceypto();
        Function f1 = new Function();
        Myconn connec = new Myconn();
        Client c = new Client(LoginForm.PKID.ToString());
        public UpdateClientForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
                OFDAddPic.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";//filter to get only picters
                TDate.Start();
                fillClientdata();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill client data in the form
        */
        public void fillClientdata()
        {
            TBAddress.Text = c.GeteAddress();
            TBUsername.Text = c.GetUserName();
            TBLName.Text = c.GetLastName();
            TBFName.Text = c.GetFirstName();
            TBEmail.Text = c.GetMail();
            TBPhone.Text = c.GetPhoneNumber();
            TBCity.Text = c.GetCity();
            LShowAge.Text = c.GetBirthdate();
            LShowID.Text = c.GetID();
            PBClientPic.Image = Image.FromFile(@"Pic\Clients\" + c.GetPic());
            LPicName.Text = c.GetPic();
        }
        /*
        date and clock
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        Exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            
            var ClientMenuForm = new ClientMenuForm();
            ClientMenuForm.Closed += (s, args) => this.Close();
            ClientMenuForm.Show();
            this.Hide();
        }
        /*
        put new pic
        */
        private void PBUpdPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                if (!new System.IO.FileInfo(@"Pic\Clients\" + OFDAddPic.SafeFileName).Exists)
                {
                    System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Clients\" + OFDAddPic.SafeFileName);
                }
                PBClientPic.Image = Image.FromFile(@"Pic\Clients\" + OFDAddPic.SafeFileName);
                LPicName.Text = OFDAddPic.SafeFileName;
            }
        }
        /*
        update client
        cheack input first and phone number,email,username duplicate
        */
        private void PBUpDateClient_Click(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "User name needs 8-4 characters long and first 3 characters are letters \n";
            }
            f1.CheckPhone(TBPhone.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Phone must have 10 digits\n";
            }
            f1.CheckName(TBFName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "First name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckName(TBLName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Last name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckAddress(TBAddress.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Address must have lest 6 characters long and no number in the first 3 characters and finish with number\n";
            }
            f1.CheckName(TBCity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "City Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckEmail(TBEmail.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Wrong Email\n";
            }
            if (LPicName.Text.Length < 2)
            {
                flag = false;
                str += "Add picture\n";
            }
            LError.Text = str;
            if (flag)
            {
                if (TBUsername.Text != c.GetUserName())
                {
                    f1.Checkdup(TBUsername.Text, "UserName", "Clients");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Client with the same User name \n";
                    }
                }
                if (TBEmail.Text!=c.GetMail())
                {
                    f1.Checkdup(TBEmail.Text, "Email", "Clients");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Client with the same Email \n";
                    }
                }
                if (TBPhone.Text != c.GetPhoneNumber())
                {
                    f1.Checkdup(TBPhone.Text, "PhoneNumber", "Clients");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Client with the same Phone Number \n";
                    }
                }
                if (flag)
                {
                    c.SetUserName(TBUsername.Text);
                    c.SetFirstName(TBFName.Text);
                    c.SetLastName(TBLName.Text);
                    c.SetAddress(TBAddress.Text);
                    c.SetCity(TBCity.Text);
                    c.SetMail(TBEmail.Text);
                    c.SetPhoneNumber(TBPhone.Text);
                    c.SetPic(LPicName.Text);

                    c.UpdateClientToDB();
                    str = "User updated";
                }
                LError.Text = str;
            }
        }
        /*
        update password
        */
        private void PBUpDatePassword_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckPassword(TBNP.Text);
            if (f1.GetAnswer() == false)
            {
                str += "New Password must be 10 characters long \n";
            }
            else
            {
                string pass1 = sh.GetSHA1(TBOP.Text);
                if (pass1 == c.GetPassword())
                {
                    if (TBCNP.Text == TBNP.Text)
                    {
                        c.UpdateClientPasswordToDB(sh.GetSHA1(TBNP.Text));
                        str = "Password Updated";
                        c = new Client("Select * from Clients where PKID=" + LoginForm.PKID.ToString() + "");
                    }
                    else
                    {
                        str = "New password and confirm password are not the same\n";
                    }
                }
                else
                {
                    str = "Old Password Wrong\n";
                }
            }
            LError.Text = str;
        }
        /*
        phone get only digits
        */
        private void TBPhone_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        /*
        hover and tooltip with mouse
        */
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }
        private void PBUpdPic_MouseHover(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add Pic", PBUpdPic);
        }

        private void PBUpdPic_MouseLeave(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.Transparent;
        }

        private void PBUpDateClient_MouseHover(object sender, EventArgs e)
        {
            PBUpDateClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update User", PBUpDateClient);
        }
        private void PBUpDateClient_MouseLeave(object sender, EventArgs e)
        {
            PBUpDateClient.BackColor = Color.Transparent;
        }

        private void PBUpDatePassword_MouseHover(object sender, EventArgs e)
        {
            PBUpDatePassword.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Change Passwoord", PBUpDatePassword);
        }
        private void PBUpDatePassword_MouseLeave(object sender, EventArgs e)
        {
            PBUpDatePassword.BackColor = Color.Transparent;
        }
        /*
        fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*tooltip background*/
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
