﻿namespace IlanTalproTCB
{
    partial class AddClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddClientForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.LUserName = new System.Windows.Forms.Label();
            this.TBUsername = new System.Windows.Forms.TextBox();
            this.TBPassword = new System.Windows.Forms.TextBox();
            this.LPassword = new System.Windows.Forms.Label();
            this.TBFName = new System.Windows.Forms.TextBox();
            this.LFName = new System.Windows.Forms.Label();
            this.TBLName = new System.Windows.Forms.TextBox();
            this.LLastName = new System.Windows.Forms.Label();
            this.TBCity = new System.Windows.Forms.TextBox();
            this.LCity = new System.Windows.Forms.Label();
            this.TBAddress = new System.Windows.Forms.TextBox();
            this.LAddress = new System.Windows.Forms.Label();
            this.TBID = new System.Windows.Forms.TextBox();
            this.LID = new System.Windows.Forms.Label();
            this.LBirthdate = new System.Windows.Forms.Label();
            this.TBEmail = new System.Windows.Forms.TextBox();
            this.LEmail = new System.Windows.Forms.Label();
            this.TBPhone = new System.Windows.Forms.TextBox();
            this.LPhone = new System.Windows.Forms.Label();
            this.LPic = new System.Windows.Forms.Label();
            this.PBAddPic = new System.Windows.Forms.PictureBox();
            this.PBClientPic = new System.Windows.Forms.PictureBox();
            this.PBAddClient = new System.Windows.Forms.PictureBox();
            this.OFDAddPic = new System.Windows.Forms.OpenFileDialog();
            this.LPicName = new System.Windows.Forms.Label();
            this.LError = new System.Windows.Forms.Label();
            this.LAddClientShow = new System.Windows.Forms.Label();
            this.DTPClentBD = new System.Windows.Forms.DateTimePicker();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddClient)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 9);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(301, 40);
            this.LHeader.TabIndex = 1;
            this.LHeader.Text = "Enter Data to join client";
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1069, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 761);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // LUserName
            // 
            this.LUserName.AutoSize = true;
            this.LUserName.BackColor = System.Drawing.Color.Transparent;
            this.LUserName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LUserName.ForeColor = System.Drawing.Color.Black;
            this.LUserName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LUserName.Location = new System.Drawing.Point(14, 68);
            this.LUserName.Name = "LUserName";
            this.LUserName.Size = new System.Drawing.Size(117, 29);
            this.LUserName.TabIndex = 10;
            this.LUserName.Text = "User Name:";
            // 
            // TBUsername
            // 
            this.TBUsername.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBUsername.Location = new System.Drawing.Point(137, 70);
            this.TBUsername.MaxLength = 8;
            this.TBUsername.Name = "TBUsername";
            this.TBUsername.Size = new System.Drawing.Size(151, 27);
            this.TBUsername.TabIndex = 12;
            // 
            // TBPassword
            // 
            this.TBPassword.Font = new System.Drawing.Font("Arial Narrow", 10.2F);
            this.TBPassword.Location = new System.Drawing.Point(137, 109);
            this.TBPassword.MaxLength = 10;
            this.TBPassword.Name = "TBPassword";
            this.TBPassword.PasswordChar = '*';
            this.TBPassword.Size = new System.Drawing.Size(151, 27);
            this.TBPassword.TabIndex = 14;
            // 
            // LPassword
            // 
            this.LPassword.AutoSize = true;
            this.LPassword.BackColor = System.Drawing.Color.Transparent;
            this.LPassword.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPassword.ForeColor = System.Drawing.Color.Black;
            this.LPassword.Location = new System.Drawing.Point(14, 107);
            this.LPassword.Name = "LPassword";
            this.LPassword.Size = new System.Drawing.Size(106, 29);
            this.LPassword.TabIndex = 13;
            this.LPassword.Text = "Password:";
            // 
            // TBFName
            // 
            this.TBFName.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBFName.Location = new System.Drawing.Point(561, 70);
            this.TBFName.MaxLength = 15;
            this.TBFName.Name = "TBFName";
            this.TBFName.Size = new System.Drawing.Size(151, 27);
            this.TBFName.TabIndex = 16;
            // 
            // LFName
            // 
            this.LFName.AutoSize = true;
            this.LFName.BackColor = System.Drawing.Color.Transparent;
            this.LFName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFName.ForeColor = System.Drawing.Color.Black;
            this.LFName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFName.Location = new System.Drawing.Point(438, 68);
            this.LFName.Name = "LFName";
            this.LFName.Size = new System.Drawing.Size(113, 29);
            this.LFName.TabIndex = 15;
            this.LFName.Text = "First Name:";
            // 
            // TBLName
            // 
            this.TBLName.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBLName.Location = new System.Drawing.Point(561, 109);
            this.TBLName.MaxLength = 15;
            this.TBLName.Name = "TBLName";
            this.TBLName.Size = new System.Drawing.Size(151, 27);
            this.TBLName.TabIndex = 18;
            // 
            // LLastName
            // 
            this.LLastName.AutoSize = true;
            this.LLastName.BackColor = System.Drawing.Color.Transparent;
            this.LLastName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LLastName.ForeColor = System.Drawing.Color.Black;
            this.LLastName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LLastName.Location = new System.Drawing.Point(438, 107);
            this.LLastName.Name = "LLastName";
            this.LLastName.Size = new System.Drawing.Size(112, 29);
            this.LLastName.TabIndex = 17;
            this.LLastName.Text = "Last Name:";
            // 
            // TBCity
            // 
            this.TBCity.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBCity.Location = new System.Drawing.Point(561, 189);
            this.TBCity.MaxLength = 25;
            this.TBCity.Name = "TBCity";
            this.TBCity.Size = new System.Drawing.Size(151, 27);
            this.TBCity.TabIndex = 22;
            // 
            // LCity
            // 
            this.LCity.AutoSize = true;
            this.LCity.BackColor = System.Drawing.Color.Transparent;
            this.LCity.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCity.ForeColor = System.Drawing.Color.Black;
            this.LCity.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCity.Location = new System.Drawing.Point(438, 187);
            this.LCity.Name = "LCity";
            this.LCity.Size = new System.Drawing.Size(50, 29);
            this.LCity.TabIndex = 21;
            this.LCity.Text = "City:";
            // 
            // TBAddress
            // 
            this.TBAddress.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBAddress.Location = new System.Drawing.Point(561, 150);
            this.TBAddress.MaxLength = 40;
            this.TBAddress.Name = "TBAddress";
            this.TBAddress.Size = new System.Drawing.Size(151, 27);
            this.TBAddress.TabIndex = 20;
            // 
            // LAddress
            // 
            this.LAddress.AutoSize = true;
            this.LAddress.BackColor = System.Drawing.Color.Transparent;
            this.LAddress.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddress.ForeColor = System.Drawing.Color.Black;
            this.LAddress.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddress.Location = new System.Drawing.Point(438, 148);
            this.LAddress.Name = "LAddress";
            this.LAddress.Size = new System.Drawing.Size(91, 29);
            this.LAddress.TabIndex = 19;
            this.LAddress.Text = "Address:";
            // 
            // TBID
            // 
            this.TBID.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBID.Location = new System.Drawing.Point(137, 152);
            this.TBID.MaxLength = 9;
            this.TBID.Name = "TBID";
            this.TBID.Size = new System.Drawing.Size(151, 27);
            this.TBID.TabIndex = 26;
            this.TBID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBID_KeyPress);
            // 
            // LID
            // 
            this.LID.AutoSize = true;
            this.LID.BackColor = System.Drawing.Color.Transparent;
            this.LID.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LID.ForeColor = System.Drawing.Color.Black;
            this.LID.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LID.Location = new System.Drawing.Point(14, 150);
            this.LID.Name = "LID";
            this.LID.Size = new System.Drawing.Size(36, 29);
            this.LID.TabIndex = 25;
            this.LID.Text = "ID:";
            // 
            // LBirthdate
            // 
            this.LBirthdate.AutoSize = true;
            this.LBirthdate.BackColor = System.Drawing.Color.Transparent;
            this.LBirthdate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBirthdate.ForeColor = System.Drawing.Color.Black;
            this.LBirthdate.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LBirthdate.Location = new System.Drawing.Point(438, 230);
            this.LBirthdate.Name = "LBirthdate";
            this.LBirthdate.Size = new System.Drawing.Size(96, 29);
            this.LBirthdate.TabIndex = 23;
            this.LBirthdate.Text = "Birthdate:";
            // 
            // TBEmail
            // 
            this.TBEmail.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBEmail.Location = new System.Drawing.Point(137, 193);
            this.TBEmail.MaxLength = 40;
            this.TBEmail.Name = "TBEmail";
            this.TBEmail.Size = new System.Drawing.Size(151, 27);
            this.TBEmail.TabIndex = 28;
            // 
            // LEmail
            // 
            this.LEmail.AutoSize = true;
            this.LEmail.BackColor = System.Drawing.Color.Transparent;
            this.LEmail.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LEmail.ForeColor = System.Drawing.Color.Black;
            this.LEmail.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LEmail.Location = new System.Drawing.Point(14, 191);
            this.LEmail.Name = "LEmail";
            this.LEmail.Size = new System.Drawing.Size(66, 29);
            this.LEmail.TabIndex = 27;
            this.LEmail.Text = "Email:";
            // 
            // TBPhone
            // 
            this.TBPhone.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBPhone.Location = new System.Drawing.Point(137, 234);
            this.TBPhone.MaxLength = 10;
            this.TBPhone.Name = "TBPhone";
            this.TBPhone.Size = new System.Drawing.Size(151, 27);
            this.TBPhone.TabIndex = 30;
            this.TBPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBPhone_KeyPress);
            // 
            // LPhone
            // 
            this.LPhone.AutoSize = true;
            this.LPhone.BackColor = System.Drawing.Color.Transparent;
            this.LPhone.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPhone.ForeColor = System.Drawing.Color.Black;
            this.LPhone.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPhone.Location = new System.Drawing.Point(14, 232);
            this.LPhone.Name = "LPhone";
            this.LPhone.Size = new System.Drawing.Size(75, 29);
            this.LPhone.TabIndex = 29;
            this.LPhone.Text = "Phone:";
            // 
            // LPic
            // 
            this.LPic.AutoSize = true;
            this.LPic.BackColor = System.Drawing.Color.Transparent;
            this.LPic.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPic.ForeColor = System.Drawing.Color.Black;
            this.LPic.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPic.Location = new System.Drawing.Point(14, 275);
            this.LPic.Name = "LPic";
            this.LPic.Size = new System.Drawing.Size(45, 29);
            this.LPic.TabIndex = 31;
            this.LPic.Text = "Pic:";
            // 
            // PBAddPic
            // 
            this.PBAddPic.BackColor = System.Drawing.Color.Transparent;
            this.PBAddPic.Image = ((System.Drawing.Image)(resources.GetObject("PBAddPic.Image")));
            this.PBAddPic.Location = new System.Drawing.Point(300, 275);
            this.PBAddPic.Name = "PBAddPic";
            this.PBAddPic.Size = new System.Drawing.Size(100, 80);
            this.PBAddPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddPic.TabIndex = 32;
            this.PBAddPic.TabStop = false;
            this.PBAddPic.Click += new System.EventHandler(this.PBAddPic_Click);
            this.PBAddPic.MouseLeave += new System.EventHandler(this.PBAddPic_MouseLeave);
            this.PBAddPic.MouseHover += new System.EventHandler(this.PBAddPic_MouseHover);
            // 
            // PBClientPic
            // 
            this.PBClientPic.BackColor = System.Drawing.Color.Transparent;
            this.PBClientPic.Location = new System.Drawing.Point(65, 275);
            this.PBClientPic.Name = "PBClientPic";
            this.PBClientPic.Size = new System.Drawing.Size(203, 173);
            this.PBClientPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBClientPic.TabIndex = 33;
            this.PBClientPic.TabStop = false;
            // 
            // PBAddClient
            // 
            this.PBAddClient.BackColor = System.Drawing.Color.Transparent;
            this.PBAddClient.Image = ((System.Drawing.Image)(resources.GetObject("PBAddClient.Image")));
            this.PBAddClient.Location = new System.Drawing.Point(612, 275);
            this.PBAddClient.Name = "PBAddClient";
            this.PBAddClient.Size = new System.Drawing.Size(100, 80);
            this.PBAddClient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddClient.TabIndex = 34;
            this.PBAddClient.TabStop = false;
            this.PBAddClient.Click += new System.EventHandler(this.PBAddClient_Click);
            this.PBAddClient.MouseLeave += new System.EventHandler(this.PBAddClient_MouseLeave);
            this.PBAddClient.MouseHover += new System.EventHandler(this.PBAddClient_MouseHover);
            // 
            // OFDAddPic
            // 
            this.OFDAddPic.FileName = "OFDAddPic";
            // 
            // LPicName
            // 
            this.LPicName.AutoSize = true;
            this.LPicName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPicName.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LPicName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPicName.Location = new System.Drawing.Point(295, 392);
            this.LPicName.Name = "LPicName";
            this.LPicName.Size = new System.Drawing.Size(0, 29);
            this.LPicName.TabIndex = 35;
            this.LPicName.Visible = false;
            // 
            // LError
            // 
            this.LError.AutoSize = true;
            this.LError.BackColor = System.Drawing.Color.Transparent;
            this.LError.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LError.ForeColor = System.Drawing.Color.Black;
            this.LError.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LError.Location = new System.Drawing.Point(60, 451);
            this.LError.Name = "LError";
            this.LError.Size = new System.Drawing.Size(0, 29);
            this.LError.TabIndex = 36;
            // 
            // LAddClientShow
            // 
            this.LAddClientShow.AutoSize = true;
            this.LAddClientShow.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddClientShow.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LAddClientShow.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddClientShow.Location = new System.Drawing.Point(60, 489);
            this.LAddClientShow.Name = "LAddClientShow";
            this.LAddClientShow.Size = new System.Drawing.Size(0, 29);
            this.LAddClientShow.TabIndex = 37;
            this.LAddClientShow.Visible = false;
            // 
            // DTPClentBD
            // 
            this.DTPClentBD.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTPClentBD.Location = new System.Drawing.Point(561, 237);
            this.DTPClentBD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DTPClentBD.MaxDate = new System.DateTime(2020, 12, 2, 0, 0, 0, 0);
            this.DTPClentBD.MinDate = new System.DateTime(1910, 1, 1, 0, 0, 0, 0);
            this.DTPClentBD.Name = "DTPClentBD";
            this.DTPClentBD.Size = new System.Drawing.Size(151, 22);
            this.DTPClentBD.TabIndex = 39;
            this.DTPClentBD.Value = new System.DateTime(2020, 12, 2, 0, 0, 0, 0);
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // AddClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.DTPClentBD);
            this.Controls.Add(this.LAddClientShow);
            this.Controls.Add(this.LError);
            this.Controls.Add(this.LPicName);
            this.Controls.Add(this.PBAddClient);
            this.Controls.Add(this.PBClientPic);
            this.Controls.Add(this.PBAddPic);
            this.Controls.Add(this.LPic);
            this.Controls.Add(this.TBPhone);
            this.Controls.Add(this.LPhone);
            this.Controls.Add(this.TBEmail);
            this.Controls.Add(this.LEmail);
            this.Controls.Add(this.TBID);
            this.Controls.Add(this.LID);
            this.Controls.Add(this.LBirthdate);
            this.Controls.Add(this.TBCity);
            this.Controls.Add(this.LCity);
            this.Controls.Add(this.TBAddress);
            this.Controls.Add(this.LAddress);
            this.Controls.Add(this.TBLName);
            this.Controls.Add(this.LLastName);
            this.Controls.Add(this.TBFName);
            this.Controls.Add(this.LFName);
            this.Controls.Add(this.TBPassword);
            this.Controls.Add(this.LPassword);
            this.Controls.Add(this.TBUsername);
            this.Controls.Add(this.LUserName);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddClientForm";
            this.Text = "Add Client";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddClient)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.Label LUserName;
        private System.Windows.Forms.TextBox TBUsername;
        private System.Windows.Forms.TextBox TBPassword;
        private System.Windows.Forms.Label LPassword;
        private System.Windows.Forms.TextBox TBFName;
        private System.Windows.Forms.Label LFName;
        private System.Windows.Forms.TextBox TBLName;
        private System.Windows.Forms.Label LLastName;
        private System.Windows.Forms.TextBox TBCity;
        private System.Windows.Forms.Label LCity;
        private System.Windows.Forms.TextBox TBAddress;
        private System.Windows.Forms.Label LAddress;
        private System.Windows.Forms.TextBox TBID;
        private System.Windows.Forms.Label LID;
        private System.Windows.Forms.Label LBirthdate;
        private System.Windows.Forms.TextBox TBEmail;
        private System.Windows.Forms.Label LEmail;
        private System.Windows.Forms.TextBox TBPhone;
        private System.Windows.Forms.Label LPhone;
        private System.Windows.Forms.Label LPic;
        private System.Windows.Forms.PictureBox PBAddPic;
        private System.Windows.Forms.PictureBox PBClientPic;
        private System.Windows.Forms.PictureBox PBAddClient;
        private System.Windows.Forms.OpenFileDialog OFDAddPic;
        private System.Windows.Forms.Label LPicName;
        private System.Windows.Forms.Label LError;
        private System.Windows.Forms.Label LAddClientShow;
        private System.Windows.Forms.DateTimePicker DTPClentBD;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}