﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class ReceiptList
    {
        public List<Receipt> Receipts = new List<Receipt>();
        /*
        empty constractor
        */
        public ReceiptList()
        {
        }
        /*
        constractor by client id unpaid orders
        */
        public void BuildReceiptsByClientUnpaid(int CID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where ClientPKID= "+CID+ "and Payment= false and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by client id paid orders and in the Future
        */
        public void BuildReceiptsByClientForFlightTicket(int CID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where ClientPKID= " + CID + "and Payment= True and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                if (DateTime.Parse(r.GetTour().GetDate()) > DateTime.Now)
                {
                    Receipts.Add(r);
                }
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by worker id paid orders
        */
        public void BuildReceiptsByWorkerpaidActive(int WID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where WorkerPKID= " + WID + "and Payment= true and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by tour id paid orders
        */
        public void BuildReceiptsByTourPaid(int TID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where TourPKID= " + TID + "and Payment= True and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by tour id unpaid orders
        */
        public void BuildReceiptsByTourUnPaidActive(int TID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where TourPKID= " + TID + "and Payment= false and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by tour id unactive orders
        */
        public void BuildReceiptsByTourUnPaidUnActive(int TID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where TourPKID= " + TID + "and Payment= false and Active= false ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by client id unpaid orders
        */
        public void BuildReceiptsByClientUnpaidActive(int CID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where ClientPKID= " + CID + "and Payment= false and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by worker id unpaid orders
        */
        public void BuildReceiptsByWorkerUnpaidActive(int WID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where WorkerPKID= " + WID + "and Payment= false and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by client id unactive orders
        */
        public void BuildReceiptsByClientUnpaidUnActive(int CID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where ClientPKID= " + CID + "and Payment= false and Active= false ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by worker id unactive orders
        */
        public void BuildReceiptsByWorkerUnpaidUnActive(int WID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where WorkerPKID= " + WID + "and Payment= false and Active= false ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by client id paid orders
        */
        public void BuildReceiptsByClientpaidActive(int CID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where ClientPKID= " + CID + "and Payment= true and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by client id
        */
        public void BuildReceiptsByClient(int CID)
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where ClientPKID= " + CID + " ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor unpaid orders
        */
        public void BuildReceiptsByUnpaid()
        {
            Receipts.Clear();
            Receipt r = new Receipt();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Orders where Payment= false and Active= True ORDER BY PKID;");
            while (dr.Read())
            {
                r = new Receipt(int.Parse(dr["PKID"].ToString()));
                Receipts.Add(r);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        get and set
        */
        public List<Receipt> GetReceiptsList()
        {
            return Receipts;
        }
        /*
        print data
        */
        public string PrintReceiptsData()
        {
            string s = "There is a " + Receipts.Count + " of unpaid orders please pay them or the travaling office will charge you before I.T Tours will Charge you\n";
            foreach (Receipt i in Receipts)
            {
                s += i.PrintDataForclientMenu()+ "\n";
            }
            return s;
        }
        /*
        print data for worker and manager show all unpaid order for tour in the next 14 days
        */
        public string PrintReceiptsDataWorker()
        {
            string  s1 = "", s2 = "";
            DateTime d = DateTime.Now;
            d = d.AddDays(14);
            int counter1 = 0, counter2 = 0;
            foreach (Receipt i in Receipts )
            {
                if (DateTime.Parse(i.GetTour().GetDate()) > DateTime.Now && DateTime.Parse(i.GetTour().GetDate()) < d)
                {
                    s1 += i.PrintDataForWorkerMenu() + "\n";
                    counter1++;
                }
                else if((DateTime.Parse(i.GetTour().GetDate()) < DateTime.Now))
                {
                    s2 += i.PrintDataForWorkerMenu() + "\n";
                    counter2++;;
                }
            }
            return "There is a:" + counter1 + " of unpaid orders for tour going in the next 2 weeks please contect the client! \n" + s1+ "There is a:" + counter2 + " of unpaid orders for tour that pased please contect the client please contect the client! \n"+s2;
        }
    }

}

