﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    find client form
    can update clients and see orders, print pdf data and order tours and flight ticket
    */
    public partial class FindClientForm : Form
    {
        Function f1 = new Function();
        Myconn connec = new Myconn();
        Client c = new Client();
        public static int clientid;
        ClientList Clients = new ClientList();
        int i = 0;
        public FindClientForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                ClientChart.Titles.Add("Client Orders chart");
                OFDAddPic.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
                if (LoginForm.Permission == "Manager")
                {
                    PBClientOrderTour.Visible = false;
                }
                if (Clients.GetClientList().Count != 0)
                {
                    c = Clients.GetClientList()[i];
                    
                    clientid = c.GetPKID();
                    FillCBClients();
                }
                else
                {

                    PBMinus.Visible = false;
                    PBMakePDFClient.Visible = false;
                    PBPlus.Visible = false;
                    PBOFF.Visible = false;
                    PBON.Visible = false;
                    PBUpdPic.Visible = false;
                    PBFlightTicket.Visible = false;
                    PBClientOrders.Visible = false;
                    PBUpaidOrders.Visible = false;
                    PBUpDateClient.Visible = false;
                }
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill client combo box
        */
        public void FillCBClients()
        {
            CBClientList.Items.Clear();
            foreach (Client i in Clients.GetClientList())
            {
                CBClientList.Items.Add(i.GetPKID() + " " + i.GetID() + " " + i.GetPhoneNumber() + " " + i.GetMail() + " " + i.GetUserName());
            }
            CBClientList.SelectedIndex = i;
        }
        /*
        fill client data in the form
        */
        public void fillClientdata()
        {
            foreach (var series in ClientChart.Series)
            {
                series.Points.Clear();
            }
            ClientChart.Series["s1"].IsValueShownAsLabel = true;
            ClientChart.Series["s1"].Points.AddXY("Unpaid Orders", c.GetOrderCount().ToString());
            ClientChart.Series["s1"].Points.AddXY("Paid Orders", c.GetOrderCount2().ToString());
            ClientChart.Series["s1"].Points.AddXY("Canceled Orders", c.GetOrderCount3().ToString());
            TBAddress.Text = Clients.GetClientList()[i].GeteAddress();
            TBUsername.Text = Clients.GetClientList()[i].GetUserName();
            TBLName.Text = Clients.GetClientList()[i].GetLastName();
            TBFName.Text = Clients.GetClientList()[i].GetFirstName();
            TBEmail.Text = Clients.GetClientList()[i].GetMail();
            TBPhone.Text = Clients.GetClientList()[i].GetPhoneNumber();
            TBCity.Text = Clients.GetClientList()[i].GetCity();
            LShowAge.Text = Clients.GetClientList()[i].GetBirthdate();
            TBID.Text = Clients.GetClientList()[i].GetID();
            PBClientPic.Image = Image.FromFile(@"Pic\Clients\" + Clients.GetClientList()[i].GetPic());
            LPicName.Text = Clients.GetClientList()[i].GetPic();
            LShowAge.Text = Clients.GetClientList()[i].ShowAge().ToString() ;
            if (Clients.GetClientList()[i].GetActivity())
            {
                LActiveornot.Text = "Active";
                PBON.Visible = false;
                PBOFF.Visible = true;

            }
            else
            {
                LActiveornot.Text = "Inactive";
                PBON.Visible = true;
                PBOFF.Visible = false;
            }
            int counter = c.GetOrderCount();
            LCounter.Text = counter.ToString();
            if (counter>3)
            {
                LCounter.ForeColor = Color.Red;
            }
            else
            {
                LCounter.ForeColor = Color.Black;
            }
        }
        /*
        Clock and date
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        go to last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            if (LoginForm.Permission == "Worker")
            {
                var WorkerMenuForm = new WorkerMenuForm();
                WorkerMenuForm.Closed += (s, args) => this.Close();
                WorkerMenuForm.Show();
                this.Hide();
            }
            else if (LoginForm.Permission == "Manager")
            {
                var ManagerMenuForm = new ManagerMenuForm();
                ManagerMenuForm.Closed += (s, args) => this.Close();
                ManagerMenuForm.Show();
                this.Hide();
            }
        }

        /*
        Update pic
        */
        private void PBUpdPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                LPicName.Text = OFDAddPic.SafeFileName;
                if (!new System.IO.FileInfo(@"Pic\Clients\" + LPicName.Text).Exists)
                {
                System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Clients\" + LPicName.Text);
                }
                PBClientPic.Image = Image.FromFile(@"Pic\Clients\" + LPicName.Text);  
            }
        }
        /*
        Update client cheack UN PN EMAIL duplicate
        */
        private void PBUpDateClient_Click(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "User name need 8-4 chars long and first 3 chars are letters \n";
            }
            f1.CheckPhone(TBPhone.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Phone must have 10 digits\n";
            }
            f1.CheckName(TBFName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "First name Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckName(TBLName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Last name Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckAddress(TBAddress.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Address must have lest 6 chars long and no number in the first 3 chars and finish with number\n";
            }

            f1.CheckName(TBCity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "City Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckEmail(TBEmail.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Wrong Email\n";
            }
            if (LPicName.Text.Length < 2)
            {
                flag = false;
                str += "Add picture\n";
            }
            LError.Text = str;
            if (flag)
            {
                if (TBUsername.Text != c.GetUserName())
                {
                    f1.Checkdup(TBUsername.Text, "UserName", "Clients");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Client with the same User name \n";
                    }
                }
                if (TBEmail.Text!=c.GetMail())
                {
                    f1.Checkdup(TBEmail.Text, "Email", "Clients");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Client with the same Email \n";
                    }
                }
                if (TBPhone.Text != c.GetPhoneNumber())
                {
                    f1.Checkdup(TBPhone.Text, "PhoneNumber", "Clients");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Client with the same Phone Number \n";
                    }
                }
                if (flag)
                {
                    i = Clients.GetClientList().IndexOf(c);
                    c.SetUserName(TBUsername.Text);
                    c.SetFirstName(TBFName.Text);
                    c.SetLastName(TBLName.Text);
                    c.SetAddress(TBAddress.Text);
                    c.SetCity(TBCity.Text);
                    c.SetMail(TBEmail.Text);
                    c.SetPhoneNumber(TBPhone.Text);
                    c.SetPic(LPicName.Text);
                    c.UpdateClientToDB();
                    str = "User updated";
                    Clients.GetClientList()[i] = c;
                    FillCBClients();

                }
                LError.Text = str;
            }
        }
        /*
        Last/next client
        */
        private void PBMinus_Click(object sender, EventArgs e)
        {
            i--;
            if (i<0)
            {
                i = Clients.GetClientList().Count-1;
            }
            c = Clients.GetClientList()[i];
            CBClientList.SelectedIndex = i;
        }
        private void PBPlus_Click(object sender, EventArgs e)
        {
            i++;
            if (i == Clients.GetClientList().Count)
            {
                i = 0;
            }
            c = Clients.GetClientList()[i];
            CBClientList.SelectedIndex = i;
        }
        /*
        Find client by id/UN/Email/PN
        */
        private void PBFCID_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckID(TBID.Text);
            if (f1.GetAnswer() == false)
            {
                str += "Wrong ID";
            }
            else
            {
                c = Clients.FindClientbyID(TBID.Text);
                i = Clients.GetClientList().IndexOf(c);
                if (i != -1)
                {
                    CBClientList.SelectedIndex=i;
                    str = "User Found by ID";
                }
                else
                {
                    str = "User with that ID dont exist";
                }
            }
            LError.Text = str;
        }
        private void PBFCUN_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                str = "User name need 8-4 chars long and first 3 chars are letters \n";
            }
            else
            {
                c = Clients.FindClientbyUN(TBUsername.Text);
                i = Clients.GetClientList().IndexOf(c);
                if (i != -1)
                {
                    CBClientList.SelectedIndex = i;
                    str = "User Found by user name";
                }
                else
                {
                    str = "User with that User name dont exist";
                }
            }
            LError.Text = str;
        }
        private void PBFCBPN_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckPhone(TBPhone.Text);
            if (f1.GetAnswer() == false)
            {
                str += "Phone must have 10 digits\n";
            }
            else
            {
                c = Clients.FindClientbyPN(TBPhone.Text);
                i = Clients.GetClientList().IndexOf(c);
                if (i != -1)
                {
                    CBClientList.SelectedIndex = i;
                    str = "User Found by Phone number";
                }
                else
                {
                    str = "User with that Phone number dont exist";
                }
            }
            LError.Text = str;
        }
        private void PBFCBEM_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckEmail(TBEmail.Text);
            if (f1.GetAnswer() == false)
            {
                str += "Wrong Email\n";
            }
            else
            {
                c = Clients.FindClientbyEMail(TBEmail.Text);
                i = Clients.GetClientList().IndexOf(c);
                if (i != -1)
                {
                    CBClientList.SelectedIndex = i;
                    str = "User Found by Email";
                }
                else
                {
                    str = "User with that Email dont exist";
                }
            }
            LError.Text = str;
        }
        /*
        Make client data PDF
        */
        private void PBMakePDFClient_Click(object sender, EventArgs e)
        {
            if (Clients.GetClientList().Count != 0)
            {
                if (SFDSaveClientFile.ShowDialog() == DialogResult.OK)
                {
                    string Path = SFDSaveClientFile.FileName;
                    this.ClientChart.SaveImage("pic/MyClientChart.png", System.Drawing.Imaging.ImageFormat.Png);
                    c.PrintClientDataPDF(System.IO.Path.GetFileNameWithoutExtension(SFDSaveClientFile.FileName), "pic/MyClientChart.png", System.IO.Path.GetDirectoryName(Path));
                }
            }
        }
        /*
        Activate/deactivate client
        */
        private void PBON_Click(object sender, EventArgs e)
        {
            i = Clients.GetClientList().IndexOf(c);
            c.UpdateClientActivityToDB(true);
            int temp = i;
            fillClientdata();
            Clients.GetClientList()[temp] = c;
            LError.Text = "User is now active";
        }
        private void PBOFF_Click(object sender, EventArgs e)
        {
            i = Clients.GetClientList().IndexOf(c);
            c.UpdateClientActivityToDB(false);
            int temp = i;
            fillClientdata();
            Clients.GetClientList()[temp] = c;
            LError.Text = "User is now inactive";
        }
        /*
        go to other forms
        */
        private void PBUpaidOrders_Click(object sender, EventArgs e)
        {
            var ClientUnpaidOrders = new ClientUnpaidOrders();
            ClientUnpaidOrders.Closed += (s, args) => this.Close();
            ClientUnpaidOrders.Show();
            this.Hide();
        }

        private void PBClientOrders_Click(object sender, EventArgs e)
        {
            var ClientOrdersForm = new ClientOrdersForm();
            ClientOrdersForm.Closed += (s, args) => this.Close();
            ClientOrdersForm.Show();
            this.Hide();
        }
        private void PBClientOrderTour_Click(object sender, EventArgs e)
        {
            {
                var ClientOrderTourForm = new ClientOrderTourForm();
                ClientOrderTourForm.Closed += (s, args) => this.Close();
                ClientOrderTourForm.Show();
                this.Hide();
            }
        }
        private void PBFlightTicket_Click(object sender, EventArgs e)
        {
            var FlightTicketForm = new FlightTicketForm();
            FlightTicketForm.Closed += (s, args) => this.Close();
            FlightTicketForm.Show();
            this.Hide();
        }
        /*
        hover and tooltip with mouse
        */
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }

        private void PBUpdPic_MouseHover(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update pic", PBUpdPic);
        }
        private void PBUpdPic_MouseLeave(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.Transparent;
        }

        private void PBUpDateClient_MouseHover(object sender, EventArgs e)
        {
            PBUpDateClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update client", PBUpDateClient);
        }
        private void PBUpDateClient_MouseLeave(object sender, EventArgs e)
        {
            PBUpDateClient.BackColor = Color.Transparent;
        }

        private void PBFCUN_MouseHover(object sender, EventArgs e)
        {
            PBFCUN.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Search by user name", PBFCUN);
        }
        private void PBFCUN_MouseLeave(object sender, EventArgs e)
        {
            PBFCUN.BackColor = Color.Transparent;
        }

        private void PBFCID_MouseHover(object sender, EventArgs e)
        {
            PBFCID.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Search by ID", PBFCID);
        }
        private void PBFCID_MouseLeave(object sender, EventArgs e)
        {
            PBFCID.BackColor = Color.Transparent;
        }

        private void PBFCBEM_MouseHover(object sender, EventArgs e)
        {
            PBFCBEM.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Search by Email", PBFCBEM);
        }
        private void PBFCBEM_MouseLeave(object sender, EventArgs e)
        {
            PBFCBEM.BackColor = Color.Transparent;
        }

        private void PBFCBPN_MouseHover(object sender, EventArgs e)
        {
            PBFCBPN.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Search by Phone", PBFCBPN);
        }
        private void PBFCBPN_MouseLeave(object sender, EventArgs e)
        {
            PBFCBPN.BackColor = Color.Transparent;
        }

        private void PBMinus_MouseHover(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Last client", PBMinus);
        }
        private void PBMinus_MouseLeave(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.Transparent;
        }

        private void PBPlus_MouseHover(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Next client", PBPlus);
        }
        private void PBPlus_MouseLeave(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.Transparent;
        }

        private void PBOFF_MouseHover(object sender, EventArgs e)
        {
            PBOFF.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Unactive client", PBOFF);
        }
        private void PBOFF_MouseLeave(object sender, EventArgs e)
        {
            PBOFF.BackColor = Color.Transparent;
        }

        private void PBON_MouseHover(object sender, EventArgs e)
        {
            PBON.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Active client", PBON);
        }
        private void PBON_MouseLeave(object sender, EventArgs e)
        {
            PBON.BackColor = Color.Transparent;
        }

        private void PBUpaidOrders_MouseHover(object sender, EventArgs e)
        {
            PBUpaidOrders.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Unpaid orders", PBUpaidOrders);
        }
        private void PBUpaidOrders_MouseLeave(object sender, EventArgs e)
        {
            PBUpaidOrders.BackColor = Color.Transparent;
        }

        private void PBClientOrders_MouseHover(object sender, EventArgs e)
        {
            PBClientOrders.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("All orders", PBClientOrders);
        }
        private void PBClientOrders_MouseLeave(object sender, EventArgs e)
        {
            PBClientOrders.BackColor = Color.Transparent;
        }

        private void PBMakePDFClient_MouseHover(object sender, EventArgs e)
        {
            PBMakePDFClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Make PDF client file", PBMakePDFClient);
        }
        private void PBMakePDFClient_MouseLeave(object sender, EventArgs e)
        {
            PBMakePDFClient.BackColor = Color.Transparent;
        }

        private void PBClientOrderTour_MouseHover(object sender, EventArgs e)
        {
            PBClientOrderTour.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Order Tour", PBClientOrderTour);
        }
        private void PBClientOrderTour_MouseLeave(object sender, EventArgs e)
        {
            PBClientOrderTour.BackColor = Color.Transparent;
        }

        private void PBFlightTicket_MouseHover(object sender, EventArgs e)
        {
            PBFlightTicket.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Make flight ticket", PBFlightTicket);
        }
        private void PBFlightTicket_MouseLeave(object sender, EventArgs e)
        {
            PBFlightTicket.BackColor = Color.Transparent;
        }
        /*
        PN and ID get only digits
        */
        private void TBPhone_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        /*
        change client
        */
        private void CBClientList_SelectedIndexChanged(object sender, EventArgs e)
        {
            i = CBClientList.SelectedIndex;
            c = Clients.GetClientList()[i];
            fillClientdata();
            clientid = c.GetPKID();
        }
        /*
        Exit timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        Tooltip background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
