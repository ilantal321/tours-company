﻿namespace IlanTalproTCB
{
    partial class WorkerMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WorkerMenuForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.LShowWorkerData = new System.Windows.Forms.Label();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.LUpdateData = new System.Windows.Forms.Label();
            this.PBUpDataWorker = new System.Windows.Forms.PictureBox();
            this.LAddCountries = new System.Windows.Forms.Label();
            this.PBAddCountries = new System.Windows.Forms.PictureBox();
            this.LFindClient = new System.Windows.Forms.Label();
            this.PBFindClient = new System.Windows.Forms.PictureBox();
            this.PBAddClient = new System.Windows.Forms.PictureBox();
            this.LAddClient = new System.Windows.Forms.Label();
            this.LClients = new System.Windows.Forms.Label();
            this.LTours = new System.Windows.Forms.Label();
            this.LFindTour = new System.Windows.Forms.Label();
            this.PBFindTour = new System.Windows.Forms.PictureBox();
            this.PBAddTour = new System.Windows.Forms.PictureBox();
            this.LAddTour = new System.Windows.Forms.Label();
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpDataWorker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddCountries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindTour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddTour)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 9);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(0, 40);
            this.LHeader.TabIndex = 1;
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 761);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // LShowWorkerData
            // 
            this.LShowWorkerData.AutoSize = true;
            this.LShowWorkerData.BackColor = System.Drawing.Color.Transparent;
            this.LShowWorkerData.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LShowWorkerData.ForeColor = System.Drawing.Color.Black;
            this.LShowWorkerData.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LShowWorkerData.Location = new System.Drawing.Point(14, 531);
            this.LShowWorkerData.Name = "LShowWorkerData";
            this.LShowWorkerData.Size = new System.Drawing.Size(0, 29);
            this.LShowWorkerData.TabIndex = 37;
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // LUpdateData
            // 
            this.LUpdateData.AutoSize = true;
            this.LUpdateData.BackColor = System.Drawing.Color.Transparent;
            this.LUpdateData.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LUpdateData.ForeColor = System.Drawing.Color.Black;
            this.LUpdateData.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LUpdateData.Location = new System.Drawing.Point(12, 93);
            this.LUpdateData.Name = "LUpdateData";
            this.LUpdateData.Size = new System.Drawing.Size(235, 40);
            this.LUpdateData.TabIndex = 43;
            this.LUpdateData.Text = "Update your data:";
            // 
            // PBUpDataWorker
            // 
            this.PBUpDataWorker.BackColor = System.Drawing.Color.Transparent;
            this.PBUpDataWorker.Image = ((System.Drawing.Image)(resources.GetObject("PBUpDataWorker.Image")));
            this.PBUpDataWorker.Location = new System.Drawing.Point(19, 168);
            this.PBUpDataWorker.Name = "PBUpDataWorker";
            this.PBUpDataWorker.Size = new System.Drawing.Size(150, 96);
            this.PBUpDataWorker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBUpDataWorker.TabIndex = 77;
            this.PBUpDataWorker.TabStop = false;
            this.PBUpDataWorker.Click += new System.EventHandler(this.PBUpDataWorker_Click);
            this.PBUpDataWorker.MouseLeave += new System.EventHandler(this.PBUpDataWorker_MouseLeave);
            this.PBUpDataWorker.MouseHover += new System.EventHandler(this.PBUpDataWorker_MouseHover);
            // 
            // LAddCountries
            // 
            this.LAddCountries.AutoSize = true;
            this.LAddCountries.BackColor = System.Drawing.Color.Transparent;
            this.LAddCountries.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddCountries.ForeColor = System.Drawing.Color.Black;
            this.LAddCountries.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddCountries.Location = new System.Drawing.Point(433, 93);
            this.LAddCountries.Name = "LAddCountries";
            this.LAddCountries.Size = new System.Drawing.Size(192, 40);
            this.LAddCountries.TabIndex = 84;
            this.LAddCountries.Text = "Add countries:";
            // 
            // PBAddCountries
            // 
            this.PBAddCountries.BackColor = System.Drawing.Color.Transparent;
            this.PBAddCountries.Image = ((System.Drawing.Image)(resources.GetObject("PBAddCountries.Image")));
            this.PBAddCountries.Location = new System.Drawing.Point(440, 168);
            this.PBAddCountries.Name = "PBAddCountries";
            this.PBAddCountries.Size = new System.Drawing.Size(150, 96);
            this.PBAddCountries.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddCountries.TabIndex = 83;
            this.PBAddCountries.TabStop = false;
            this.PBAddCountries.Click += new System.EventHandler(this.PBAddCountries_Click);
            this.PBAddCountries.MouseLeave += new System.EventHandler(this.PBAddCountries_MouseLeave);
            this.PBAddCountries.MouseHover += new System.EventHandler(this.PBAddCountries_MouseHover);
            // 
            // LFindClient
            // 
            this.LFindClient.AutoSize = true;
            this.LFindClient.BackColor = System.Drawing.Color.Transparent;
            this.LFindClient.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFindClient.ForeColor = System.Drawing.Color.Black;
            this.LFindClient.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFindClient.Location = new System.Drawing.Point(433, 357);
            this.LFindClient.Name = "LFindClient";
            this.LFindClient.Size = new System.Drawing.Size(111, 40);
            this.LFindClient.TabIndex = 88;
            this.LFindClient.Text = "Search:";
            // 
            // PBFindClient
            // 
            this.PBFindClient.BackColor = System.Drawing.Color.Transparent;
            this.PBFindClient.Image = ((System.Drawing.Image)(resources.GetObject("PBFindClient.Image")));
            this.PBFindClient.Location = new System.Drawing.Point(440, 432);
            this.PBFindClient.Name = "PBFindClient";
            this.PBFindClient.Size = new System.Drawing.Size(150, 96);
            this.PBFindClient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFindClient.TabIndex = 87;
            this.PBFindClient.TabStop = false;
            this.PBFindClient.Click += new System.EventHandler(this.PBFindClient_Click);
            this.PBFindClient.MouseLeave += new System.EventHandler(this.PBFindClient_MouseLeave);
            this.PBFindClient.MouseHover += new System.EventHandler(this.PBFindClient_MouseHover);
            // 
            // PBAddClient
            // 
            this.PBAddClient.BackColor = System.Drawing.Color.Transparent;
            this.PBAddClient.Image = ((System.Drawing.Image)(resources.GetObject("PBAddClient.Image")));
            this.PBAddClient.Location = new System.Drawing.Point(19, 432);
            this.PBAddClient.Name = "PBAddClient";
            this.PBAddClient.Size = new System.Drawing.Size(150, 96);
            this.PBAddClient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddClient.TabIndex = 86;
            this.PBAddClient.TabStop = false;
            this.PBAddClient.Click += new System.EventHandler(this.PBAddClient_Click);
            this.PBAddClient.MouseLeave += new System.EventHandler(this.PBAddClient_MouseLeave);
            this.PBAddClient.MouseHover += new System.EventHandler(this.PBAddClient_MouseHover);
            // 
            // LAddClient
            // 
            this.LAddClient.AutoSize = true;
            this.LAddClient.BackColor = System.Drawing.Color.Transparent;
            this.LAddClient.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddClient.ForeColor = System.Drawing.Color.Black;
            this.LAddClient.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddClient.Location = new System.Drawing.Point(12, 357);
            this.LAddClient.Name = "LAddClient";
            this.LAddClient.Size = new System.Drawing.Size(73, 40);
            this.LAddClient.TabIndex = 85;
            this.LAddClient.Text = "Add:";
            // 
            // LClients
            // 
            this.LClients.AutoSize = true;
            this.LClients.BackColor = System.Drawing.Color.Transparent;
            this.LClients.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LClients.ForeColor = System.Drawing.Color.Black;
            this.LClients.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LClients.Location = new System.Drawing.Point(12, 295);
            this.LClients.Name = "LClients";
            this.LClients.Size = new System.Drawing.Size(109, 40);
            this.LClients.TabIndex = 89;
            this.LClients.Text = "Clients:";
            // 
            // LTours
            // 
            this.LTours.AutoSize = true;
            this.LTours.BackColor = System.Drawing.Color.Transparent;
            this.LTours.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTours.ForeColor = System.Drawing.Color.Black;
            this.LTours.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTours.Location = new System.Drawing.Point(625, 295);
            this.LTours.Name = "LTours";
            this.LTours.Size = new System.Drawing.Size(95, 40);
            this.LTours.TabIndex = 109;
            this.LTours.Text = "Tours:";
            // 
            // LFindTour
            // 
            this.LFindTour.AutoSize = true;
            this.LFindTour.BackColor = System.Drawing.Color.Transparent;
            this.LFindTour.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFindTour.ForeColor = System.Drawing.Color.Black;
            this.LFindTour.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFindTour.Location = new System.Drawing.Point(1040, 357);
            this.LFindTour.Name = "LFindTour";
            this.LFindTour.Size = new System.Drawing.Size(111, 40);
            this.LFindTour.TabIndex = 108;
            this.LFindTour.Text = "Search:";
            // 
            // PBFindTour
            // 
            this.PBFindTour.BackColor = System.Drawing.Color.Transparent;
            this.PBFindTour.Image = ((System.Drawing.Image)(resources.GetObject("PBFindTour.Image")));
            this.PBFindTour.Location = new System.Drawing.Point(1047, 432);
            this.PBFindTour.Name = "PBFindTour";
            this.PBFindTour.Size = new System.Drawing.Size(150, 96);
            this.PBFindTour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFindTour.TabIndex = 107;
            this.PBFindTour.TabStop = false;
            this.PBFindTour.Click += new System.EventHandler(this.PBFindTour_Click);
            this.PBFindTour.MouseLeave += new System.EventHandler(this.PBFindTour_MouseLeave);
            this.PBFindTour.MouseHover += new System.EventHandler(this.PBFindTour_MouseHover);
            // 
            // PBAddTour
            // 
            this.PBAddTour.BackColor = System.Drawing.Color.Transparent;
            this.PBAddTour.Image = ((System.Drawing.Image)(resources.GetObject("PBAddTour.Image")));
            this.PBAddTour.Location = new System.Drawing.Point(632, 432);
            this.PBAddTour.Name = "PBAddTour";
            this.PBAddTour.Size = new System.Drawing.Size(150, 96);
            this.PBAddTour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddTour.TabIndex = 106;
            this.PBAddTour.TabStop = false;
            this.PBAddTour.Click += new System.EventHandler(this.PBAddTour_Click);
            this.PBAddTour.MouseLeave += new System.EventHandler(this.PBAddTour_MouseLeave);
            this.PBAddTour.MouseHover += new System.EventHandler(this.PBAddTour_MouseHover);
            // 
            // LAddTour
            // 
            this.LAddTour.AutoSize = true;
            this.LAddTour.BackColor = System.Drawing.Color.Transparent;
            this.LAddTour.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddTour.ForeColor = System.Drawing.Color.Black;
            this.LAddTour.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddTour.Location = new System.Drawing.Point(625, 357);
            this.LAddTour.Name = "LAddTour";
            this.LAddTour.Size = new System.Drawing.Size(73, 40);
            this.LAddTour.TabIndex = 105;
            this.LAddTour.Text = "Add:";
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // WorkerMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.LTours);
            this.Controls.Add(this.LFindTour);
            this.Controls.Add(this.PBFindTour);
            this.Controls.Add(this.PBAddTour);
            this.Controls.Add(this.LAddTour);
            this.Controls.Add(this.LClients);
            this.Controls.Add(this.LFindClient);
            this.Controls.Add(this.PBFindClient);
            this.Controls.Add(this.PBAddClient);
            this.Controls.Add(this.LAddClient);
            this.Controls.Add(this.LAddCountries);
            this.Controls.Add(this.PBAddCountries);
            this.Controls.Add(this.PBUpDataWorker);
            this.Controls.Add(this.LUpdateData);
            this.Controls.Add(this.LShowWorkerData);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "WorkerMenuForm";
            this.Text = "Worker menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpDataWorker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddCountries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFindTour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddTour)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.Label LShowWorkerData;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.Label LUpdateData;
        private System.Windows.Forms.PictureBox PBUpDataWorker;
        private System.Windows.Forms.Label LAddCountries;
        private System.Windows.Forms.PictureBox PBAddCountries;
        private System.Windows.Forms.Label LFindClient;
        private System.Windows.Forms.PictureBox PBFindClient;
        private System.Windows.Forms.PictureBox PBAddClient;
        private System.Windows.Forms.Label LAddClient;
        private System.Windows.Forms.Label LClients;
        private System.Windows.Forms.Label LTours;
        private System.Windows.Forms.Label LFindTour;
        private System.Windows.Forms.PictureBox PBFindTour;
        private System.Windows.Forms.PictureBox PBAddTour;
        private System.Windows.Forms.Label LAddTour;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}