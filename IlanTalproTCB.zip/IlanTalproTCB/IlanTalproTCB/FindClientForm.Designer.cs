﻿namespace IlanTalproTCB
{
    partial class FindClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FindClientForm));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.OFDAddPic = new System.Windows.Forms.OpenFileDialog();
            this.LError = new System.Windows.Forms.Label();
            this.LPicName = new System.Windows.Forms.Label();
            this.PBUpDateClient = new System.Windows.Forms.PictureBox();
            this.PBClientPic = new System.Windows.Forms.PictureBox();
            this.PBUpdPic = new System.Windows.Forms.PictureBox();
            this.LPic = new System.Windows.Forms.Label();
            this.TBPhone = new System.Windows.Forms.TextBox();
            this.LPhone = new System.Windows.Forms.Label();
            this.TBEmail = new System.Windows.Forms.TextBox();
            this.LEmail = new System.Windows.Forms.Label();
            this.LID = new System.Windows.Forms.Label();
            this.LAge = new System.Windows.Forms.Label();
            this.TBCity = new System.Windows.Forms.TextBox();
            this.LCity = new System.Windows.Forms.Label();
            this.TBAddress = new System.Windows.Forms.TextBox();
            this.LAddress = new System.Windows.Forms.Label();
            this.TBLName = new System.Windows.Forms.TextBox();
            this.LLastName = new System.Windows.Forms.Label();
            this.TBFName = new System.Windows.Forms.TextBox();
            this.LFName = new System.Windows.Forms.Label();
            this.TBUsername = new System.Windows.Forms.TextBox();
            this.LUserName = new System.Windows.Forms.Label();
            this.LShowAge = new System.Windows.Forms.Label();
            this.PBMinus = new System.Windows.Forms.PictureBox();
            this.PBPlus = new System.Windows.Forms.PictureBox();
            this.TBID = new System.Windows.Forms.TextBox();
            this.PBFCID = new System.Windows.Forms.PictureBox();
            this.PBFCUN = new System.Windows.Forms.PictureBox();
            this.PBFCBEM = new System.Windows.Forms.PictureBox();
            this.PBFCBPN = new System.Windows.Forms.PictureBox();
            this.LActiveornot = new System.Windows.Forms.Label();
            this.LActivity = new System.Windows.Forms.Label();
            this.PBON = new System.Windows.Forms.PictureBox();
            this.PBOFF = new System.Windows.Forms.PictureBox();
            this.CBClientList = new System.Windows.Forms.ComboBox();
            this.LCounter = new System.Windows.Forms.Label();
            this.LUnpaid = new System.Windows.Forms.Label();
            this.PBUpaidOrders = new System.Windows.Forms.PictureBox();
            this.PBClientOrders = new System.Windows.Forms.PictureBox();
            this.PBMakePDFClient = new System.Windows.Forms.PictureBox();
            this.ClientChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.SFDSaveClientFile = new System.Windows.Forms.SaveFileDialog();
            this.PBClientOrderTour = new System.Windows.Forms.PictureBox();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.PBFlightTicket = new System.Windows.Forms.PictureBox();
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpDateClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpdPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMinus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPlus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFCID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFCUN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFCBEM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFCBPN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBON)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBOFF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpaidOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMakePDFClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClientChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientOrderTour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFlightTicket)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 7);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(198, 40);
            this.LHeader.TabIndex = 1;
            this.LHeader.Text = "Search a client";
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 761);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // OFDAddPic
            // 
            this.OFDAddPic.FileName = "OFDAddPic";
            // 
            // LError
            // 
            this.LError.AutoSize = true;
            this.LError.BackColor = System.Drawing.Color.Transparent;
            this.LError.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LError.ForeColor = System.Drawing.Color.Black;
            this.LError.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LError.Location = new System.Drawing.Point(14, 513);
            this.LError.Name = "LError";
            this.LError.Size = new System.Drawing.Size(0, 29);
            this.LError.TabIndex = 63;
            // 
            // LPicName
            // 
            this.LPicName.AutoSize = true;
            this.LPicName.BackColor = System.Drawing.Color.Transparent;
            this.LPicName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPicName.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LPicName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPicName.Location = new System.Drawing.Point(295, 437);
            this.LPicName.Name = "LPicName";
            this.LPicName.Size = new System.Drawing.Size(0, 29);
            this.LPicName.TabIndex = 62;
            this.LPicName.Visible = false;
            // 
            // PBUpDateClient
            // 
            this.PBUpDateClient.BackColor = System.Drawing.Color.Transparent;
            this.PBUpDateClient.Image = ((System.Drawing.Image)(resources.GetObject("PBUpDateClient.Image")));
            this.PBUpDateClient.Location = new System.Drawing.Point(612, 310);
            this.PBUpDateClient.Name = "PBUpDateClient";
            this.PBUpDateClient.Size = new System.Drawing.Size(100, 80);
            this.PBUpDateClient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBUpDateClient.TabIndex = 61;
            this.PBUpDateClient.TabStop = false;
            this.PBUpDateClient.Click += new System.EventHandler(this.PBUpDateClient_Click);
            this.PBUpDateClient.MouseLeave += new System.EventHandler(this.PBUpDateClient_MouseLeave);
            this.PBUpDateClient.MouseHover += new System.EventHandler(this.PBUpDateClient_MouseHover);
            // 
            // PBClientPic
            // 
            this.PBClientPic.BackColor = System.Drawing.Color.Transparent;
            this.PBClientPic.Location = new System.Drawing.Point(65, 320);
            this.PBClientPic.Name = "PBClientPic";
            this.PBClientPic.Size = new System.Drawing.Size(203, 173);
            this.PBClientPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBClientPic.TabIndex = 60;
            this.PBClientPic.TabStop = false;
            // 
            // PBUpdPic
            // 
            this.PBUpdPic.BackColor = System.Drawing.Color.Transparent;
            this.PBUpdPic.Image = ((System.Drawing.Image)(resources.GetObject("PBUpdPic.Image")));
            this.PBUpdPic.Location = new System.Drawing.Point(300, 310);
            this.PBUpdPic.Name = "PBUpdPic";
            this.PBUpdPic.Size = new System.Drawing.Size(100, 80);
            this.PBUpdPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBUpdPic.TabIndex = 59;
            this.PBUpdPic.TabStop = false;
            this.PBUpdPic.Click += new System.EventHandler(this.PBUpdPic_Click);
            this.PBUpdPic.MouseLeave += new System.EventHandler(this.PBUpdPic_MouseLeave);
            this.PBUpdPic.MouseHover += new System.EventHandler(this.PBUpdPic_MouseHover);
            // 
            // LPic
            // 
            this.LPic.AutoSize = true;
            this.LPic.BackColor = System.Drawing.Color.Transparent;
            this.LPic.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPic.ForeColor = System.Drawing.Color.Black;
            this.LPic.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPic.Location = new System.Drawing.Point(14, 320);
            this.LPic.Name = "LPic";
            this.LPic.Size = new System.Drawing.Size(45, 29);
            this.LPic.TabIndex = 58;
            this.LPic.Text = "Pic:";
            // 
            // TBPhone
            // 
            this.TBPhone.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBPhone.Location = new System.Drawing.Point(137, 190);
            this.TBPhone.MaxLength = 10;
            this.TBPhone.Name = "TBPhone";
            this.TBPhone.Size = new System.Drawing.Size(151, 27);
            this.TBPhone.TabIndex = 57;
            this.TBPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBPhone_KeyPress_1);
            // 
            // LPhone
            // 
            this.LPhone.AutoSize = true;
            this.LPhone.BackColor = System.Drawing.Color.Transparent;
            this.LPhone.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPhone.ForeColor = System.Drawing.Color.Black;
            this.LPhone.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPhone.Location = new System.Drawing.Point(14, 188);
            this.LPhone.Name = "LPhone";
            this.LPhone.Size = new System.Drawing.Size(75, 29);
            this.LPhone.TabIndex = 56;
            this.LPhone.Text = "Phone:";
            // 
            // TBEmail
            // 
            this.TBEmail.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBEmail.Location = new System.Drawing.Point(137, 149);
            this.TBEmail.MaxLength = 40;
            this.TBEmail.Name = "TBEmail";
            this.TBEmail.Size = new System.Drawing.Size(151, 27);
            this.TBEmail.TabIndex = 55;
            // 
            // LEmail
            // 
            this.LEmail.AutoSize = true;
            this.LEmail.BackColor = System.Drawing.Color.Transparent;
            this.LEmail.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LEmail.ForeColor = System.Drawing.Color.Black;
            this.LEmail.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LEmail.Location = new System.Drawing.Point(14, 147);
            this.LEmail.Name = "LEmail";
            this.LEmail.Size = new System.Drawing.Size(66, 29);
            this.LEmail.TabIndex = 54;
            this.LEmail.Text = "Email:";
            // 
            // LID
            // 
            this.LID.AutoSize = true;
            this.LID.BackColor = System.Drawing.Color.Transparent;
            this.LID.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LID.ForeColor = System.Drawing.Color.Black;
            this.LID.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LID.Location = new System.Drawing.Point(14, 106);
            this.LID.Name = "LID";
            this.LID.Size = new System.Drawing.Size(36, 29);
            this.LID.TabIndex = 52;
            this.LID.Text = "ID:";
            // 
            // LAge
            // 
            this.LAge.AutoSize = true;
            this.LAge.BackColor = System.Drawing.Color.Transparent;
            this.LAge.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAge.ForeColor = System.Drawing.Color.Black;
            this.LAge.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAge.Location = new System.Drawing.Point(14, 230);
            this.LAge.Name = "LAge";
            this.LAge.Size = new System.Drawing.Size(53, 29);
            this.LAge.TabIndex = 50;
            this.LAge.Text = "Age:";
            // 
            // TBCity
            // 
            this.TBCity.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBCity.Location = new System.Drawing.Point(561, 186);
            this.TBCity.MaxLength = 25;
            this.TBCity.Name = "TBCity";
            this.TBCity.Size = new System.Drawing.Size(151, 27);
            this.TBCity.TabIndex = 49;
            // 
            // LCity
            // 
            this.LCity.AutoSize = true;
            this.LCity.BackColor = System.Drawing.Color.Transparent;
            this.LCity.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCity.ForeColor = System.Drawing.Color.Black;
            this.LCity.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCity.Location = new System.Drawing.Point(438, 184);
            this.LCity.Name = "LCity";
            this.LCity.Size = new System.Drawing.Size(50, 29);
            this.LCity.TabIndex = 48;
            this.LCity.Text = "City:";
            // 
            // TBAddress
            // 
            this.TBAddress.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBAddress.Location = new System.Drawing.Point(561, 147);
            this.TBAddress.MaxLength = 40;
            this.TBAddress.Name = "TBAddress";
            this.TBAddress.Size = new System.Drawing.Size(151, 27);
            this.TBAddress.TabIndex = 47;
            // 
            // LAddress
            // 
            this.LAddress.AutoSize = true;
            this.LAddress.BackColor = System.Drawing.Color.Transparent;
            this.LAddress.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAddress.ForeColor = System.Drawing.Color.Black;
            this.LAddress.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LAddress.Location = new System.Drawing.Point(438, 145);
            this.LAddress.Name = "LAddress";
            this.LAddress.Size = new System.Drawing.Size(91, 29);
            this.LAddress.TabIndex = 46;
            this.LAddress.Text = "Address:";
            // 
            // TBLName
            // 
            this.TBLName.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBLName.Location = new System.Drawing.Point(561, 106);
            this.TBLName.MaxLength = 15;
            this.TBLName.Name = "TBLName";
            this.TBLName.Size = new System.Drawing.Size(151, 27);
            this.TBLName.TabIndex = 45;
            // 
            // LLastName
            // 
            this.LLastName.AutoSize = true;
            this.LLastName.BackColor = System.Drawing.Color.Transparent;
            this.LLastName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LLastName.ForeColor = System.Drawing.Color.Black;
            this.LLastName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LLastName.Location = new System.Drawing.Point(438, 104);
            this.LLastName.Name = "LLastName";
            this.LLastName.Size = new System.Drawing.Size(112, 29);
            this.LLastName.TabIndex = 44;
            this.LLastName.Text = "Last Name:";
            // 
            // TBFName
            // 
            this.TBFName.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBFName.Location = new System.Drawing.Point(561, 67);
            this.TBFName.MaxLength = 15;
            this.TBFName.Name = "TBFName";
            this.TBFName.Size = new System.Drawing.Size(151, 27);
            this.TBFName.TabIndex = 43;
            // 
            // LFName
            // 
            this.LFName.AutoSize = true;
            this.LFName.BackColor = System.Drawing.Color.Transparent;
            this.LFName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFName.ForeColor = System.Drawing.Color.Black;
            this.LFName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFName.Location = new System.Drawing.Point(438, 65);
            this.LFName.Name = "LFName";
            this.LFName.Size = new System.Drawing.Size(113, 29);
            this.LFName.TabIndex = 42;
            this.LFName.Text = "First Name:";
            // 
            // TBUsername
            // 
            this.TBUsername.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBUsername.Location = new System.Drawing.Point(137, 67);
            this.TBUsername.MaxLength = 8;
            this.TBUsername.Name = "TBUsername";
            this.TBUsername.Size = new System.Drawing.Size(151, 27);
            this.TBUsername.TabIndex = 39;
            // 
            // LUserName
            // 
            this.LUserName.AutoSize = true;
            this.LUserName.BackColor = System.Drawing.Color.Transparent;
            this.LUserName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LUserName.ForeColor = System.Drawing.Color.Black;
            this.LUserName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LUserName.Location = new System.Drawing.Point(14, 65);
            this.LUserName.Name = "LUserName";
            this.LUserName.Size = new System.Drawing.Size(117, 29);
            this.LUserName.TabIndex = 38;
            this.LUserName.Text = "User Name:";
            // 
            // LShowAge
            // 
            this.LShowAge.AutoSize = true;
            this.LShowAge.BackColor = System.Drawing.Color.Transparent;
            this.LShowAge.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LShowAge.ForeColor = System.Drawing.Color.Black;
            this.LShowAge.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LShowAge.Location = new System.Drawing.Point(132, 230);
            this.LShowAge.Name = "LShowAge";
            this.LShowAge.Size = new System.Drawing.Size(0, 29);
            this.LShowAge.TabIndex = 65;
            // 
            // PBMinus
            // 
            this.PBMinus.BackColor = System.Drawing.Color.Transparent;
            this.PBMinus.Image = ((System.Drawing.Image)(resources.GetObject("PBMinus.Image")));
            this.PBMinus.Location = new System.Drawing.Point(350, 431);
            this.PBMinus.Name = "PBMinus";
            this.PBMinus.Size = new System.Drawing.Size(59, 62);
            this.PBMinus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBMinus.TabIndex = 68;
            this.PBMinus.TabStop = false;
            this.PBMinus.Click += new System.EventHandler(this.PBMinus_Click);
            this.PBMinus.MouseLeave += new System.EventHandler(this.PBMinus_MouseLeave);
            this.PBMinus.MouseHover += new System.EventHandler(this.PBMinus_MouseHover);
            // 
            // PBPlus
            // 
            this.PBPlus.BackColor = System.Drawing.Color.Transparent;
            this.PBPlus.Image = ((System.Drawing.Image)(resources.GetObject("PBPlus.Image")));
            this.PBPlus.Location = new System.Drawing.Point(443, 431);
            this.PBPlus.Name = "PBPlus";
            this.PBPlus.Size = new System.Drawing.Size(59, 62);
            this.PBPlus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBPlus.TabIndex = 69;
            this.PBPlus.TabStop = false;
            this.PBPlus.Click += new System.EventHandler(this.PBPlus_Click);
            this.PBPlus.MouseLeave += new System.EventHandler(this.PBPlus_MouseLeave);
            this.PBPlus.MouseHover += new System.EventHandler(this.PBPlus_MouseHover);
            // 
            // TBID
            // 
            this.TBID.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBID.Location = new System.Drawing.Point(137, 108);
            this.TBID.MaxLength = 10;
            this.TBID.Name = "TBID";
            this.TBID.Size = new System.Drawing.Size(151, 27);
            this.TBID.TabIndex = 70;
            this.TBID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBID_KeyPress);
            // 
            // PBFCID
            // 
            this.PBFCID.BackColor = System.Drawing.Color.Transparent;
            this.PBFCID.Image = ((System.Drawing.Image)(resources.GetObject("PBFCID.Image")));
            this.PBFCID.Location = new System.Drawing.Point(300, 108);
            this.PBFCID.Name = "PBFCID";
            this.PBFCID.Size = new System.Drawing.Size(29, 27);
            this.PBFCID.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFCID.TabIndex = 71;
            this.PBFCID.TabStop = false;
            this.PBFCID.Click += new System.EventHandler(this.PBFCID_Click);
            this.PBFCID.MouseLeave += new System.EventHandler(this.PBFCID_MouseLeave);
            this.PBFCID.MouseHover += new System.EventHandler(this.PBFCID_MouseHover);
            // 
            // PBFCUN
            // 
            this.PBFCUN.BackColor = System.Drawing.Color.Transparent;
            this.PBFCUN.Image = ((System.Drawing.Image)(resources.GetObject("PBFCUN.Image")));
            this.PBFCUN.Location = new System.Drawing.Point(300, 67);
            this.PBFCUN.Name = "PBFCUN";
            this.PBFCUN.Size = new System.Drawing.Size(29, 27);
            this.PBFCUN.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFCUN.TabIndex = 72;
            this.PBFCUN.TabStop = false;
            this.PBFCUN.Click += new System.EventHandler(this.PBFCUN_Click);
            this.PBFCUN.MouseLeave += new System.EventHandler(this.PBFCUN_MouseLeave);
            this.PBFCUN.MouseHover += new System.EventHandler(this.PBFCUN_MouseHover);
            // 
            // PBFCBEM
            // 
            this.PBFCBEM.BackColor = System.Drawing.Color.Transparent;
            this.PBFCBEM.Image = ((System.Drawing.Image)(resources.GetObject("PBFCBEM.Image")));
            this.PBFCBEM.Location = new System.Drawing.Point(300, 149);
            this.PBFCBEM.Name = "PBFCBEM";
            this.PBFCBEM.Size = new System.Drawing.Size(29, 27);
            this.PBFCBEM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFCBEM.TabIndex = 73;
            this.PBFCBEM.TabStop = false;
            this.PBFCBEM.Click += new System.EventHandler(this.PBFCBEM_Click);
            this.PBFCBEM.MouseLeave += new System.EventHandler(this.PBFCBEM_MouseLeave);
            this.PBFCBEM.MouseHover += new System.EventHandler(this.PBFCBEM_MouseHover);
            // 
            // PBFCBPN
            // 
            this.PBFCBPN.BackColor = System.Drawing.Color.Transparent;
            this.PBFCBPN.Image = ((System.Drawing.Image)(resources.GetObject("PBFCBPN.Image")));
            this.PBFCBPN.Location = new System.Drawing.Point(300, 190);
            this.PBFCBPN.Name = "PBFCBPN";
            this.PBFCBPN.Size = new System.Drawing.Size(29, 27);
            this.PBFCBPN.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFCBPN.TabIndex = 74;
            this.PBFCBPN.TabStop = false;
            this.PBFCBPN.Click += new System.EventHandler(this.PBFCBPN_Click);
            this.PBFCBPN.MouseLeave += new System.EventHandler(this.PBFCBPN_MouseLeave);
            this.PBFCBPN.MouseHover += new System.EventHandler(this.PBFCBPN_MouseHover);
            // 
            // LActiveornot
            // 
            this.LActiveornot.AutoSize = true;
            this.LActiveornot.BackColor = System.Drawing.Color.Transparent;
            this.LActiveornot.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LActiveornot.ForeColor = System.Drawing.Color.Black;
            this.LActiveornot.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LActiveornot.Location = new System.Drawing.Point(556, 230);
            this.LActiveornot.Name = "LActiveornot";
            this.LActiveornot.Size = new System.Drawing.Size(0, 29);
            this.LActiveornot.TabIndex = 76;
            // 
            // LActivity
            // 
            this.LActivity.AutoSize = true;
            this.LActivity.BackColor = System.Drawing.Color.Transparent;
            this.LActivity.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LActivity.ForeColor = System.Drawing.Color.Black;
            this.LActivity.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LActivity.Location = new System.Drawing.Point(438, 230);
            this.LActivity.Name = "LActivity";
            this.LActivity.Size = new System.Drawing.Size(77, 29);
            this.LActivity.TabIndex = 75;
            this.LActivity.Text = "Activity:";
            // 
            // PBON
            // 
            this.PBON.BackColor = System.Drawing.Color.Transparent;
            this.PBON.Image = ((System.Drawing.Image)(resources.GetObject("PBON.Image")));
            this.PBON.Location = new System.Drawing.Point(521, 310);
            this.PBON.Name = "PBON";
            this.PBON.Size = new System.Drawing.Size(59, 62);
            this.PBON.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBON.TabIndex = 77;
            this.PBON.TabStop = false;
            this.PBON.Click += new System.EventHandler(this.PBON_Click);
            this.PBON.MouseLeave += new System.EventHandler(this.PBON_MouseLeave);
            this.PBON.MouseHover += new System.EventHandler(this.PBON_MouseHover);
            // 
            // PBOFF
            // 
            this.PBOFF.BackColor = System.Drawing.Color.Transparent;
            this.PBOFF.Image = ((System.Drawing.Image)(resources.GetObject("PBOFF.Image")));
            this.PBOFF.Location = new System.Drawing.Point(443, 310);
            this.PBOFF.Name = "PBOFF";
            this.PBOFF.Size = new System.Drawing.Size(59, 62);
            this.PBOFF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBOFF.TabIndex = 78;
            this.PBOFF.TabStop = false;
            this.PBOFF.Click += new System.EventHandler(this.PBOFF_Click);
            this.PBOFF.MouseLeave += new System.EventHandler(this.PBOFF_MouseLeave);
            this.PBOFF.MouseHover += new System.EventHandler(this.PBOFF_MouseHover);
            // 
            // CBClientList
            // 
            this.CBClientList.FormattingEnabled = true;
            this.CBClientList.Location = new System.Drawing.Point(287, 23);
            this.CBClientList.Name = "CBClientList";
            this.CBClientList.Size = new System.Drawing.Size(584, 24);
            this.CBClientList.TabIndex = 79;
            this.CBClientList.SelectedIndexChanged += new System.EventHandler(this.CBClientList_SelectedIndexChanged);
            // 
            // LCounter
            // 
            this.LCounter.AutoSize = true;
            this.LCounter.BackColor = System.Drawing.Color.Transparent;
            this.LCounter.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCounter.ForeColor = System.Drawing.Color.Black;
            this.LCounter.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCounter.Location = new System.Drawing.Point(187, 271);
            this.LCounter.Name = "LCounter";
            this.LCounter.Size = new System.Drawing.Size(0, 29);
            this.LCounter.TabIndex = 81;
            // 
            // LUnpaid
            // 
            this.LUnpaid.AutoSize = true;
            this.LUnpaid.BackColor = System.Drawing.Color.Transparent;
            this.LUnpaid.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LUnpaid.ForeColor = System.Drawing.Color.Black;
            this.LUnpaid.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LUnpaid.Location = new System.Drawing.Point(14, 271);
            this.LUnpaid.Name = "LUnpaid";
            this.LUnpaid.Size = new System.Drawing.Size(146, 29);
            this.LUnpaid.TabIndex = 80;
            this.LUnpaid.Text = "Unpaid Orders:";
            // 
            // PBUpaidOrders
            // 
            this.PBUpaidOrders.BackColor = System.Drawing.Color.Transparent;
            this.PBUpaidOrders.Image = ((System.Drawing.Image)(resources.GetObject("PBUpaidOrders.Image")));
            this.PBUpaidOrders.Location = new System.Drawing.Point(612, 413);
            this.PBUpaidOrders.Name = "PBUpaidOrders";
            this.PBUpaidOrders.Size = new System.Drawing.Size(100, 80);
            this.PBUpaidOrders.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBUpaidOrders.TabIndex = 82;
            this.PBUpaidOrders.TabStop = false;
            this.PBUpaidOrders.Click += new System.EventHandler(this.PBUpaidOrders_Click);
            this.PBUpaidOrders.MouseLeave += new System.EventHandler(this.PBUpaidOrders_MouseLeave);
            this.PBUpaidOrders.MouseHover += new System.EventHandler(this.PBUpaidOrders_MouseHover);
            // 
            // PBClientOrders
            // 
            this.PBClientOrders.BackColor = System.Drawing.Color.Transparent;
            this.PBClientOrders.Image = ((System.Drawing.Image)(resources.GetObject("PBClientOrders.Image")));
            this.PBClientOrders.Location = new System.Drawing.Point(612, 513);
            this.PBClientOrders.Name = "PBClientOrders";
            this.PBClientOrders.Size = new System.Drawing.Size(100, 80);
            this.PBClientOrders.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBClientOrders.TabIndex = 83;
            this.PBClientOrders.TabStop = false;
            this.PBClientOrders.Click += new System.EventHandler(this.PBClientOrders_Click);
            this.PBClientOrders.MouseLeave += new System.EventHandler(this.PBClientOrders_MouseLeave);
            this.PBClientOrders.MouseHover += new System.EventHandler(this.PBClientOrders_MouseHover);
            // 
            // PBMakePDFClient
            // 
            this.PBMakePDFClient.BackColor = System.Drawing.Color.Transparent;
            this.PBMakePDFClient.Image = ((System.Drawing.Image)(resources.GetObject("PBMakePDFClient.Image")));
            this.PBMakePDFClient.Location = new System.Drawing.Point(732, 310);
            this.PBMakePDFClient.Name = "PBMakePDFClient";
            this.PBMakePDFClient.Size = new System.Drawing.Size(100, 80);
            this.PBMakePDFClient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBMakePDFClient.TabIndex = 84;
            this.PBMakePDFClient.TabStop = false;
            this.PBMakePDFClient.Click += new System.EventHandler(this.PBMakePDFClient_Click);
            this.PBMakePDFClient.MouseLeave += new System.EventHandler(this.PBMakePDFClient_MouseLeave);
            this.PBMakePDFClient.MouseHover += new System.EventHandler(this.PBMakePDFClient_MouseHover);
            // 
            // ClientChart
            // 
            chartArea1.Name = "ChartArea1";
            this.ClientChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.ClientChart.Legends.Add(legend1);
            this.ClientChart.Location = new System.Drawing.Point(878, 104);
            this.ClientChart.Name = "ClientChart";
            series1.BackImageTransparentColor = System.Drawing.Color.Transparent;
            series1.BackSecondaryColor = System.Drawing.Color.Transparent;
            series1.BorderColor = System.Drawing.Color.Transparent;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Color = System.Drawing.Color.Transparent;
            series1.Legend = "Legend1";
            series1.Name = "s1";
            this.ClientChart.Series.Add(series1);
            this.ClientChart.Size = new System.Drawing.Size(295, 298);
            this.ClientChart.TabIndex = 85;
            this.ClientChart.Text = "Client Chart";
            // 
            // PBClientOrderTour
            // 
            this.PBClientOrderTour.BackColor = System.Drawing.Color.Transparent;
            this.PBClientOrderTour.Image = ((System.Drawing.Image)(resources.GetObject("PBClientOrderTour.Image")));
            this.PBClientOrderTour.Location = new System.Drawing.Point(732, 413);
            this.PBClientOrderTour.Name = "PBClientOrderTour";
            this.PBClientOrderTour.Size = new System.Drawing.Size(100, 80);
            this.PBClientOrderTour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBClientOrderTour.TabIndex = 86;
            this.PBClientOrderTour.TabStop = false;
            this.PBClientOrderTour.Click += new System.EventHandler(this.PBClientOrderTour_Click);
            this.PBClientOrderTour.MouseLeave += new System.EventHandler(this.PBClientOrderTour_MouseLeave);
            this.PBClientOrderTour.MouseHover += new System.EventHandler(this.PBClientOrderTour_MouseHover);
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // PBFlightTicket
            // 
            this.PBFlightTicket.BackColor = System.Drawing.Color.Transparent;
            this.PBFlightTicket.Image = ((System.Drawing.Image)(resources.GetObject("PBFlightTicket.Image")));
            this.PBFlightTicket.Location = new System.Drawing.Point(732, 513);
            this.PBFlightTicket.Name = "PBFlightTicket";
            this.PBFlightTicket.Size = new System.Drawing.Size(100, 80);
            this.PBFlightTicket.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFlightTicket.TabIndex = 88;
            this.PBFlightTicket.TabStop = false;
            this.PBFlightTicket.Click += new System.EventHandler(this.PBFlightTicket_Click);
            this.PBFlightTicket.MouseLeave += new System.EventHandler(this.PBFlightTicket_MouseLeave);
            this.PBFlightTicket.MouseHover += new System.EventHandler(this.PBFlightTicket_MouseHover);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // FindClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.PBFlightTicket);
            this.Controls.Add(this.PBClientOrderTour);
            this.Controls.Add(this.ClientChart);
            this.Controls.Add(this.PBMakePDFClient);
            this.Controls.Add(this.PBClientOrders);
            this.Controls.Add(this.PBUpaidOrders);
            this.Controls.Add(this.LCounter);
            this.Controls.Add(this.LUnpaid);
            this.Controls.Add(this.CBClientList);
            this.Controls.Add(this.PBOFF);
            this.Controls.Add(this.PBON);
            this.Controls.Add(this.LActiveornot);
            this.Controls.Add(this.LActivity);
            this.Controls.Add(this.PBFCBPN);
            this.Controls.Add(this.PBFCBEM);
            this.Controls.Add(this.PBFCUN);
            this.Controls.Add(this.PBFCID);
            this.Controls.Add(this.TBID);
            this.Controls.Add(this.PBPlus);
            this.Controls.Add(this.PBMinus);
            this.Controls.Add(this.LShowAge);
            this.Controls.Add(this.LError);
            this.Controls.Add(this.LPicName);
            this.Controls.Add(this.PBUpDateClient);
            this.Controls.Add(this.PBClientPic);
            this.Controls.Add(this.PBUpdPic);
            this.Controls.Add(this.LPic);
            this.Controls.Add(this.TBPhone);
            this.Controls.Add(this.LPhone);
            this.Controls.Add(this.TBEmail);
            this.Controls.Add(this.LEmail);
            this.Controls.Add(this.LID);
            this.Controls.Add(this.LAge);
            this.Controls.Add(this.TBCity);
            this.Controls.Add(this.LCity);
            this.Controls.Add(this.TBAddress);
            this.Controls.Add(this.LAddress);
            this.Controls.Add(this.TBLName);
            this.Controls.Add(this.LLastName);
            this.Controls.Add(this.TBFName);
            this.Controls.Add(this.LFName);
            this.Controls.Add(this.TBUsername);
            this.Controls.Add(this.LUserName);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FindClientForm";
            this.Text = "Find client";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpDateClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpdPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMinus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPlus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFCID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFCUN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFCBEM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFCBPN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBON)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBOFF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpaidOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMakePDFClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClientChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientOrderTour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFlightTicket)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.OpenFileDialog OFDAddPic;
        private System.Windows.Forms.Label LError;
        private System.Windows.Forms.Label LPicName;
        private System.Windows.Forms.PictureBox PBUpDateClient;
        private System.Windows.Forms.PictureBox PBClientPic;
        private System.Windows.Forms.PictureBox PBUpdPic;
        private System.Windows.Forms.Label LPic;
        private System.Windows.Forms.TextBox TBPhone;
        private System.Windows.Forms.Label LPhone;
        private System.Windows.Forms.TextBox TBEmail;
        private System.Windows.Forms.Label LEmail;
        private System.Windows.Forms.Label LID;
        private System.Windows.Forms.Label LAge;
        private System.Windows.Forms.TextBox TBCity;
        private System.Windows.Forms.Label LCity;
        private System.Windows.Forms.TextBox TBAddress;
        private System.Windows.Forms.Label LAddress;
        private System.Windows.Forms.TextBox TBLName;
        private System.Windows.Forms.Label LLastName;
        private System.Windows.Forms.TextBox TBFName;
        private System.Windows.Forms.Label LFName;
        private System.Windows.Forms.TextBox TBUsername;
        private System.Windows.Forms.Label LUserName;
        private System.Windows.Forms.Label LShowAge;
        private System.Windows.Forms.PictureBox PBMinus;
        private System.Windows.Forms.PictureBox PBPlus;
        private System.Windows.Forms.TextBox TBID;
        private System.Windows.Forms.PictureBox PBFCID;
        private System.Windows.Forms.PictureBox PBFCUN;
        private System.Windows.Forms.PictureBox PBFCBEM;
        private System.Windows.Forms.PictureBox PBFCBPN;
        private System.Windows.Forms.Label LActiveornot;
        private System.Windows.Forms.Label LActivity;
        private System.Windows.Forms.PictureBox PBON;
        private System.Windows.Forms.PictureBox PBOFF;
        private System.Windows.Forms.ComboBox CBClientList;
        private System.Windows.Forms.Label LCounter;
        private System.Windows.Forms.Label LUnpaid;
        private System.Windows.Forms.PictureBox PBUpaidOrders;
        private System.Windows.Forms.PictureBox PBClientOrders;
        private System.Windows.Forms.PictureBox PBMakePDFClient;
        private System.Windows.Forms.DataVisualization.Charting.Chart ClientChart;
        private System.Windows.Forms.SaveFileDialog SFDSaveClientFile;
        private System.Windows.Forms.PictureBox PBClientOrderTour;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.PictureBox PBFlightTicket;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}