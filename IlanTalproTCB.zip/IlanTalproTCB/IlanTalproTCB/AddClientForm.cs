﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    public partial class AddClientForm : Form
    {
        Function f1 = new Function();//Functions to check input data 
        Client Client_c = new Client();//The new client class

        /*
        In this Form you add client to the database
        */
        public AddClientForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();//date and a clock
                SetDates();// set date time picker

                OFDAddPic.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";//filter to get only picters
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }

        /*
        Set date time picker, client cant pick a birthday as future date
        */
        private void SetDates()
        {
            DTPClentBD.MaxDate = DateTime.Now;
            DTPClentBD.Value = DateTime.Now;
        }

        /*
        Show date and a clock on the Label
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }

        /*
        Exit the program from Exit Button
        User need to conform the exit
        use fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        /*
        Return to the last Form
        if its no permission its return to the Login menu
        if its worker permission its return to the worker menu
        if its manager permission its return to the manager menu
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            if (LoginForm.PKID==-1)
            {
                var LoginForm = new LoginForm();
                LoginForm.Closed += (s, args) => this.Close();
                LoginForm.Show();
                this.Hide();
            }
            else if (LoginForm.PKID != -1 && LoginForm.Permission== "Worker")
            {
                var WorkerMenuForm = new WorkerMenuForm();
                WorkerMenuForm.Closed += (s, args) => this.Close();
                WorkerMenuForm.Show();
                this.Hide();
            }
            else if (LoginForm.PKID != -1 && LoginForm.Permission == "Manager")
            {
                var ManagerMenuForm = new ManagerMenuForm();
                ManagerMenuForm.Closed += (s, args) => this.Close();
                ManagerMenuForm.Show();
                this.Hide();
            }
        }

        /*
        Add pic to client and copy pic to the client folder, dont copy if the pic its in the folder already
        */
        private void PBAddPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                
                if (!new System.IO.FileInfo(@"Pic\Clients\" + OFDAddPic.SafeFileName).Exists)
                {
                    System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Clients\" + OFDAddPic.SafeFileName);
                }
                PBClientPic.Image = Image.FromFile(@"Pic\Clients\" + OFDAddPic.SafeFileName);
                LPicName.Text = OFDAddPic.SafeFileName;
            }
        }
        /*
        Add client check the client data if the client data is suitable
        and if ID, email, username and phone number its a not exists 
        and add it to the Database
        */
        private void PBAddClient_Click(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "User name needs 8-4 characters long and first 3 characters are letters \n";
            }
            f1.CheckPassword(TBPassword.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Password must contain 10 characters long \n";
            }
            f1.CheckID(TBID.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Worng ID\n";
            }
            f1.CheckPhone(TBPhone.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Phone must contain 10 digits\n";
            }
            f1.CheckDOB(DateTime.Parse(DTPClentBD.Text));
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Age must be number between 18 to 130\n";
            }
            f1.CheckName(TBFName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "First name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckName(TBLName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Last name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckAddress(TBAddress.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Address must have at least 6 characters long and no number in the first 3 characters and finish with number\n";
            }
            f1.CheckName(TBCity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "City must Start with Capital letter and over 3 letters long\n";
            }
            f1.CheckEmail(TBEmail.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Wrong Email\n";
            }
            if (LPicName.Text.Length<2)
            {
                flag = false;
                str += "Add picture\n";
            }
            LError.Text = str;
            if (flag)
            {
                f1.Checkdup(TBID.Text,"ID", "Clients");
                if (f1.GetAnswer()==false)
                {
                    flag = false;
                    str += "There is a Client with the same ID \n";
                }
                f1.Checkdup(TBUsername.Text, "UserName", "Clients");
                if (f1.GetAnswer() == false)
                {
                    flag = false;
                    str += "There is a Client with the same User name \n";
                }
                f1.Checkdup(TBEmail.Text, "Email", "Clients");
                if (f1.GetAnswer() == false)
                {
                    flag = false;
                    str += "There is a Client with the same Email \n";
                }
                f1.Checkdup(TBPhone.Text, "PhoneNumber", "Clients");
                if (f1.GetAnswer() == false)
                {
                    flag = false;
                    str += "There is a Client with the same Phone Number \n";
                }
                LError.Text = str;
                if (flag)
                {
                    int m = f1.MakePKID("Clients")+1;
                    Client_c = new Client(m,TBFName.Text, TBLName.Text, TBAddress.Text, DTPClentBD.Text, TBCity.Text, TBUsername.Text,TBPassword.Text ,LPicName.Text,TBID.Text,TBEmail.Text,TBPhone.Text,true);
                    Client_c.AddClientToDB();
                    LError.Text = Client_c.GetFirstName()+" "+ Client_c.GetLastName()+" Added To data base";
                }
            }
        }

        /*
        TB for ID and Phone number get only digits chars
        */
        private void TBID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) )
            {
                e.Handled = true;
            }
        }
        private void TBPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        /*
        button change color when mouse hover and leave
        and tooltip show the text
        */
        private void PBAddClient_MouseHover(object sender, EventArgs e)
        {
            TTMouseHover.Show("Add client", PBAddClient);
            PBAddClient.BackColor = Color.WhiteSmoke;
        }
        private void PBAddClient_MouseLeave(object sender, EventArgs e)
        {
            PBAddClient.BackColor = Color.Transparent;
        }

        private void PBAddPic_MouseHover(object sender, EventArgs e)
        {
            TTMouseHover.Show("Add pic", PBAddPic);
            PBAddPic.BackColor = Color.WhiteSmoke;
        }
        private void PBAddPic_MouseLeave(object sender, EventArgs e)
        {
            PBAddPic.BackColor = Color.Transparent;
        }

        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            TTMouseHover.Show("Exit", PBExit);
            PBExit.BackColor = Color.WhiteSmoke;
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            TTMouseHover.Show("Back", PBBack);
            PBBack.BackColor = Color.WhiteSmoke;
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }
        /*
        timer fade
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tool tip drow background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
