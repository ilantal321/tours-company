﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.OleDb;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
namespace IlanTalproTCB
{

    class Function
    {
        private bool Answer;
        /*
        constractor
        */
        public Function()
        {
            Answer = true;
        }
        public Function(bool a)
        {
            Answer = a;
        }
        /*
        get and set
        */
        public bool GetAnswer()
        {
            return Answer;
        }
        public void SetAnswer(bool a)
        {
            Answer = a;
        }
        /*
        check password
        10 chars long
        and its digits and letters only
        */
        public void CheckPassword(string Password)
        {
            if (Password.Length != 10)
            {
                Answer= false;
                return;
            }
            int i = 0;
            for (i = 0; i < 10; i++)
            {
                if (!((Password[i] >= 'A' && Password[i] <= 'Z') || (Password[i] >= 'a' && Password[i] <= 'z') || (Password[i] >= '0' && Password[i] <= '9')))
                {
                    Answer= false;
                    return;
                }
            }
            Answer= true;
        }
        /*
        check username
        first capital letter
        4-8 chars long
        first 3 are letters other can be digits
        */
        public void CheckUsername(string username)
        {
            if (username.Length > 8 || username.Length < 4)
            {
                Answer = false;
                return;
            }
            int i = 0;
            for (i = 0; i < 3; i++)
            {
                if (!((username[i] >= 'A' && username[i] <= 'Z') || (username[i] >= 'a' && username[i] <= 'z')))
                {
                    Answer = false;
                    return;
                }
            }
            for (i = 3; i < username.Length; i++)
            {
                if (!((username[i] >= 'A' && username[i] <= 'Z') || (username[i] >= 'a' && username[i] <= 'z') || (username[i] >= '0' && username[i] <= '9')))
                {
                    Answer = false;
                    return;
                }
            }
            Answer = true;
            return;
        }
        /*
        check Country
        at least 4 chars long
        first capital letter
        letters only
        */
        public void CheckCountry(string username)
        {
            if ( username.Length < 4)
            {
                Answer = false;
                return;
            }
            int i = 0;
            if (!((username[i] >= 'A' && username[i] <= 'Z') ))
            {
                Answer = false;
                return;
            }
            for (i = 1; i < username.Length; i++)
            {
                if (!((username[i] >= 'A' && username[i] <= 'Z') || (username[i] >= 'a' && username[i] <= 'z') || (username[i] == ' ' || username[i] == '-')))
                {
                    Answer = false;
                    return;
                }
            }
            Answer = true;
            return;
        }
        /*
        check if its a real ID
        */
        public void CheckID(string ID)
        {
            if (ID.Length != 9)
            {
                Answer = false;
                return;
            }
            int i = 0, sum = 0;
            for (i = 0; i < 9; i++)
            {
                if (!((ID[i] >= '0' && ID[i] <= '9')))
                {
                    Answer = false;
                    return;
                }
                if (i % 2 == 0)
                {
                    sum += (ID[i]) - '0';
                }
                else
                {
                    sum += (((ID[i]) - '0') * 2) / 10 + (((ID[i]) - '0') * 2) % 10;
                }

            }
            Answer = sum % 10 == 0;
        }
        /*
        check phone number
        10 digits long
        */
        public void CheckPhone(string Phone)
        {
            if (Phone.Length != 10)
            {
                Answer = false;
                return;
            }
            int i = 0;
            for (i = 0; i < 10; i++)
            {
                if (!((Phone[i] >= '0' && Phone[i] <= '9')))
                {
                    Answer = false;
                    return;
                }

            }
            Answer = true;
        }
        /*
        check if the age is more then 18 years
        */
        public void CheckDOB(DateTime DOB)
        {
            int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
            int dob = int.Parse(DOB.ToString("yyyyMMdd"));
            int age = (now - dob) / 10000;
            Answer = age >= 18;
        }
        /*
        check name
        at least 3 chars long
        first capital letter
        letters and spaces only
        */
        public void CheckName(string Name)
        {
            if (Name.Length < 3)
            {
                Answer = false;
                return;
            }
            if (!((Name[0] >= 'A' && Name[0] <= 'Z')))
            {
                Answer = false;
                return;
            }
            int i = 1;
            for (i = 1; i < Name.Length; i++)
            {
                if (!((Name[i] >= 'a' && Name[i] <= 'z'))&& !(Name[i] == ' ')&& !(Name[i] == '-'))
                {
                    if (!((Name[i] >= 'A' && Name[i] <= 'Z')) && !(Name[i-1] == ' ') && !(Name[i-1] == '-'))
                    {
                    Answer = false;
                    return;
                    }

                }
                if (Name[i] == ' ' && Name[i-1] == ' ')
                {
                    Answer = false;
                    return;
                }

            }
            if ((Name[i-1] == ' '))
            {
                Answer = false;
                return;
            }
            Answer = true;
        }
        /*
        check Address
        at least 5 chars long
        can have a letters and digits at the and
        */
        public void CheckAddress(string Address)
        {
            bool flag = false;
            if (Address.Length < 5 || Address.Length == 0)
            {
                Answer = false;
                return;
            }
            int i = 0;
            for (i = 0; i <3; i++)
            {
                if (!((Address[i] >= 'A' && Address[i] <= 'Z') || (Address[i] >= 'a' && Address[i] <= 'z')))
                {
                    Answer = false;
                    return;
                }

            }
            for (i = 3; i < Address.Length; i++)
            {
                if (!((Address[i] >= 'A' && Address[i] <= 'Z') || (Address[i] >= 'a' && Address[i] <= 'z') ))
                {
                    if (Address[i] != ' ')
                    {
                        Answer = false;
                        return;
                    }
                    else if ( i + 1 < Address.Length && Address[i+1] >= '0' && Address[i+1] <= '9')
                    {
                        i++;
                        break;
                    }
                }
            }
            for (; i < Address.Length; i++)
            {
                flag = true;
                if (!(Address[i] >= '0' && Address[i] <= '9'))
                {
                    Answer = false;
                    return;
                }
            }
            Answer = flag ;
        }
        /*
        cheack Email
        */
        public void CheckEmail(string Email)
        {
            Answer = false;
            Regex r = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            if (r.IsMatch(Email))
            {
                Answer = true;
            }
        }
        /*
        cheack salary
        from 4500 to 8000
        */
        public void CheackSalary(string Salary)
        {
            Answer = true;
            if (Salary == "")
            {
                Answer = false;
            }
            else if (int.Parse(Salary) < 4500 || int.Parse(Salary) > 8000)
            {
                Answer = false;
            }
        }
        /*
        check duplicate data in the database
        */
        public void Checkdup(string Data, string CHeader, string table)
        {
            string str = "";
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from " + table + " where " + CHeader + " = '" + Data + "'");
            while (dr.Read())
            {
                str += dr[CHeader];
            }
            dr.Close();
            connec.closeCon();
            Answer = (str == "");
        }
        /*
        check duplicate tourname on the same date
        */
        public void CheckTourdup(string Datadate, string Tname)
        {
            string str = "";
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Tours where Tour_Date = '" + Datadate+ "' and Tour_Name = '" +Tname+"';");
            while (dr.Read())
            {
                str += dr["Tour_Name"];
            }
            dr.Close();
            connec.closeCon();
            Answer = (str == "");
        }
        /*
        check duplicate flight number on the same date
        */
        public void CheckTourdupFN(string Datadate, string FN)
        {
            string str = "";
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Tours where Tour_Date = '" + Datadate + "' and Flight_number = '" + FN + "';");
            while (dr.Read())
            {
                str += dr["Tour_Name"];
            }
            dr.Close();
            connec.closeCon();
            Answer = (str == "");
        }
        public void CheckTourdupRFN(string Datadate, string FN, string days)
        {
            string str = "";
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Tours where Tour_Date = '" + Datadate + "' and Flight_number_Return = '" + FN + "' and Days = " + days + ";");
            while (dr.Read())
            {
                str += dr["Tour_Name"];
            }
            dr.Close();
            connec.closeCon();
            Answer = (str == "");
        }
        /*
        check duplicate of the same pic on the same tour
        */
        public void CheckPicdup(string Data1, string data2)
        {
            string str = "";
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Pics_Tours where Pic_Name = '" + Data1 + "' and TourID =" + data2);
            while (dr.Read())
            {
                str += dr["Pic_Name"];
            }
            dr.Close();
            connec.closeCon();
            Answer = (str == "");
        }
        /*
        make the next PKID
        */
        public int MakePKID( string table)
        {
            string str = "";
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select MAX(PKID) AS NPKID from " + table + ";");
            while (dr.Read())
            {
                str = dr["NPKID"].ToString();
            }
            dr.Close();
            connec.closeCon();
            if (str=="")
            {
                return 0;
            }
            return int.Parse(str);
        }
        /*
        cheack flight number
        8 chars long
        */
        public void CheckFNumber(string str)
        {
            if (str.Length==8 && int.Parse(str)!=0)
            {
                Answer = true;
            }
            else
            {
                Answer = false;
            }
        }
        /*
        cheack tour price
        must be more then 300$
        */
        public void CheckPrice(string str)
        {
            if (str.Length > 2)
            {
                if (int.Parse(str) > 299)
                {
                    Answer = true;
                }
                else
                {
                    Answer = false;
                }
            }
            else
            {
                Answer = false;
            }
        }
        /*
        cheack tour days
        more then 0 days
        */
        public void CheckDays(string str)
        {
            if (str.Length != 0 && int.Parse(str) != 0)
            {
                Answer = true;
            }
            else
            {
                Answer = false;
            }
        }
    }
}
