﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class Continent
    {
        private int PKID;
        private string ContinentName;
        /*
        constractor
        */
        public Continent(int ID, string CN)
        {
            PKID = ID;
            ContinentName = CN;
        }
        /*
        empty constractor
        */
        public Continent()
        {
        }
        /*
        constractor feom data base
        */
        public Continent(string CPKID)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Continents where PKID=" + CPKID + ";");
            while (dr.Read())
            {
                PKID = int.Parse(dr["PKID"].ToString());
                ContinentName = dr["ContinentName"].ToString();
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        get and set
        */
        public void SetPKID(int pk)
        {
            PKID = pk;
        }
        public void SetCountryName(string cn)
        {
            ContinentName = cn;
        }
        public int GetPKID()
        {
            return PKID;
        }
        public string GetContinentName()
        {
            return ContinentName;
        }
    }
}
