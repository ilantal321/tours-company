﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    update worker
    worker can update his data
    */
    public partial class UpdateWorkerForm : Form
    {
        sha1ceypto sh = new sha1ceypto();
        Function f1 = new Function();
        Myconn connec = new Myconn();
        Worker w = new Worker(LoginForm.PKID.ToString());
        public UpdateWorkerForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                OFDAddPic.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
                fillWorkerdata();
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill worker data in the form
        */
        public void fillWorkerdata()
        {
            TBAddress.Text = w.GeteAddress();
            TBUsername.Text = w.GetUserName();
            TBLName.Text = w.GetLastName();
            TBFName.Text = w.GetFirstName();
            LShowSalary.Text = w.GetSalary().ToString();
            LAddDate.Text = w.GetADate().ToString("dd/MM/yyyy");
            TBCity.Text = w.GetCity();
            LShowAge.Text = w.GetBirthdate();
            LShowID.Text = w.GetID();
            PBClientPic.Image = Image.FromFile(@"Pic\Workers\" + w.GetPic());
            LPicName.Text = w.GetPic();
        }
        /*
        date and clock
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        Exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            var WorkerMenuForm = new WorkerMenuForm();
            WorkerMenuForm.Closed += (s, args) => this.Close();
            WorkerMenuForm.Show();
            this.Hide();
        }
        /*
        put new pic
        */
        private void PBUpdPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                LPicName.Text = OFDAddPic.SafeFileName;
                if (!new System.IO.FileInfo(@"Pic\Workers\" + LPicName.Text).Exists)
                {
                    System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Workers\" + LPicName.Text);
                }
                PBClientPic.Image = Image.FromFile(@"Pic\Workers\" + LPicName.Text);
            }
        }
        /*
        update worker
        cheack input first and username duplicate
        */
        private void PBUpDateWorker_Click(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "User name needs 8-4 characters long and first 3 characters are letters \n";
            }
            f1.CheckName(TBFName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "First name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckName(TBLName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Last name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckAddress(TBAddress.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Address must have lest 6 characters long and no number in the first 3 characters and finish with number\n";
            }
            f1.CheckName(TBCity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "City must Start with Capital letter and more then 3 letters long\n";
            }
            if (LPicName.Text.Length < 2)
            {
                flag = false;
                str += "Add picture\n";
            }
            LError.Text = str;
            if (flag)
            {
                if (TBUsername.Text != w.GetUserName())
                {
                    f1.Checkdup(TBUsername.Text, "UserName", "Workers");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Worker with the same User name \n";
                    }
                }

                if (flag)
                {
                    w.SetUserName(TBUsername.Text);
                    w.SetFirstName(TBFName.Text);
                    w.SetLastName(TBLName.Text);
                    w.SetAddress(TBAddress.Text);
                    w.SetCity(TBCity.Text);
                    w.SetPic(LPicName.Text);
                    w.UpdateWorkerToDB();
                    str = "User updated";
                }
                LError.Text = str;
            }
        }
        /*
        update password
        */
        private void PBUpDatePassword_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckPassword(TBNP.Text);
            if (f1.GetAnswer() == false)
            {
                str += "new Password must have 10 chars long \n";
            }
            else
            {
                string pass1 = sh.GetSHA1(TBOP.Text);
                if (pass1 == w.GetPassword())
                {
                    if (TBCNP.Text == TBNP.Text)
                    {
                        w.UpdateWorkerPasswordToDB(sh.GetSHA1(TBNP.Text));
                        str = "Password Updated";
                        w = new Worker(LoginForm.PKID.ToString());
                    }
                    else
                    {
                        str = "New password and confirm password are not the same\n";
                    }
                }
                else
                {
                    str = "Old Password Wrong\n";
                }
            }
            LError.Text = str;
        }
        /*
        hover and tooltip with mouse
        */
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }

        private void PBUpdPic_MouseHover(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update pic", PBUpdPic);
        }
        private void PBUpdPic_MouseLeave(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.Transparent;
        }

        private void PBUpDateClient_MouseHover(object sender, EventArgs e)
        {
            PBUpDateWorker.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update data", PBUpDateWorker);
        }
        private void PBUpDateClient_MouseLeave(object sender, EventArgs e)
        {
            PBUpDateWorker.BackColor = Color.Transparent;
        }

        private void PBUpDatePassword_MouseHover(object sender, EventArgs e)
        {
            PBUpDatePassword.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Change Passwoord", PBUpDatePassword);
        }
        private void PBUpDatePassword_MouseLeave(object sender, EventArgs e)
        {
            PBUpDatePassword.BackColor = Color.Transparent;
        }
        /*
        dade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tooltip background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }

    }
}
