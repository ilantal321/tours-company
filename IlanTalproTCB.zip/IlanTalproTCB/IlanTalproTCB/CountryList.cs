﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class CountryList
    {
        public List<Country> Countrys = new List<Country>();
        /*
        constractor
        */
        public CountryList()
        {
            Countrys.Clear();
            Country c = new Country();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Countries ORDER BY PKID");
            while (dr.Read())
            {
                c = new Country(int.Parse(dr["PKID"].ToString()), int.Parse(dr["ContinentPKID"].ToString()), dr["CountryName"].ToString());
                Countrys.Add(c);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by continent
        */
        public CountryList(int ConPKID)
        {
            Countrys.Clear();
            Country c = new Country();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Countries where ContinentPKID= "+ConPKID+" ORDER BY PKID");
            while (dr.Read())
            {
                c = new Country(int.Parse(dr["PKID"].ToString()), int.Parse(dr["ContinentPKID"].ToString()), dr["CountryName"].ToString());
                Countrys.Add(c);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        get and set
        */
        public List<Country> getCountryList()
        {
            return Countrys;
        }
        public void SetCountryList(List<Country> c)
        {
            Countrys = c;
        }
    }
}
