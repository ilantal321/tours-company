﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    class ClientList
    {
        public List<Client> Clients = new List<Client>();
        /*
        constractor
        */
        public ClientList()
        {
            Clients.Clear();
            Client c = new Client();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Clients ORDER BY PKID");
            while (dr.Read())
            {
                c = new Client(int.Parse(dr["PKID"].ToString()), dr["FirstName"].ToString(), dr["LastName"].ToString(), dr["Address"].ToString(), dr["Birthdate"].ToString(), dr["City"].ToString(), dr["UserName"].ToString(), dr["Passw"].ToString(), dr["Pic"].ToString(), dr["ID"].ToString(), dr["Email"].ToString(), dr["PhoneNumber"].ToString(), bool.Parse(dr["active"].ToString()));
                Clients.Add(c);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        Set and get
        */
        public void SetClientList(List<Client> c)
        {
            Clients = c;
        }
        public List<Client> GetClientList()
        {
            return Clients;
        }
        /*
        find client in the list
        */
        public Client FindClientbyID(string ID)
        {
            Client c = new Client();
            var result = from s in Clients where s.GetID() == ID select s;
            foreach (var Clients in result)
            {
                c = Clients;
            }
            return c;
        }
        public Client FindClientbyUN(string UN)
        {
            Client c = new Client();
            var result = from s in Clients where s.GetUserName() == UN select s;
            foreach (var Clients in result)
            {
                c = Clients;
            }
            return c;
        }
        public Client FindClientbyEMail(string Email)
        {
            Client c = new Client();
            var result = from s in Clients where s.GetMail() == Email select s;
            foreach (var Clients in result)
            {
                c = Clients;
            }
            return c;
        }
        public Client FindClientbyPN(string PN)
        {
            Client c = new Client();
            var result = from s in Clients where s.GetPhoneNumber() == PN select s;
            foreach (var Clients in result)
            {
                c = Clients;
            }
            return c;
        }
    }
}
