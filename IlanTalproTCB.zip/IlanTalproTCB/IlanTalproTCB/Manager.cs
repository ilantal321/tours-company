﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Security.Cryptography;

namespace IlanTalproTCB
{
    class Manager : Worker
    {
        private string Job;
        private int Department;
        /*
        empty constractor
        */
        public Manager()
        {

        }
        /*
        constractor
        */
        public Manager(int pid, string FN, string LN, string Add, string BD, string icity, string UN, string PS, string iPic, string id, int s, string j, int dep,bool a)
            : base(pid,FN, LN, Add, BD, icity, UN, PS, iPic, id,s,a)
        {
            Job = j;
            Department = dep;
        }
        /*
        constractor by database
        */
        public Manager(string MPKID)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Managers where PKID=" + MPKID + ";");
            while (dr.Read())
            {
                PKID = int.Parse(dr["PKID"].ToString());
                FirstName = dr["FirstName"].ToString();
                LastName = dr["LastName"].ToString();
                Address = dr["Address"].ToString();
                birthdate = dr["Birthdate"].ToString();
                City = dr["City"].ToString();
                UserName = dr["UserName"].ToString();
                Password = dr["Passw"].ToString();
                Pic = dr["Pic"].ToString();
                ID = dr["ID"].ToString();
                Salary = int.Parse(dr["Salary"].ToString());
                DateAbsorption = Convert.ToDateTime(dr["DateAbsorption"]);
                Activity = (bool)dr["active"];
                Job = dr["Job"].ToString();
                Department = int.Parse(dr["Department"].ToString());
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        get and set
        */
        public void SetJob(string j)
        {
            Job = j;
        }
        public void SetDep(int dep)
        {
            Department = dep;
        }
        public string GetJob()
        {
            return Job;
        }
        public int Getdep()
        {
            return Department;
        }
        /*
        get Department from database
        */
        public string GetDepartment()
        {
            string dep = "";
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Departments where PKID=" + Department + ";");
            while (dr.Read())
            {
                dep = dr["Department"].ToString();
            }
            dr.Close();
            connec.closeCon();
            return dep;
        }
        /*
        update manager data
        */
        public void UpdateManagerToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("UPDATE Managers SET UserName = '" + UserName + "', FirstName = '" + FirstName + "' , LastName = '" + LastName + "' , Address = '" + Address + "' , City= '" + City + "' , Pic='" + Pic + "' , Job='" + Job + "' WHERE PKID = " + PKID + " ;");
            dr.Close();
            connec.closeCon();
        }
        /*
        update manager password
        */
        public void UpdateManagerPasswordToDB(string newpassword)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("UPDATE Managers SET Passw ='" + newpassword + "' WHERE PKID = " + PKID + "; ");
            dr.Close();
            connec.closeCon();
        }
        public string PrintManager => base.PrintWorker
                   + string.Format(" \nJob:" + Job + " \nDepartment:"+ Department);
    }
}
