﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    worker and manager can add country and change country name
    */
    public partial class AddCountryForm : Form
    {
        Function f1 = new Function();
        Country Country1 = new Country();
        ContinentList Continentslist = new ContinentList();
        CountryList countryList = new CountryList();
        int ContinentIndex = 0, CountryIndex= 0;

        public AddCountryForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                FillCBContinent();
                FillCBCountry();
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill country combobox with names
        */
        public void FillCBCountry()
        {
            CBCountrys.Items.Clear();
            foreach (Country i in countryList.getCountryList())
            {
                CBCountrys.Items.Add(i.GetCountryName());
            }
            CBCountrys.SelectedIndex = CountryIndex;
        }
        /*
        fill continent combobox with names
        */
        public void FillCBContinent()
        {
            CBContinent.Items.Clear();
            foreach (Continent i in Continentslist.GetContinentsList())
            {
                CBContinent.Items.Add(i.GetContinentName());
            }
            CBContinent.SelectedIndex = ContinentIndex;
        }
        /*
        date and clock timer
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        Exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        go to last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            if (LoginForm.PKID != -1 && LoginForm.Permission == "Worker")
            {
                var WorkerMenuForm = new WorkerMenuForm();
                WorkerMenuForm.Closed += (s, args) => this.Close();
                WorkerMenuForm.Show();
                this.Hide();
            }
            else if (LoginForm.PKID != -1 && LoginForm.Permission == "Manager")
            {
                var ManagerMenuForm = new ManagerMenuForm();
                ManagerMenuForm.Closed += (s, args) => this.Close();
                ManagerMenuForm.Show();
                this.Hide();
            }
        }
        /*
        add/update country to data base
        */
        private void PBAddCountry_Click(object sender, EventArgs e)
        {
            f1.CheckCountry(TBCountryName.Text);
            if (f1.GetAnswer())
            {
                f1.Checkdup(TBCountryName.Text, "CountryName", "Countries");
                if (f1.GetAnswer() == false)
                {
                    LError.Text = "There is a Country with the same Name \n";
                }
                else
                {
                    int m = f1.MakePKID("Countries") + 1;
                    Country1 = new Country(m, Continentslist.GetContinentsList()[ContinentIndex].GetPKID(), TBCountryName.Text);
                    Country1.AddCountryToDB();
                    CBCountrys.Items.Add(Country1.GetCountryName());
                    countryList.getCountryList().Add(Country1);
                    LError.Text = "Country Added\n";
                }
            }
            else
            {
                LError.Text = "Worng Country name\n\n";
            }
        }
        private void PBUpdateCountry_Click(object sender, EventArgs e)
        {
            if (TBCountryName.Text == CBCountrys.SelectedItem.ToString())
            {
                LError.Text = "Same Country name";
            }
            else
            {
                f1.CheckCountry(TBCountryName.Text);
                if (f1.GetAnswer())
                {
                    f1.Checkdup(TBCountryName.Text, "CountryName", "Countries");
                    if (f1.GetAnswer() == false)
                    {
                        LError.Text = "There is a Country with the same Name \n";
                    }
                    else
                    {
                        countryList.getCountryList()[CountryIndex].SetCountryName(TBCountryName.Text);
                        countryList.getCountryList()[CountryIndex].SetContinentPKID(Continentslist.GetContinentsList()[ContinentIndex].GetPKID());
                        countryList.getCountryList()[CountryIndex].UpdateCountryName();
                        LError.Text = "Country name Updated\n";
                        CBCountrys.Items[CountryIndex] = TBCountryName.Text;
                    }
                }
                else
                {
                    LError.Text = "Worng Country name\n";
                }
            }
        }
        /*
        change combobox selected index
        */
        private void CBContinent_SelectedIndexChanged(object sender, EventArgs e)
        {
            ContinentIndex = CBContinent.SelectedIndex;
        }
        private void CBCountrys_SelectedIndexChanged(object sender, EventArgs e)
        {
            CountryIndex = CBCountrys.SelectedIndex;
        }
        /*
        hover and tooltip mouse hover
        */
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }
        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }
        private void PBAddCountry_MouseHover(object sender, EventArgs e)
        {
            PBAddCountry.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add country", PBAddCountry);
        }
        private void PBAddCountry_MouseLeave(object sender, EventArgs e)
        {
            PBAddCountry.BackColor = Color.Transparent;
        }
        private void PBUpdateCountry_MouseHover(object sender, EventArgs e)
        {
            PBUpdateCountry.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Change country name", PBUpdateCountry);
        }
        private void PBUpdateCountry_MouseLeave(object sender, EventArgs e)
        {
            PBUpdateCountry.BackColor = Color.Transparent;
        }
        /*
        fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tool tip background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }

    }
}
