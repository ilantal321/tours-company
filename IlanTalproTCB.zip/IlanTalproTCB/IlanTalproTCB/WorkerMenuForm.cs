﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    worker menu form
    update data, add/find tour, add/find client, add country
    */
    public partial class WorkerMenuForm : Form
    {
        Function f1 = new Function();
        Worker w = new Worker( LoginForm.PKID.ToString());
        ReceiptList rl = new ReceiptList();
        public WorkerMenuForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                rl.BuildReceiptsByUnpaid();
                LShowWorkerData.Text = rl.PrintReceiptsDataWorker();
                LHeader.Text = "Welcome " + w.GetFirstName() + " "+w.GetLastName()+ " to I.T travel company";
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        date and clock
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        open other forms
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
            
            var LoginForm = new LoginForm();
            LoginForm.Closed += (s, args) => this.Close();
            LoginForm.Show();
            this.Hide();
        }
        private void BtnMakeTicket_Click(object sender, EventArgs e)
        {
            var FlightTicketForm = new FlightTicketForm();
            FlightTicketForm.Closed += (s, args) => this.Close();
            FlightTicketForm.Show();
            this.Hide();
        }
        private void PBUpDataWorker_Click(object sender, EventArgs e)
        {
            var UPWorkerForm = new UpdateWorkerForm();
            UPWorkerForm.Closed += (s, args) => this.Close();
            UPWorkerForm.Show();
            this.Hide();
        }
        private void PBAddCountries_Click(object sender, EventArgs e)
        {
            var AddCountryForm = new AddCountryForm();
            AddCountryForm.Closed += (s, args) => this.Close();
            AddCountryForm.Show();
            this.Hide();
        }
        private void PBAddClient_Click(object sender, EventArgs e)
        {
            var AddClientForm = new AddClientForm();
            AddClientForm.Closed += (s, args) => this.Close();
            AddClientForm.Show();
            this.Hide();
        }
        private void PBFindClient_Click(object sender, EventArgs e)
        {
            var UPWorkeFindClientForm = new FindClientForm();
            UPWorkeFindClientForm.Closed += (s, args) => this.Close();
            UPWorkeFindClientForm.Show();
            this.Hide();
        }
        private void PBAddTour_Click(object sender, EventArgs e)
        {
            var addtour = new AddTourForm();
            addtour.Closed += (s, args) => this.Close();
            addtour.Show();
            this.Hide();
        }
        private void PBFindTour_Click(object sender, EventArgs e)
        {
            var UpdateTourForm = new FindTour();
            UpdateTourForm.Closed += (s, args) => this.Close();
            UpdateTourForm.Show();
            this.Hide();
        }
        /*
        mouse hover and leave
        */
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }

        private void PBUpDataWorker_MouseHover(object sender, EventArgs e)
        {
            PBUpDataWorker.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update your data", PBUpDataWorker);
        }
        private void PBUpDataWorker_MouseLeave(object sender, EventArgs e)
        {
            PBUpDataWorker.BackColor = Color.Transparent;
        }

        private void PBAddCountries_MouseHover(object sender, EventArgs e)
        {
            PBAddCountries.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add Countries", PBAddCountries);
        }
        private void PBAddCountries_MouseLeave(object sender, EventArgs e)
        {
            PBAddCountries.BackColor = Color.Transparent;
        }

        private void PBAddClient_MouseHover(object sender, EventArgs e)
        {
            PBAddClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add client", PBAddClient);
        }
        private void PBAddClient_MouseLeave(object sender, EventArgs e)
        {
            PBAddClient.BackColor = Color.Transparent;
        }

        private void PBFindClient_MouseHover(object sender, EventArgs e)
        {
            PBFindClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find Clients", PBFindClient);
        }
        private void PBFindClient_MouseLeave(object sender, EventArgs e)
        {
            PBFindClient.BackColor = Color.Transparent;
        }

        private void PBAddTour_MouseHover(object sender, EventArgs e)
        {
            PBAddTour.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add Tour", PBAddTour);
        }
        private void PBAddTour_MouseLeave(object sender, EventArgs e)
        {
            PBAddTour.BackColor = Color.Transparent;
        }

        private void PBFindTour_MouseHover(object sender, EventArgs e)
        {
            PBFindTour.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find tour", PBFindTour);
        }
        private void PBFindTour_MouseLeave(object sender, EventArgs e)
        {
            PBFindTour.BackColor = Color.Transparent;
        }
        /*
        Fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tool tip background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }


    }
}
