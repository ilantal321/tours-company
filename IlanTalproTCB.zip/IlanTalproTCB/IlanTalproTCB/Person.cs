﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IlanTalproTCB
{
    class Person
    {
        protected int PKID;
        protected string FirstName;
        protected string LastName;
        protected string Address;
        protected string birthdate;
        protected string City;
        protected string UserName;
        protected string Password;
        protected string Pic;
        protected string ID;
        protected bool Activity;
        /*
        empty constractor
        */
        public Person()
        {

        }
        /*
        constractor
        */
        public Person(int pid,string FN,string LN ,string Add, string BD,string icity,string UN , string PS, string iPic,string id,bool a)
        {
            PKID = pid;
            FirstName = FN;
            LastName = LN;
            Address = Add;
            birthdate = BD;
            City = icity;
            UserName = UN;
            Password = PS;
            Pic = iPic;
            ID = id;
            Activity = a;
        }
        /*
        copy constractor
        */
        public Person(Person p)
        {
            PKID = p.PKID;
            FirstName = p.FirstName;
            LastName = p.LastName;
            Address =p.Address;
            birthdate = p.birthdate;
            City = p.City;
            UserName = p.UserName;
            Password = p.Password;
            Pic = p.Pic;
            ID = p.ID;
            Activity = p.Activity;
        }
        /*
        get and set
        */
        public void SetPKID(int pid)
        {
            PKID = pid;
        }
        public void SetActivity(bool a)
        {
            Activity = a;
        }
        public void SetFirstName(string FN)
        {
            FirstName = FN;
        }
        public void SetLastName(string LN)
        {
            LastName = LN;
        }
        public void SetAddress(string Add)
        {
            Address = Add;
        }
        public void Setbirthdate(string BD)
        {
            birthdate = BD;
        }
        public void SetCity(string city)
        {
            City = city;
        }
        public void SetUserName(string UN)
        {
            UserName = UN;
        }
        public void SetPassword(string PS)
        {
            Password = PS;
        }
        public void SetPic(string pic)
        {
            Pic = pic;
        }
        public void SetID(string id)
        {
            ID = id;
        }
        public string GetFirstName()
        {
            return FirstName;
        }
        public string GetLastName()
        {
            return LastName;
        }
        public string GeteAddress()
        {
            return Address;
        }
        public string GetBirthdate()
        {
            return birthdate;
        }
        public string GetCity()
        {
            return City;
        }
        public string GetUserName()
        {
            return UserName;
        }
        public string GetPassword()
        {
            return Password;
        }
        public string GetPic()
        {
            return Pic;
        }
        public string GetID()
        {
            return ID;
        }
        public bool GetActivity()
        {
            return Activity;
        }
        public int GetPKID()
        {
            return PKID;
        }
        /*
        print data
        */
        public string PrintPerson()
        {
            string str = "";
            str = "PKID: " + PKID.ToString()+"\nID: " + ID + "\nName: " + FirstName+" "+ LastName + "\nAddress: " + Address + "\nBirthdate: " + birthdate + "\nCity: " + City + "\nUsername:"+ UserName+"\nActivity="+Activity;
            return str;
        }
        /*
        show age
        */
        public int ShowAge()
        {
            int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
            int dob = int.Parse(DateTime.Parse(birthdate).ToString("yyyyMMdd"));
            int age = (now - dob) / 10000;
            return age;
        }
    }
}
