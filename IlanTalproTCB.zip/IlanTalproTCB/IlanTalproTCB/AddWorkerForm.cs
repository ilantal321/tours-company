﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    add worker form
    add worker to the data base
    */
    public partial class AddWorkerForm : Form
    {
        sha1ceypto sh = new sha1ceypto();
        Function f1 = new Function();
        Worker w = new Worker();
        public AddWorkerForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                SetDates();
                TDate.Start();
                OFDAddPic.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        Set date time picker, client cant pick a birthday as future date
        */
        private void SetDates()
        {
            DTPWorkerBD.MaxDate = DateTime.Now;
            DTPWorkerBD.Value = DateTime.Now;
        }
        /*
        Show date and a clock on the Label
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }

        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        /*
        Exit the program from Exit Button
        User need to conform the exit
        use fade timer
        */
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        Return to the last Form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {

            var ManagerMenuForm = new ManagerMenuForm();
            ManagerMenuForm.Closed += (s, args) => this.Close();
            ManagerMenuForm.Show();
            this.Hide();
        }
        /*
        add pic
        */
        private void PBAddPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                LPicName.Text = OFDAddPic.SafeFileName;
                if (!new System.IO.FileInfo(@"Pic\Workers\" + LPicName.Text).Exists)
                {
                    System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Workers\" + LPicName.Text);
                }
                PBClientPic.Image = Image.FromFile(@"Pic\Workers\" + LPicName.Text);
            }
        }
        /*
        add worker
        */
        private void PBAddClient_Click(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "User name need 8-4 characters long and first 3 characters are letters \n";
            }
            f1.CheckPassword(TBPassword.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Password must have 10 characters long \n";
            }
            f1.CheckID(TBID.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Worng ID \n";
            }
            f1.CheckDOB(DateTime.Parse(DTPWorkerBD.Text));
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Age must be number more then 18\n";
            }
            f1.CheckName(TBFName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "First name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckName(TBLName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Last name must Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckAddress(TBAddress.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Address must have lest 6 characters long and no number in the first 3 characters and finish with number\n";
            }
            f1.CheckName(TBCity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "City must Start with Capital letter and over 3 letters long\n";
            }
            if (LPicName.Text.Length<2)
            {
                flag = false;
                str += "Add picture\n";
            }
            f1.CheackSalary(TBSalary.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Salary must be between 4500-8000\n";
            }
            LError.Text = str;
            if (flag)
            {
                f1.Checkdup(TBID.Text,"ID", "Workers");
                if (f1.GetAnswer()==false)
                {
                    flag = false;
                    str += "There is a Worker with the same ID \n";
                }
                f1.Checkdup(TBUsername.Text, "UserName", "Workers");
                if (f1.GetAnswer() == false)
                {
                    flag = false;
                    str += "There is a Worker with the same User name \n";
                }

                LError.Text = str;
                if (flag)
                {
                    int m = f1.MakePKID("Workers")+1;
                    w = new Worker(m,TBFName.Text, TBLName.Text, TBAddress.Text, DTPWorkerBD.Text, TBCity.Text, TBUsername.Text,sh.GetSHA1(TBPassword.Text) ,LPicName.Text,TBID.Text, int.Parse(TBSalary.Text), true);
                    w.AddWorkerToDB();
                    LError.Text = w.PrintWorker;
                }
            }
        }
        /*
        ID, salary get only digits
        */
        private void TBID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) )
            {
                e.Handled = true;
            }
        }
        private void TBSalary_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        /*
        button change color when mouse hover and leave
        and tooltip show the text
        */
        private void PBAddClient_MouseHover(object sender, EventArgs e)
        {
            PBAddClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add worker", PBAddClient);
        }

        private void PBAddClient_MouseLeave(object sender, EventArgs e)
        {
            PBAddClient.BackColor = Color.Transparent;
        }

        private void PBAddPic_MouseHover(object sender, EventArgs e)
        {
            PBAddPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update pic", PBAddPic);
        }

        private void PBAddPic_MouseLeave(object sender, EventArgs e)
        {
            PBAddPic.BackColor = Color.Transparent;
        }

        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }

        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }

        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }
        /*
        timer fade
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tool tip drow background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
