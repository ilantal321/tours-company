﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    find worker form
    manager can find workers
    */
    public partial class FindWorkerForm : Form
    {
        sha1ceypto sh = new sha1ceypto();
        Function f1 = new Function();
        Myconn connec = new Myconn();
        Worker w = new Worker();
        WorkerList Workers = new WorkerList();
        int i = 0;
        public FindWorkerForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                OFDAddPic.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
                if (Workers.GetWorkerList().Count != 0)
                {
                    WorkerChart.Titles.Add("Worker Orders chart");
                    w = Workers.GetWorkerList()[i];
                    FillCBWorkers();
                }
                else
                {
                    PBMinus.Visible = false;
                    PBPlus.Visible = false;
                    PBUpDateWorker.Visible = false;
                    PBUpdPic.Visible = false;
                    PBON.Visible = false;
                    PBOFF.Visible = false;
                    PBShowWorkerDataFile.Visible = false;
                }
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill worker combobox
        */
        public void FillCBWorkers()
        {
            CBWorkerList.Items.Clear();
            foreach (Worker work in Workers.GetWorkerList())
            {
                CBWorkerList.Items.Add(work.GetPKID() + " " + work.GetID() + " " + work.GetFirstName() + " " + work.GetLastName() + " " + work.GetUserName());
            }
            CBWorkerList.SelectedIndex = 0;
        }
        /*
        fill worker data in the form
        */
        public void fillWorkerdata()
        {
            foreach (var series in WorkerChart.Series)
            {
                series.Points.Clear();
            }
            WorkerChart.Series["s1"].IsValueShownAsLabel = true;
            WorkerChart.Series["s1"].Points.AddXY("Unpaid Orders", w.GetOrderCount().ToString());
            WorkerChart.Series["s1"].Points.AddXY("Paid Orders", w.GetOrderCount2().ToString());
            WorkerChart.Series["s1"].Points.AddXY("Canceled Orders", w.GetOrderCount3().ToString());
            TBAddress.Text = Workers.GetWorkerList()[i].GeteAddress();
            TBUsername.Text = Workers.GetWorkerList()[i].GetUserName();
            TBLName.Text = Workers.GetWorkerList()[i].GetLastName();
            TBFName.Text = Workers.GetWorkerList()[i].GetFirstName();
            LShowDateAbsorption.Text = Workers.GetWorkerList()[i].GetADate().ToString();
            TBPSalary.Text = Workers.GetWorkerList()[i].GetSalary().ToString();
            TBCity.Text = Workers.GetWorkerList()[i].GetCity();
            LShowAge.Text = Workers.GetWorkerList()[i].ShowAge().ToString();
            TBID.Text = Workers.GetWorkerList()[i].GetID();
            PBClientPic.Image = Image.FromFile(@"Pic\Workers\" + Workers.GetWorkerList()[i].GetPic());
            LPicName.Text = Workers.GetWorkerList()[i].GetPic();
            if (Workers.GetWorkerList()[i].GetActivity())
            {
                LActiveornot.Text = "Active";
                PBON.Visible = false;
                PBOFF.Visible = true;

            }
            else
            {
                LActiveornot.Text = "Inactive";
                PBON.Visible = true;
                PBOFF.Visible = false;
            }
            if (Workers.GetWorkerList()[i].GetPKID() == 8)
            {
                PBUpDateWorker.Visible = false;
            }
            else
            {
                PBUpDateWorker.Visible = true;
            }
        }
        /*
        date and clock
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        to last form
        */
        private void PBBack_Click(object sender, EventArgs e)
        {
                var ManagerMenuForm = new ManagerMenuForm();
                ManagerMenuForm.Closed += (s, args) => this.Close();
                ManagerMenuForm.Show();
                this.Hide();
        }
        /*
        update pic
        */
        private void PBUpdPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                LPicName.Text = OFDAddPic.SafeFileName;
                if (!new System.IO.FileInfo(@"Pic\Workers\" + LPicName.Text).Exists)
                {
                    System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Workers\" + LPicName.Text);
                }
                PBClientPic.Image = Image.FromFile(@"Pic\Workers\" + LPicName.Text);
            }
        }
        /*
        update worker
        */
        private void PBUpDateClient_Click(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "User name need 8-4 chars long and first 3 chars are letters \n";
            }
            f1.CheckName(TBLName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Last name Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheckAddress(TBAddress.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Address must have lest 6 chars long and no number in the first 3 chars and finish with number\n";
            }

            f1.CheckName(TBCity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "City Start with Capital letter and more then 3 letters long\n";
            }
            f1.CheackSalary(TBPSalary.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Salary must be between 4500-8000\n";
            }
            if (LPicName.Text.Length < 2)
            {
                flag = false;
                str += "Add picture\n";
            }
            LError.Text = str;
            if (flag)
            {
                if (TBUsername.Text != w.GetUserName())
                {
                    f1.Checkdup(TBUsername.Text, "UserName", "Clients");
                    if (f1.GetAnswer() == false)
                    {
                        flag = false;
                        str += "There is a Client with the same User name \n";
                    }
                }

                if (flag)
                {
                    i = Workers.GetWorkerList().IndexOf(w);
                    w.SetUserName(TBUsername.Text);
                    w.SetFirstName(TBFName.Text);
                    w.SetLastName(TBLName.Text);
                    w.SetAddress(TBAddress.Text);
                    w.SetCity(TBCity.Text);
                    w.SetSalary(int.Parse(TBPSalary.Text));
                    w.SetPic(LPicName.Text);
                    w.UpdateWorkerToDB();
                    str = "User updated";
                    Workers.GetWorkerList()[i] = w;
                }
                LError.Text = str;
            }
        }
        /*
        next/last worker
        */
        private void PBMinus_Click(object sender, EventArgs e)
        {
            i--;
            if (i<0)
            {
                i = Workers.GetWorkerList().Count-1;
            }
            w = Workers.GetWorkerList()[i];
            CBWorkerList.SelectedIndex = i;
        }
        private void PBPlus_Click(object sender, EventArgs e)
        {
            i++;
            if (i == Workers.GetWorkerList().Count)
            {
                i = 0;
            }
            w = Workers.GetWorkerList()[i];
            CBWorkerList.SelectedIndex = i;
        }
        /*
        find worker by iD, user name, 
        */
        private void PBFCID_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckID(TBID.Text);
            if (f1.GetAnswer() == false)
            {
                str += "Wrong ID";
            }
            else
            {
                w = Workers.FindWorkerbyID(TBID.Text);
                i = Workers.GetWorkerList().IndexOf(w);
                if (i != -1)
                {
                    CBWorkerList.SelectedIndex = i;
                    str = "User Found by ID";
                }
                else
                {
                    str = "User with that ID dont exist";
                }
            }
            LError.Text = str;
        }
        private void PBFCUN_Click(object sender, EventArgs e)
        {
            string str = "";
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer() == false)
            {
                str = "User name need 8-4 chars long and first 3 chars are letters \n";
            }
            else
            {
                w = Workers.FindWorkerbyUN(TBUsername.Text);
                i = Workers.GetWorkerList().IndexOf(w);
                if (i != -1)
                {
                    CBWorkerList.SelectedIndex = i;
                    str = "User Found by user name";
                }
                else
                {
                    str = "User with that User name dont exist";
                }
            }
            LError.Text = str;
        }
        /*
        activate/deactivate worker
        */
        private void PBON_Click(object sender, EventArgs e)
        {
            i = Workers.GetWorkerList().IndexOf(w);
            w.UpdateWorkerActivityToDB(true);
            Workers.GetWorkerList()[i] = w;
            fillWorkerdata();
            LError.Text = "User is now active";
        }

        private void PBOFF_Click(object sender, EventArgs e)
        {
            i = Workers.GetWorkerList().IndexOf(w);
            w.UpdateWorkerActivityToDB(false);
            Workers.GetWorkerList()[i] = w;
            fillWorkerdata();
            LError.Text = "User is now inactive";
        }
        /*
        make worker data PDF
        */
        private void BOShowWorkerDataFile_Click(object sender, EventArgs e)
        {
            if (SFDSavePDF.ShowDialog() == DialogResult.OK)
            {
                string Path = SFDSavePDF.FileName;
                this.WorkerChart.SaveImage("pic/MyClientChart.png", System.Drawing.Imaging.ImageFormat.Png);
                w.PrintWorkerDataPDF(System.IO.Path.GetFileNameWithoutExtension(SFDSavePDF.FileName), "pic/MyClientChart.png", System.IO.Path.GetDirectoryName(Path));
            }
        }
        /*
        button change color when mouse hover and leave
        and tooltip show the text
        */
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }

        private void PBUpdPic_MouseHover(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update pic", PBUpdPic);
        }

        private void PBUpdPic_MouseLeave(object sender, EventArgs e)
        {
            PBUpdPic.BackColor = Color.Transparent;
        }

        private void PBUpDateWorker_MouseHover(object sender, EventArgs e)
        {
            PBUpDateWorker.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update worker", PBUpDateWorker);
        }

        private void PBUpDateWorker_MouseLeave(object sender, EventArgs e)
        {
            PBUpDateWorker.BackColor = Color.Transparent;
        }
        private void PBFCUN_MouseHover(object sender, EventArgs e)
        {
            PBFCUN.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find worker username", PBFCUN);
        }

        private void PBFCUN_MouseLeave(object sender, EventArgs e)
        {
            PBFCUN.BackColor = Color.Transparent;
        }

        private void PBFCID_MouseHover(object sender, EventArgs e)
        {
            PBFCID.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find worker ID", PBFCID);
        }

        private void PBFCID_MouseLeave(object sender, EventArgs e)
        {
            PBFCID.BackColor = Color.Transparent;
        }

        private void PBOFF_MouseHover(object sender, EventArgs e)
        {
            PBOFF.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Deactivate worker", PBOFF);
        }
        private void PBOFF_MouseLeave(object sender, EventArgs e)
        {
            PBOFF.BackColor = Color.Transparent;
        }

        private void PBON_MouseHover(object sender, EventArgs e)
        {
            PBON.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Activate worker", PBON);
        }

        private void PBON_MouseLeave(object sender, EventArgs e)
        {
            PBON.BackColor = Color.Transparent;
        }

        private void PBMinus_MouseHover(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Last worker", PBMinus);
        }

        private void PBMinus_MouseLeave(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.Transparent;
        }

        private void PBPlus_MouseHover(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Next worker", PBPlus);
        }

        private void PBPlus_MouseLeave(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.Transparent;
        }
        private void BOShowWorkerDataFile_MouseHover(object sender, EventArgs e)
        {
            PBShowWorkerDataFile.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Make worker PDF data", PBShowWorkerDataFile);
        }

        private void BOShowWorkerDataFile_MouseLeave(object sender, EventArgs e)
        {
            PBShowWorkerDataFile.BackColor = Color.Transparent;
        }

        /*
        id and salary get only digits
        */
        private void TBID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBPSalary_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        /*
        chhange worker on combobox
        */
        private void CBWorkerList_SelectedIndexChanged(object sender, EventArgs e)
        {
            i = CBWorkerList.SelectedIndex;
            w = Workers.GetWorkerList()[i];
            fillWorkerdata();
        }
        /*
        fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tool tip drow background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
