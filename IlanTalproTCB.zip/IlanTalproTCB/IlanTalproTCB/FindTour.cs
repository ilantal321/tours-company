﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    find tour form user can find form and make a new one with difrent data
    */
    public partial class FindTour : Form
    {
        Function f1 = new Function();
        Tour t = new Tour();
        TourList tours = new TourList();
        PicsTourList picsTour = new PicsTourList();
        PicsTourList picsToTour= new PicsTourList();
        PicsTours pictour = new PicsTours();
        Country c = new Country();
        CountryList cl = new CountryList();
        int i = 0;
        int j = 0;
        int k = 0;
        public FindTour()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                DTPTour.Value = DateTime.Now;
                DTPTour.MinDate = DateTime.Now;
                TourChart.Titles.Add("Tour chart");
                if (tours.GetTourList().Count != 0)
                {
                    t = tours.GetTourList()[i];
                    FillCBCountry();
                    FillCBTime();
                    FillCBTours();
                    fillTourdata();
                }
                else
                {
                    PBMinus.Visible = false;
                    PBPlus.Visible = false;
                    PBMakePFDTourData.Visible = false;
                    PBAddTour.Visible = false;
                    PBAddPic.Visible = false;
                    PBAddTourPic.Visible = false;
                    PBDeletePic.Visible = false;
                    PBPicPlus.Visible = false;
                    PBPicMinus.Visible = false;
                }
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        fill combobox with countries
        */
        public void FillCBCountry()
        {
            CBCountry.Items.Clear();
            foreach (Country i in cl.getCountryList())
            {
                CBCountry.Items.Add(i.GetCountryName());
            }
            CBCountry.SelectedIndex = k;
            c = cl.getCountryList()[k];
        }
        /*
        fill the comboboxs with the hours and minutes times
        */
        public void FillCBTime()
        {
            for (int num = 0; num < 60; num++)
            {
                if (num < 10)
                {
                    CBHour.Items.Add("0" + num.ToString());
                    CBMinutes.Items.Add("0" + num.ToString());
                    CBHourReturn.Items.Add("0" + num.ToString());
                    CBMinutesReturn.Items.Add("0" + num.ToString());
                }
                else if (num < 24)
                {
                    CBHour.Items.Add(num.ToString());
                    CBHourReturn.Items.Add(num.ToString());
                    CBMinutesReturn.Items.Add(num.ToString());
                    CBMinutes.Items.Add(num.ToString());
                }
                else
                {
                    CBMinutesReturn.Items.Add(num.ToString());
                    CBMinutes.Items.Add(num.ToString());
                }
            }
            CBHour.SelectedIndex = 0;
            CBMinutes.SelectedIndex = 0;
            CBHourReturn.SelectedIndex = 0;
            CBMinutesReturn.SelectedIndex = 0;
        }
        /*
        fill the comboboxs with the tours in the database
        */
        public void FillCBTours()
        {
            CBToursList.Items.Clear();
            foreach (Tour i in tours.GetTourList())
            {
                Country cont = new Country(i.GetCountry());
                CBToursList.Items.Add(i.GetTourID() + " " + i.GetTourname() + " " + cont.GetCountryName() + " " + i.GetPrice());
            }

            CBToursList.SelectedIndex = k;
        }
        /*
        fill the form with tour data
        */
        public void fillTourdata()
        {
            foreach (var series in TourChart.Series)
            {
                series.Points.Clear();
            }
            TourChart.Series["s1"].IsValueShownAsLabel = true;
            TourChart.Series["s1"].Points.AddXY("Taken", tours.GetTourList()[i].getTourTakenSeats());
            TourChart.Series["s1"].Points.AddXY("Empty", tours.GetTourList()[i].GetCapacity());
            TBTourID.Text = tours.GetTourList()[i].GetTourID().ToString();
            TBFlightnumber.Text = tours.GetTourList()[i].GetFlight_numberID();
            TBPrice.Text = tours.GetTourList()[i].GetPrice().ToString();
            TBDays.Text = tours.GetTourList()[i].GetDay().ToString();
            TBCapacity.Text = tours.GetTourList()[i].GetCapacity().ToString();
            TBTourName.Text = tours.GetTourList()[i].GetTourname();
            RTBDisdescription.Text = tours.GetTourList()[i].Getdisdescription();
            TBGate.Text = tours.GetTourList()[i].GetGate().ToString();
            TBRFN.Text = tours.GetTourList()[i].getFlight_number_Return().ToString();
            if (DateTime.Parse(tours.GetTourList()[i].GetDate()) > DateTime.Now)
            {
                DTPTour.Value = DateTime.Parse(tours.GetTourList()[i].GetDate());
            }
            TBRGate.Text= tours.GetTourList()[i].GetGateReturn().ToString();
            CBHour.SelectedIndex = int.Parse(tours.GetTourList()[i].GetTimeHM()[0].ToString()) * 10+int.Parse(tours.GetTourList()[i].GetTimeHM()[1].ToString());
            CBMinutes.SelectedIndex= int.Parse(tours.GetTourList()[i].GetTimeHM()[3].ToString()) * 10 + int.Parse(tours.GetTourList()[i].GetTimeHM()[4].ToString());
            CBHourReturn.SelectedIndex = int.Parse(tours.GetTourList()[i].GetTimeHMReturn()[0].ToString()) * 10 + int.Parse(tours.GetTourList()[i].GetTimeHMReturn()[1].ToString());
            CBMinutesReturn.SelectedIndex = int.Parse(tours.GetTourList()[i].GetTimeHMReturn()[3].ToString()) * 10 + int.Parse(tours.GetTourList()[i].GetTimeHMReturn()[4].ToString());
        }
        /*add tour to the database only if the input data good*/
        private void PBAddTour_Click(object sender, EventArgs e)
        {
            bool flag = true;
            string str = "";
            f1.CheckFNumber(TBFlightnumber.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Flight number must contain 8 chars\n";
            }
            f1.CheckFNumber(TBRFN.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Return Flight number must contain 8 chars\n";
            }
            f1.CheckPrice(TBPrice.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "price needs to be at least with 300$\n";
            }
            f1.CheckDays(TBDays.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Enter days\n";
            }
            f1.CheckDays(TBCapacity.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Enter Capacity\n";
            }
            f1.CheckName(TBTourName.Text);
            if (f1.GetAnswer() == false)
            {
                flag = false;
                str += "Tour name Start with Capital letter and more then 3 letters long\n";
            }
            if (TBGate.Text == "" || TBGate.Text == "0" && int.Parse(TBGate.Text) < 1000)
            {
                flag = false;
                str += "Enter gate number less then 1000\n";
            }
            if (flag == false)
            {
                LError.Text = str;
            }
            else
            {
                f1.CheckTourdup(String.Format("{0:dd/MM/yyyy}", DTPTour.Value), TBTourName.Text);
                if (f1.GetAnswer() == false)
                {
                    str += "There is a tour with the same name on the same date!\n";
                    LError.Text = str;
                }
                else
                {
                    f1.CheckTourdupFN(String.Format("{0:dd/MM/yyyy}", DTPTour.Value), TBFlightnumber.Text);
                    if (f1.GetAnswer() == false)
                    {
                        str += "There is a tour with the same FlightNumber on the same date!\n";
                        LError.Text = str;
                    }

                    else
                    {
                        f1.CheckTourdupRFN(String.Format("{0:dd/MM/yyyy}", DTPTour.Value), TBRFN.Text, TBDays.Text);
                        if (f1.GetAnswer() == false)
                        {
                            str += "There is a tour with the same Return FlightNumber on the same date!\n";
                            LError.Text = str;
                        }
                        else
                        {
                            int m = f1.MakePKID("Tours") + 1;
                            Tour tr = new Tour(m, TBTourName.Text, TBFlightnumber.Text, int.Parse(TBPrice.Text), c.GetPKID().ToString(), RTBDisdescription.Text, int.Parse(TBDays.Text), String.Format("{0:dd/MM/yyyy}", DTPTour.Value), int.Parse(TBCapacity.Text), CBHour.SelectedItem.ToString() + ":" + CBMinutes.SelectedItem.ToString(), int.Parse(TBGate.Text), CBHourReturn.SelectedItem.ToString() + ":" + CBMinutesReturn.SelectedItem.ToString(), TBRFN.Text, int.Parse(TBRGate.Text));
                            tr.AddTourToDB();
                            LError.Text = tr.PrintTour();
                            int k = 0;
                            for (k = 0; k < picsToTour.GetTourPicList().Count; k++)
                            {
                                int pictourid = f1.MakePKID("Pics_Tours") + 1;
                                pictour = new PicsTours(pictourid, m, picsToTour.GetTourPicList()[k].GetPicName());
                                pictour.AddPicToDB();
                                pictourid++;
                            }
                            tours = new TourList();
                            picsTour = new PicsTourList();
                            picsToTour = new PicsTourList();
                            picsToTour.SetTourPicList(picsTour.FindPicByTourID(tr.GetTourID()));
                            FillCBTours();
                            CBToursList.SelectedIndex = CBToursList.Items.Count - 1;
                        }
                    }
                }
            }
        }
        /*add pic to tour*/
        private void PBAddTourPic_Click(object sender, EventArgs e)
        {
            if (LPicName.Text.Length<3)
            {
                LError.Text = "Add picture to tour";
            }
            else
            {
                f1.CheckPicdup(LPicName.Text, tours.GetTourList()[i].GetTourID().ToString());
                if (f1.GetAnswer() == false)
                {
                    LError.Text = "The picture is in the tour\n";
                }
                else
                {
                    int m = f1.MakePKID("Pics_Tours") + 1;
                    PicsTours p = new PicsTours(m, t.GetTourID(), LPicName.Text);
                    p.AddPicToDB();
                    picsToTour.GetTourPicList().Add(p);
                    picsTour.GetTourPicList().Add(p);
                    LError.Text = "Pic Added\n";
                    LPicName.Text = OFDAddPic.SafeFileName;
                    j = picsToTour.GetTourPicList().IndexOf(p);
                }
            }
        }
        /*delete pic from tour*/
        private void PBDeletePic_Click(object sender, EventArgs e)
        {
            f1.CheckPicdup(LPicName.Text,tours.GetTourList()[i].GetTourID().ToString());
            if (f1.GetAnswer() == false)
            {
                int p= picsTour.GetTourPicList().IndexOf(picsToTour.GetTourPicList()[j]);
                picsToTour.GetTourPicList()[j].DeletePicToDB();
                picsTour.GetTourPicList().RemoveAt(p);
                picsToTour.SetTourPicList(picsTour.FindPicByTourID(t.GetTourID()));
                LPicName.Text = "";
                PBTourPic.Image = null;
            }
        }
        /*user pick a pic to add*/
        private void PBAddPic_Click(object sender, EventArgs e)
        {
            if (OFDAddPic.ShowDialog() == DialogResult.OK)
            {
                LPicName.Text = OFDAddPic.SafeFileName;
                if (!new System.IO.FileInfo(@"Pic\Tours\" + LPicName.Text).Exists)
                {
                    System.IO.File.Copy(Path.GetFullPath(OFDAddPic.FileName), @"Pic\Tours\" + LPicName.Text);
                }
                PBTourPic.Image = Image.FromFile(@"Pic\Tours\" + LPicName.Text);
            }
        }
        /*next/last tour*/
        private void PBPlus_Click(object sender, EventArgs e)
        {
            i++;
            if (i == tours.GetTourList().Count)
            {
                i = 0;
            }
            t = tours.GetTourList()[i];
            CBToursList.SelectedIndex = i;
        }
        private void PBMinus_Click(object sender, EventArgs e)
        {
            i--;
            if (i < 0)
            {
                i = tours.GetTourList().Count - 1;
            }
            t = tours.GetTourList()[i];
            CBToursList.SelectedIndex = i;
        }
        /*next/last pic*/
        private void PBPicPlus_Click(object sender, EventArgs e)
        {
            if (picsToTour.GetTourPicList().Count != 0)
            {
                j++;
                if (j >= picsToTour.GetTourPicList().Count)
                {
                    j = 0;
                }
                LPicName.Text = picsToTour.GetTourPicList()[j].GetPicName();
                PBTourPic.Image = Image.FromFile(@"Pic\Tours\" + LPicName.Text);
            }
        }
        private void PBPicMinus_Click(object sender, EventArgs e)
        {
            if (picsToTour.GetTourPicList().Count != 0)
            {
                j--;
                if (j < 0)
                {
                    j = picsToTour.GetTourPicList().Count - 1;
                }
                LPicName.Text = picsToTour.GetTourPicList()[j].GetPicName();
                PBTourPic.Image = Image.FromFile(@"Pic\Tours\" + LPicName.Text);
            }
        }
        /*slected tour changed*/
        private void CBToursList_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            i = CBToursList.SelectedIndex;
            t = tours.GetTourList()[i];
            j = 0;
            c = new Country(t.GetCountry());
            CBCountry.SelectedItem = c.GetCountryName();
            fillTourdata();
            picsToTour.SetTourPicList(picsTour.FindPicByTourID(t.GetTourID()));
            if (picsToTour.GetTourPicList().Count != 0)
            {
                LPicName.Text = picsToTour.GetTourPicList()[j].GetPicName();
                PBTourPic.Image = Image.FromFile(@"Pic\Tours\" + LPicName.Text);
            }
            else
            {
                LPicName.Text ="";
                PBTourPic.Image = null;
            }

        }
        /*find tour by ID*/
        private void PBFTID_Click(object sender, EventArgs e)
        {
            string str = "";
            if (TBTourID.Text=="")
            {
                    str = "Enter Tour ID\n";
            }
            else
            {
                    t = tours.FindTourtbyID(TBTourID.Text);
                    i = tours.GetTourList().IndexOf(t);
                    if (i != -1)
                    {
                        CBToursList.SelectedIndex = i;
                        str = "Tour Found";
                    }
                    else
                    {
                        str = "Tour with that ID dont exist";
                    }
            }
            LError.Text = str;
        }
        /*Date and clock*/
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*Exit with fade timer*/
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*Go to last form*/
        private void PBBack_Click(object sender, EventArgs e)
        {
            if (LoginForm.Permission == "Worker")
            {
                var WorkerMenuForm = new WorkerMenuForm();
                WorkerMenuForm.Closed += (s, args) => this.Close();
                WorkerMenuForm.Show();
                this.Hide();
            }
            else if (LoginForm.Permission == "Manager")
            {
                var ManagerMenuForm = new ManagerMenuForm();
                ManagerMenuForm.Closed += (s, args) => this.Close();
                ManagerMenuForm.Show();
                this.Hide();
            }
        }
        /*Make PDF data file*/
        private void PBMakePFDTourData_Click(object sender, EventArgs e)
        {
            if (SFDTourPDF.ShowDialog() == DialogResult.OK)
            {
                string Path = SFDTourPDF.FileName;
                this.TourChart.SaveImage("pic/MyClientChart.png", System.Drawing.Imaging.ImageFormat.Png);
                t.PrintTourDataPDF(System.IO.Path.GetFileNameWithoutExtension(SFDTourPDF.FileName), "pic/MyClientChart.png", System.IO.Path.GetDirectoryName(Path));
            }
        }
        /*flight numbers, gates, price,cap and days are only digits*/
        private void TBFlightnumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBCapacity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void TBTourID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TBGate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TBRFN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TBRGate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        /*hover and tooltip withmouse*/
        private void PBAddClient_MouseHover(object sender, EventArgs e)
        {
            PBAddTour.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add tour", PBAddTour);
        }
        private void PBAddClient_MouseLeave(object sender, EventArgs e)
        {
            PBAddTour.BackColor = Color.Transparent;
        }

        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }

        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }

        private void PBAddPic_MouseHover(object sender, EventArgs e)
        {
            PBAddPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Serch pic", PBAddPic);
        }

        private void PBAddPic_MouseLeave(object sender, EventArgs e)
        {
            PBAddPic.BackColor = Color.Transparent;
        }

        private void PBAddTourPic_MouseHover(object sender, EventArgs e)
        {
            PBAddTourPic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Add pic", PBAddTourPic);
        }

        private void PBAddTourPic_MouseLeave(object sender, EventArgs e)
        {
            PBAddTourPic.BackColor = Color.Transparent;
        }


        private void PBPicPlus_MouseHover(object sender, EventArgs e)
        {
            PBPicPlus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Next pic", PBPicPlus);
        }

        private void PBPicPlus_MouseLeave(object sender, EventArgs e)
        {
            PBPicPlus.BackColor = Color.Transparent;
        }

        private void PBPicMinus_MouseHover(object sender, EventArgs e)
        {
            PBPicMinus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Last pic", PBPicMinus);
        }

        private void PBPicMinus_MouseLeave(object sender, EventArgs e)
        {
            PBPicMinus.BackColor = Color.Transparent;
        }

        private void PBDeletePic_MouseHover(object sender, EventArgs e)
        {
            PBDeletePic.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Delete pic", PBDeletePic);
        }

        private void PBDeletePic_MouseLeave(object sender, EventArgs e)
        {
            PBDeletePic.BackColor = Color.Transparent;
        }

        private void PBPlus_MouseHover(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Next tour", PBPlus);
        }

        private void PBPlus_MouseLeave(object sender, EventArgs e)
        {
            PBPlus.BackColor = Color.Transparent;
        }

        private void PBMinus_MouseHover(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Last tour", PBMinus);
        }

        private void PBMinus_MouseLeave(object sender, EventArgs e)
        {
            PBMinus.BackColor = Color.Transparent;
        }

        private void PBFTID_MouseHover(object sender, EventArgs e)
        {
            PBFTID.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Find tour by ID", PBFTID);
        }

        private void PBFTID_MouseLeave(object sender, EventArgs e)
        {
            PBFTID.BackColor = Color.Transparent;
        }

        private void PBMakePFDTourData_MouseHover(object sender, EventArgs e)
        {
            PBMakePFDTourData.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Make tour PDF data", PBMakePFDTourData);
        }

        private void PBMakePFDTourData_MouseLeave(object sender, EventArgs e)
        {
            PBMakePFDTourData.BackColor = Color.Transparent;
        }

        /*fade timer*/
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*tooltip background*/
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
