﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
namespace IlanTalproTCB
{
    /*
     this is the login form the user can login with his username and password
    */
    public partial class LoginForm : Form
    {
        public static int PKID = -1;
        public static string Permission = "";
        OleDbDataReader dr;
        Myconn connec = new Myconn();
        sha1ceypto sh = new sha1ceypto();
        Function f1 = new Function();
        Function f2 = new Function();
        
        public LoginForm()
        {
            this.BackgroundImage = Properties.Resources.background;
            InitializeComponent();
            TDate.Start();
            FillCBpermission();
            TTMouseHover.OwnerDraw = true;
            TTMouseHover.ForeColor = Color.Black;
            TTMouseHover.BackColor = Color.White;
        }
        /*
        fill the combobox with the permissions
        */
        public void FillCBpermission()
        {
            dr = connec.SandQuery("Select permission from permissions");
            while (dr.Read())
            {
                CBPermissions.Items.Add(dr["permission"].ToString());
            }
            dr.Close();
            connec.closeCon();
            CBPermissions.SelectedIndex = 0;
        }
        /*
        exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit","EXIT",MessageBoxButtons.YesNo);
            if(confirm==DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
        date timer
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        login first cheack if username and password are valid
        cheack if there is same user and encoded password in the right permission show message 
        if user still active he go to the right from else show message 
        if it login the user PKID and permission saved for other uses
        */
        private void PBLogin_Click(object sender, EventArgs e)
        {
            PKID = -1;
            bool activity=false;
            LActivity.Visible = false;
            LNotLogin.Visible = false;
            f1.CheckUsername(TBUsername.Text);
            if (f1.GetAnswer()==false)
            {
                LErrorUsername.Visible = true;
            }
            else
            {
                LErrorUsername.Visible = false;
            }
            f2.CheckPassword(TBPassword.Text);
            if (f2.GetAnswer() == false)
            {
                LErrorPassword.Visible = true;
            }
            else
            {
                LErrorPassword.Visible = false;
            }
            if (f1.GetAnswer() && f2.GetAnswer())
            {
                dr=connec.SandQuery("Select * from "+ CBPermissions.SelectedItem.ToString() + "s where UserName='" + TBUsername.Text+ "' and Passw='" + sh.GetSHA1(TBPassword.Text) + "'");
                while (dr.Read())
                {
                    PKID = int.Parse(dr["PKID"].ToString());
                    activity = bool.Parse(dr["active"].ToString());
                }
                dr.Close();
                connec.closeCon();
                
                if (PKID == -1)
                {
                    LNotLogin.Visible = true;
                }
                else
                {
                    if (activity)
                    {
                        LActivity.Visible = false;
                        Permission = CBPermissions.SelectedItem.ToString();
                        this.Hide();
                        if (CBPermissions.SelectedItem.ToString() == "Client")
                        {
                            var CForm = new ClientMenuForm();
                            CForm.Closed += (s, args) => this.Close();
                            CForm.Show();
                        }
                        else if (CBPermissions.SelectedItem.ToString() == "Worker")
                        {
                            var WForm = new WorkerMenuForm();
                            WForm.Closed += (s, args) => this.Close();
                            WForm.Show();
                        }
                        else if (CBPermissions.SelectedItem.ToString() == "Manager")
                        {
                            var MForm = new ManagerMenuForm();
                            MForm.Closed += (s, args) => this.Close();
                            MForm.Show();
                        }
                    }
                    else
                    {
                        PKID = -1;
                        LActivity.Visible = true;
                    }
                }
            }
        }
        /*
        go to add client form
        */
        private void PBNewC_Click(object sender, EventArgs e)
        {
            PKID = -1;
            this.Hide();
            var ACForm = new AddClientForm();
            ACForm.Closed += (s, args) => this.Close();
            ACForm.Show();
        }

        private void PBLogin_MouseHover(object sender, EventArgs e)
        {
            PBLogin.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Login", PBLogin);
        }
        private void PBLogin_MouseLeave(object sender, EventArgs e)
        {
            PBLogin.BackColor = Color.Transparent;
        }

        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBNewC_MouseHover(object sender, EventArgs e)
        {
            PBNewC.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("New Client", PBNewC);
        }
        private void PBNewC_MouseLeave(object sender, EventArgs e)
        {
            PBNewC.BackColor = Color.Transparent;
        }
        /*
        time fade
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tool tip drow background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
