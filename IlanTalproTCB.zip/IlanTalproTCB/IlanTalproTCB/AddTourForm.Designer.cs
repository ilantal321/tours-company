﻿namespace IlanTalproTCB
{
    partial class AddTourForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddTourForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.TBPrice = new System.Windows.Forms.TextBox();
            this.LPrice = new System.Windows.Forms.Label();
            this.TBTourName = new System.Windows.Forms.TextBox();
            this.LTourName = new System.Windows.Forms.Label();
            this.LCountry = new System.Windows.Forms.Label();
            this.TBFlightnumber = new System.Windows.Forms.TextBox();
            this.LFlightnumber = new System.Windows.Forms.Label();
            this.PBAddTour = new System.Windows.Forms.PictureBox();
            this.OFDAddPic = new System.Windows.Forms.OpenFileDialog();
            this.LError = new System.Windows.Forms.Label();
            this.LDisdescription = new System.Windows.Forms.Label();
            this.LTourDate = new System.Windows.Forms.Label();
            this.LCapacity = new System.Windows.Forms.Label();
            this.TBCapacity = new System.Windows.Forms.TextBox();
            this.TBDays = new System.Windows.Forms.TextBox();
            this.LDays = new System.Windows.Forms.Label();
            this.DTPTour = new System.Windows.Forms.DateTimePicker();
            this.RTBDisdescription = new System.Windows.Forms.RichTextBox();
            this.LPicName = new System.Windows.Forms.Label();
            this.PBTourPic = new System.Windows.Forms.PictureBox();
            this.PBAddPic = new System.Windows.Forms.PictureBox();
            this.LPic = new System.Windows.Forms.Label();
            this.PBAddTourPic = new System.Windows.Forms.PictureBox();
            this.CBCountry = new System.Windows.Forms.ComboBox();
            this.CBHour = new System.Windows.Forms.ComboBox();
            this.CBMinutes = new System.Windows.Forms.ComboBox();
            this.LTime = new System.Windows.Forms.Label();
            this.LGate = new System.Windows.Forms.Label();
            this.TBGate = new System.Windows.Forms.TextBox();
            this.LReturnTime = new System.Windows.Forms.Label();
            this.LTime2 = new System.Windows.Forms.Label();
            this.CBMinutesReturn = new System.Windows.Forms.ComboBox();
            this.CBHourReturn = new System.Windows.Forms.ComboBox();
            this.TBRFN = new System.Windows.Forms.TextBox();
            this.LRFN = new System.Windows.Forms.Label();
            this.TBRGate = new System.Windows.Forms.TextBox();
            this.LRGate = new System.Windows.Forms.Label();
            this.LFlightTime = new System.Windows.Forms.Label();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddTour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBTourPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddTourPic)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 9);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(287, 40);
            this.LHeader.TabIndex = 1;
            this.LHeader.Text = "Enter Data to add tour";
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 762);
            this.PBExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 762);
            this.PBBack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // TBPrice
            // 
            this.TBPrice.Font = new System.Drawing.Font("Arial Narrow", 10.2F);
            this.TBPrice.Location = new System.Drawing.Point(176, 158);
            this.TBPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBPrice.MaxLength = 5;
            this.TBPrice.Name = "TBPrice";
            this.TBPrice.Size = new System.Drawing.Size(151, 27);
            this.TBPrice.TabIndex = 14;
            this.TBPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBPrice_KeyPress);
            // 
            // LPrice
            // 
            this.LPrice.AutoSize = true;
            this.LPrice.BackColor = System.Drawing.Color.Transparent;
            this.LPrice.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPrice.ForeColor = System.Drawing.Color.Black;
            this.LPrice.Location = new System.Drawing.Point(14, 156);
            this.LPrice.Name = "LPrice";
            this.LPrice.Size = new System.Drawing.Size(63, 29);
            this.LPrice.TabIndex = 13;
            this.LPrice.Text = "Price:";
            // 
            // TBTourName
            // 
            this.TBTourName.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBTourName.Location = new System.Drawing.Point(176, 77);
            this.TBTourName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBTourName.MaxLength = 30;
            this.TBTourName.Name = "TBTourName";
            this.TBTourName.Size = new System.Drawing.Size(151, 27);
            this.TBTourName.TabIndex = 16;
            // 
            // LTourName
            // 
            this.LTourName.AutoSize = true;
            this.LTourName.BackColor = System.Drawing.Color.Transparent;
            this.LTourName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourName.ForeColor = System.Drawing.Color.Black;
            this.LTourName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourName.Location = new System.Drawing.Point(14, 76);
            this.LTourName.Name = "LTourName";
            this.LTourName.Size = new System.Drawing.Size(116, 29);
            this.LTourName.TabIndex = 15;
            this.LTourName.Text = "Tour Name:";
            // 
            // LCountry
            // 
            this.LCountry.AutoSize = true;
            this.LCountry.BackColor = System.Drawing.Color.Transparent;
            this.LCountry.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCountry.ForeColor = System.Drawing.Color.Black;
            this.LCountry.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCountry.Location = new System.Drawing.Point(14, 115);
            this.LCountry.Name = "LCountry";
            this.LCountry.Size = new System.Drawing.Size(86, 29);
            this.LCountry.TabIndex = 17;
            this.LCountry.Text = "Country:";
            // 
            // TBFlightnumber
            // 
            this.TBFlightnumber.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBFlightnumber.Location = new System.Drawing.Point(562, 77);
            this.TBFlightnumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBFlightnumber.MaxLength = 8;
            this.TBFlightnumber.Name = "TBFlightnumber";
            this.TBFlightnumber.Size = new System.Drawing.Size(151, 27);
            this.TBFlightnumber.TabIndex = 30;
            this.TBFlightnumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBFlightnumber_KeyPress);
            // 
            // LFlightnumber
            // 
            this.LFlightnumber.AutoSize = true;
            this.LFlightnumber.BackColor = System.Drawing.Color.Transparent;
            this.LFlightnumber.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFlightnumber.ForeColor = System.Drawing.Color.Black;
            this.LFlightnumber.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFlightnumber.Location = new System.Drawing.Point(356, 76);
            this.LFlightnumber.Name = "LFlightnumber";
            this.LFlightnumber.Size = new System.Drawing.Size(137, 29);
            this.LFlightnumber.TabIndex = 29;
            this.LFlightnumber.Text = "Flight number:";
            // 
            // PBAddTour
            // 
            this.PBAddTour.BackColor = System.Drawing.Color.Transparent;
            this.PBAddTour.Image = ((System.Drawing.Image)(resources.GetObject("PBAddTour.Image")));
            this.PBAddTour.Location = new System.Drawing.Point(776, 237);
            this.PBAddTour.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBAddTour.Name = "PBAddTour";
            this.PBAddTour.Size = new System.Drawing.Size(100, 80);
            this.PBAddTour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddTour.TabIndex = 34;
            this.PBAddTour.TabStop = false;
            this.PBAddTour.Click += new System.EventHandler(this.PBAddTour_Click);
            this.PBAddTour.MouseLeave += new System.EventHandler(this.PBAddClient_MouseLeave);
            this.PBAddTour.MouseHover += new System.EventHandler(this.PBAddTour_MouseHover);
            // 
            // OFDAddPic
            // 
            this.OFDAddPic.FileName = "OFDAddPic";
            // 
            // LError
            // 
            this.LError.AutoSize = true;
            this.LError.BackColor = System.Drawing.Color.Transparent;
            this.LError.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LError.ForeColor = System.Drawing.Color.Black;
            this.LError.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LError.Location = new System.Drawing.Point(432, 393);
            this.LError.Name = "LError";
            this.LError.Size = new System.Drawing.Size(0, 29);
            this.LError.TabIndex = 36;
            // 
            // LDisdescription
            // 
            this.LDisdescription.AutoSize = true;
            this.LDisdescription.BackColor = System.Drawing.Color.Transparent;
            this.LDisdescription.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDisdescription.ForeColor = System.Drawing.Color.Black;
            this.LDisdescription.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LDisdescription.Location = new System.Drawing.Point(14, 237);
            this.LDisdescription.Name = "LDisdescription";
            this.LDisdescription.Size = new System.Drawing.Size(141, 29);
            this.LDisdescription.TabIndex = 19;
            this.LDisdescription.Text = "Disdescription:";
            // 
            // LTourDate
            // 
            this.LTourDate.AutoSize = true;
            this.LTourDate.BackColor = System.Drawing.Color.Transparent;
            this.LTourDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourDate.ForeColor = System.Drawing.Color.Black;
            this.LTourDate.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourDate.Location = new System.Drawing.Point(751, 79);
            this.LTourDate.Name = "LTourDate";
            this.LTourDate.Size = new System.Drawing.Size(105, 29);
            this.LTourDate.TabIndex = 10;
            this.LTourDate.Text = "Tour Date:";
            // 
            // LCapacity
            // 
            this.LCapacity.AutoSize = true;
            this.LCapacity.BackColor = System.Drawing.Color.Transparent;
            this.LCapacity.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCapacity.ForeColor = System.Drawing.Color.Black;
            this.LCapacity.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCapacity.Location = new System.Drawing.Point(14, 194);
            this.LCapacity.Name = "LCapacity";
            this.LCapacity.Size = new System.Drawing.Size(93, 29);
            this.LCapacity.TabIndex = 27;
            this.LCapacity.Text = "Capacity:";
            // 
            // TBCapacity
            // 
            this.TBCapacity.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBCapacity.Location = new System.Drawing.Point(176, 195);
            this.TBCapacity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBCapacity.MaxLength = 2;
            this.TBCapacity.Name = "TBCapacity";
            this.TBCapacity.Size = new System.Drawing.Size(151, 27);
            this.TBCapacity.TabIndex = 28;
            this.TBCapacity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBCapacity_KeyPress);
            // 
            // TBDays
            // 
            this.TBDays.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBDays.Location = new System.Drawing.Point(878, 115);
            this.TBDays.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBDays.MaxLength = 2;
            this.TBDays.Name = "TBDays";
            this.TBDays.Size = new System.Drawing.Size(151, 27);
            this.TBDays.TabIndex = 26;
            this.TBDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBDays_KeyPress);
            // 
            // LDays
            // 
            this.LDays.AutoSize = true;
            this.LDays.BackColor = System.Drawing.Color.Transparent;
            this.LDays.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDays.ForeColor = System.Drawing.Color.Black;
            this.LDays.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LDays.Location = new System.Drawing.Point(751, 113);
            this.LDays.Name = "LDays";
            this.LDays.Size = new System.Drawing.Size(62, 29);
            this.LDays.TabIndex = 25;
            this.LDays.Text = "Days:";
            // 
            // DTPTour
            // 
            this.DTPTour.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTPTour.Location = new System.Drawing.Point(878, 82);
            this.DTPTour.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DTPTour.MinDate = new System.DateTime(2020, 10, 13, 0, 0, 0, 0);
            this.DTPTour.Name = "DTPTour";
            this.DTPTour.Size = new System.Drawing.Size(151, 22);
            this.DTPTour.TabIndex = 38;
            this.DTPTour.Value = new System.DateTime(2020, 10, 13, 10, 58, 54, 0);
            // 
            // RTBDisdescription
            // 
            this.RTBDisdescription.Location = new System.Drawing.Point(19, 268);
            this.RTBDisdescription.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.RTBDisdescription.Name = "RTBDisdescription";
            this.RTBDisdescription.Size = new System.Drawing.Size(504, 98);
            this.RTBDisdescription.TabIndex = 39;
            this.RTBDisdescription.Text = "";
            // 
            // LPicName
            // 
            this.LPicName.AutoSize = true;
            this.LPicName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPicName.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LPicName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPicName.Location = new System.Drawing.Point(299, 510);
            this.LPicName.Name = "LPicName";
            this.LPicName.Size = new System.Drawing.Size(0, 29);
            this.LPicName.TabIndex = 43;
            this.LPicName.Visible = false;
            // 
            // PBTourPic
            // 
            this.PBTourPic.BackColor = System.Drawing.Color.Transparent;
            this.PBTourPic.Location = new System.Drawing.Point(69, 393);
            this.PBTourPic.Name = "PBTourPic";
            this.PBTourPic.Size = new System.Drawing.Size(203, 173);
            this.PBTourPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBTourPic.TabIndex = 42;
            this.PBTourPic.TabStop = false;
            this.PBTourPic.Visible = false;
            // 
            // PBAddPic
            // 
            this.PBAddPic.BackColor = System.Drawing.Color.Transparent;
            this.PBAddPic.Image = ((System.Drawing.Image)(resources.GetObject("PBAddPic.Image")));
            this.PBAddPic.Location = new System.Drawing.Point(304, 393);
            this.PBAddPic.Name = "PBAddPic";
            this.PBAddPic.Size = new System.Drawing.Size(100, 80);
            this.PBAddPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddPic.TabIndex = 41;
            this.PBAddPic.TabStop = false;
            this.PBAddPic.Visible = false;
            this.PBAddPic.Click += new System.EventHandler(this.PBAddPic_Click);
            this.PBAddPic.MouseLeave += new System.EventHandler(this.PBAddPic_MouseLeave);
            this.PBAddPic.MouseHover += new System.EventHandler(this.PBAddPic_MouseHover);
            // 
            // LPic
            // 
            this.LPic.AutoSize = true;
            this.LPic.BackColor = System.Drawing.Color.Transparent;
            this.LPic.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPic.ForeColor = System.Drawing.Color.Black;
            this.LPic.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPic.Location = new System.Drawing.Point(14, 393);
            this.LPic.Name = "LPic";
            this.LPic.Size = new System.Drawing.Size(45, 29);
            this.LPic.TabIndex = 40;
            this.LPic.Text = "Pic:";
            this.LPic.Visible = false;
            // 
            // PBAddTourPic
            // 
            this.PBAddTourPic.BackColor = System.Drawing.Color.Transparent;
            this.PBAddTourPic.Image = ((System.Drawing.Image)(resources.GetObject("PBAddTourPic.Image")));
            this.PBAddTourPic.Location = new System.Drawing.Point(304, 486);
            this.PBAddTourPic.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBAddTourPic.Name = "PBAddTourPic";
            this.PBAddTourPic.Size = new System.Drawing.Size(100, 80);
            this.PBAddTourPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddTourPic.TabIndex = 44;
            this.PBAddTourPic.TabStop = false;
            this.PBAddTourPic.Visible = false;
            this.PBAddTourPic.Click += new System.EventHandler(this.PBAddTourPic_Click);
            this.PBAddTourPic.MouseLeave += new System.EventHandler(this.PBAddTourPic_MouseLeave);
            this.PBAddTourPic.MouseHover += new System.EventHandler(this.PBAddTourPic_MouseHover);
            // 
            // CBCountry
            // 
            this.CBCountry.FormattingEnabled = true;
            this.CBCountry.Location = new System.Drawing.Point(176, 120);
            this.CBCountry.Name = "CBCountry";
            this.CBCountry.Size = new System.Drawing.Size(151, 24);
            this.CBCountry.TabIndex = 45;
            this.CBCountry.SelectedIndexChanged += new System.EventHandler(this.CBCountry_SelectedIndexChanged);
            // 
            // CBHour
            // 
            this.CBHour.FormattingEnabled = true;
            this.CBHour.Location = new System.Drawing.Point(879, 161);
            this.CBHour.Name = "CBHour";
            this.CBHour.Size = new System.Drawing.Size(52, 24);
            this.CBHour.TabIndex = 46;
            // 
            // CBMinutes
            // 
            this.CBMinutes.FormattingEnabled = true;
            this.CBMinutes.Location = new System.Drawing.Point(961, 161);
            this.CBMinutes.Name = "CBMinutes";
            this.CBMinutes.Size = new System.Drawing.Size(45, 24);
            this.CBMinutes.TabIndex = 47;
            // 
            // LTime
            // 
            this.LTime.AutoSize = true;
            this.LTime.BackColor = System.Drawing.Color.Transparent;
            this.LTime.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTime.ForeColor = System.Drawing.Color.Black;
            this.LTime.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTime.Location = new System.Drawing.Point(937, 155);
            this.LTime.Name = "LTime";
            this.LTime.Size = new System.Drawing.Size(18, 29);
            this.LTime.TabIndex = 48;
            this.LTime.Text = ":";
            // 
            // LGate
            // 
            this.LGate.AutoSize = true;
            this.LGate.BackColor = System.Drawing.Color.Transparent;
            this.LGate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LGate.ForeColor = System.Drawing.Color.Black;
            this.LGate.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LGate.Location = new System.Drawing.Point(356, 115);
            this.LGate.Name = "LGate";
            this.LGate.Size = new System.Drawing.Size(106, 29);
            this.LGate.TabIndex = 49;
            this.LGate.Text = "Tour Gate:";
            // 
            // TBGate
            // 
            this.TBGate.Font = new System.Drawing.Font("Arial Narrow", 10.2F);
            this.TBGate.Location = new System.Drawing.Point(562, 116);
            this.TBGate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBGate.MaxLength = 5;
            this.TBGate.Name = "TBGate";
            this.TBGate.Size = new System.Drawing.Size(151, 27);
            this.TBGate.TabIndex = 50;
            this.TBGate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBGate_KeyPress);
            // 
            // LReturnTime
            // 
            this.LReturnTime.AutoSize = true;
            this.LReturnTime.BackColor = System.Drawing.Color.Transparent;
            this.LReturnTime.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LReturnTime.ForeColor = System.Drawing.Color.Black;
            this.LReturnTime.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LReturnTime.Location = new System.Drawing.Point(751, 195);
            this.LReturnTime.Name = "LReturnTime";
            this.LReturnTime.Size = new System.Drawing.Size(125, 29);
            this.LReturnTime.TabIndex = 103;
            this.LReturnTime.Text = "Return Time:";
            // 
            // LTime2
            // 
            this.LTime2.AutoSize = true;
            this.LTime2.BackColor = System.Drawing.Color.Transparent;
            this.LTime2.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTime2.ForeColor = System.Drawing.Color.Black;
            this.LTime2.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTime2.Location = new System.Drawing.Point(937, 194);
            this.LTime2.Name = "LTime2";
            this.LTime2.Size = new System.Drawing.Size(18, 29);
            this.LTime2.TabIndex = 102;
            this.LTime2.Text = ":";
            // 
            // CBMinutesReturn
            // 
            this.CBMinutesReturn.FormattingEnabled = true;
            this.CBMinutesReturn.Location = new System.Drawing.Point(961, 199);
            this.CBMinutesReturn.Name = "CBMinutesReturn";
            this.CBMinutesReturn.Size = new System.Drawing.Size(45, 24);
            this.CBMinutesReturn.TabIndex = 101;
            // 
            // CBHourReturn
            // 
            this.CBHourReturn.FormattingEnabled = true;
            this.CBHourReturn.Location = new System.Drawing.Point(879, 199);
            this.CBHourReturn.Name = "CBHourReturn";
            this.CBHourReturn.Size = new System.Drawing.Size(52, 24);
            this.CBHourReturn.TabIndex = 100;
            // 
            // TBRFN
            // 
            this.TBRFN.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBRFN.Location = new System.Drawing.Point(563, 158);
            this.TBRFN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBRFN.MaxLength = 8;
            this.TBRFN.Name = "TBRFN";
            this.TBRFN.Size = new System.Drawing.Size(151, 27);
            this.TBRFN.TabIndex = 105;
            this.TBRFN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBRFN_KeyPress);
            // 
            // LRFN
            // 
            this.LRFN.AutoSize = true;
            this.LRFN.BackColor = System.Drawing.Color.Transparent;
            this.LRFN.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRFN.ForeColor = System.Drawing.Color.Black;
            this.LRFN.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRFN.Location = new System.Drawing.Point(356, 156);
            this.LRFN.Name = "LRFN";
            this.LRFN.Size = new System.Drawing.Size(201, 29);
            this.LRFN.TabIndex = 104;
            this.LRFN.Text = "Return Flight number:";
            // 
            // TBRGate
            // 
            this.TBRGate.Font = new System.Drawing.Font("Arial Narrow", 10.2F);
            this.TBRGate.Location = new System.Drawing.Point(563, 194);
            this.TBRGate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBRGate.MaxLength = 5;
            this.TBRGate.Name = "TBRGate";
            this.TBRGate.Size = new System.Drawing.Size(151, 27);
            this.TBRGate.TabIndex = 107;
            this.TBRGate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBRGate_KeyPress);
            // 
            // LRGate
            // 
            this.LRGate.AutoSize = true;
            this.LRGate.BackColor = System.Drawing.Color.Transparent;
            this.LRGate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRGate.ForeColor = System.Drawing.Color.Black;
            this.LRGate.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LRGate.Location = new System.Drawing.Point(356, 193);
            this.LRGate.Name = "LRGate";
            this.LRGate.Size = new System.Drawing.Size(170, 29);
            this.LRGate.TabIndex = 106;
            this.LRGate.Text = "Return Tour Gate:";
            // 
            // LFlightTime
            // 
            this.LFlightTime.AutoSize = true;
            this.LFlightTime.BackColor = System.Drawing.Color.Transparent;
            this.LFlightTime.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFlightTime.ForeColor = System.Drawing.Color.Black;
            this.LFlightTime.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFlightTime.Location = new System.Drawing.Point(751, 156);
            this.LFlightTime.Name = "LFlightTime";
            this.LFlightTime.Size = new System.Drawing.Size(113, 29);
            this.LFlightTime.TabIndex = 108;
            this.LFlightTime.Text = "Flight Time:";
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // AddTourForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.LFlightTime);
            this.Controls.Add(this.TBRGate);
            this.Controls.Add(this.LRGate);
            this.Controls.Add(this.TBRFN);
            this.Controls.Add(this.LRFN);
            this.Controls.Add(this.LReturnTime);
            this.Controls.Add(this.LTime2);
            this.Controls.Add(this.CBMinutesReturn);
            this.Controls.Add(this.CBHourReturn);
            this.Controls.Add(this.TBGate);
            this.Controls.Add(this.LGate);
            this.Controls.Add(this.LTime);
            this.Controls.Add(this.CBMinutes);
            this.Controls.Add(this.CBHour);
            this.Controls.Add(this.CBCountry);
            this.Controls.Add(this.PBAddTourPic);
            this.Controls.Add(this.LPicName);
            this.Controls.Add(this.PBTourPic);
            this.Controls.Add(this.PBAddPic);
            this.Controls.Add(this.LPic);
            this.Controls.Add(this.RTBDisdescription);
            this.Controls.Add(this.DTPTour);
            this.Controls.Add(this.LError);
            this.Controls.Add(this.PBAddTour);
            this.Controls.Add(this.TBFlightnumber);
            this.Controls.Add(this.LFlightnumber);
            this.Controls.Add(this.TBCapacity);
            this.Controls.Add(this.LCapacity);
            this.Controls.Add(this.TBDays);
            this.Controls.Add(this.LDays);
            this.Controls.Add(this.LDisdescription);
            this.Controls.Add(this.LCountry);
            this.Controls.Add(this.TBTourName);
            this.Controls.Add(this.LTourName);
            this.Controls.Add(this.TBPrice);
            this.Controls.Add(this.LPrice);
            this.Controls.Add(this.LTourDate);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AddTourForm";
            this.Text = "Add Tour";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddTour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBTourPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddTourPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.TextBox TBPrice;
        private System.Windows.Forms.Label LPrice;
        private System.Windows.Forms.TextBox TBTourName;
        private System.Windows.Forms.Label LTourName;
        private System.Windows.Forms.Label LCountry;
        private System.Windows.Forms.TextBox TBFlightnumber;
        private System.Windows.Forms.Label LFlightnumber;
        private System.Windows.Forms.PictureBox PBAddTour;
        private System.Windows.Forms.OpenFileDialog OFDAddPic;
        private System.Windows.Forms.Label LError;
        private System.Windows.Forms.Label LDisdescription;
        private System.Windows.Forms.Label LTourDate;
        private System.Windows.Forms.Label LCapacity;
        private System.Windows.Forms.TextBox TBCapacity;
        private System.Windows.Forms.TextBox TBDays;
        private System.Windows.Forms.Label LDays;
        private System.Windows.Forms.DateTimePicker DTPTour;
        private System.Windows.Forms.RichTextBox RTBDisdescription;
        private System.Windows.Forms.Label LPicName;
        private System.Windows.Forms.PictureBox PBTourPic;
        private System.Windows.Forms.PictureBox PBAddPic;
        private System.Windows.Forms.Label LPic;
        private System.Windows.Forms.PictureBox PBAddTourPic;
        private System.Windows.Forms.ComboBox CBCountry;
        private System.Windows.Forms.ComboBox CBHour;
        private System.Windows.Forms.ComboBox CBMinutes;
        private System.Windows.Forms.Label LTime;
        private System.Windows.Forms.Label LGate;
        private System.Windows.Forms.TextBox TBGate;
        private System.Windows.Forms.Label LReturnTime;
        private System.Windows.Forms.Label LTime2;
        private System.Windows.Forms.ComboBox CBMinutesReturn;
        private System.Windows.Forms.ComboBox CBHourReturn;
        private System.Windows.Forms.TextBox TBRFN;
        private System.Windows.Forms.Label LRFN;
        private System.Windows.Forms.TextBox TBRGate;
        private System.Windows.Forms.Label LRGate;
        private System.Windows.Forms.Label LFlightTime;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}