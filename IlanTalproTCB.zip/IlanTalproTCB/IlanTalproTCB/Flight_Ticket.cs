﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.IO;
namespace IlanTalproTCB
{
    class Flight_Ticket
    {
        private int PKID;
        private int OrderID;
        private string Seat;
        private int TourID;
        /*
        empty constractor
        */
        public Flight_Ticket()
        { }
        /*
        constractor
        */
        public Flight_Ticket(int PID, int OID,string  SeatIN,int TID)
        {
            PKID = PID;
            OrderID = OID;
            Seat = SeatIN;
            TourID = TID;
        }
        /*
        constractor from database
        */
        public Flight_Ticket(int ID)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("SELECT * FROM Flight_Ticket where PKID=" + ID + ";");
            while (dr.Read())
            {
                PKID = int.Parse(dr["PKID"].ToString());
                OrderID = int.Parse(dr["OrderID"].ToString());
                Seat = dr["Seat"].ToString();
                TourID = int.Parse(dr["TourID"].ToString());
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        get abd set
        */
        public int GetPKID()
        {
            return PKID;
        }
        public int GetOrderID()
        {
            return OrderID;
        }
        public int GetTourID()
        {
            return TourID;
        }
        public void SetSeat(string Nseat)
        {
            Seat = Nseat ;
        }
        public void SetPKID(int NPKID)
        {
            PKID=NPKID;
        }
        public void SetOrderID(int NorderID)
        {
            OrderID=NorderID;
        }
        public void SetTourID(int NTID)
        {
            TourID=NTID;
        }
        public string GetSeat()
        {
            return Seat;
        }
        /*
        update Flight Ticket in database
        */
        public void Update_Flight_Ticket_TODB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("UPDATE Flight_Ticket SET OrderID = " + OrderID + " WHERE PKID = " + PKID + " ;");
            dr.Close();
            connec.closeCon();
        }
        /*
        add Flight Ticket to the database
        */
        public void Add_Flight_Ticket_TODB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("INSERT INTO Flight_Ticket VALUES ( '" + PKID + "',"+OrderID+", '" + Seat + "', '" + TourID + "');");
            dr.Close();
            connec.closeCon();
        }
    }

}
