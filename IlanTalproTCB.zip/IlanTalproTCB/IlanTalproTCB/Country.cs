﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class Country
    {
        private int PKID;
        private int ContinentPKID;
        private string CountryName;
        /*
        constractor
        */
        public Country(int pk,int c,string cn)
        {
            PKID = pk;
            ContinentPKID = c;
            CountryName = cn;
        }
        /*
        empty constractor
        */
        public Country() { }
        /*
         constractor by data base
        */
        public Country(string CPKID)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Countries where PKID=" + CPKID + ";");
            while (dr.Read())
            {
                PKID = int.Parse(dr["PKID"].ToString());
                ContinentPKID = int.Parse(dr["ContinentPKID"].ToString());
                CountryName = dr["CountryName"].ToString();
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        get and set
        */
        public void SetPKID(int pk)
        {
            PKID = pk;
        }
        public void SetContinentPKID(int pk)
        {
            ContinentPKID = pk;
        }
        public void SetCountryName(string cn)
        {
            CountryName = cn;
        }
        public int GetPKID()
        {
            return PKID;
        }
        public int GetContinentPKID()
        {
            return ContinentPKID;
        }
        public string GetCountryName()
        {
            return CountryName;
        }
        /*
        add Country to the data base
        */
        public void AddCountryToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("INSERT INTO Countries VALUES (" + PKID+" , "+ ContinentPKID + " , '"+CountryName+"');");
            dr.Close();
            connec.closeCon();
        }
        /*
        update Country
        */
        public void UpdateCountryName()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("UPDATE Countries SET CountryName = '" + CountryName + "', ContinentPKID="+ ContinentPKID + " WHERE PKID = " + PKID + " ;");
            dr.Close();
            connec.closeCon();
        }
    }

}
