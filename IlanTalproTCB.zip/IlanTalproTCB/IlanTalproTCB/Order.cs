﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    class Order
    {
        private int OrderNumber;
        private int ClientNumber;
        private int WorkerNumber;
        private int TourNumber;
        private DateTime OrderDate;
        private DateTime PaymentDate;
        private bool Payment;
        private int Quantity;
        private bool Active;
        /*
        empty constractor
        */
        public Order()
        {}
        /*
        constractor new order
        */
        public Order(int ON, int CN, int WN, int TN, bool pay, int q)
        {
            OrderNumber = ON;
            ClientNumber = CN;
            WorkerNumber = WN;
            TourNumber = TN;
            OrderDate = DateTime.Now;
            Payment = pay;
            Quantity = q;
            Active = true;
            if (Payment)
            {
                PaymentDate = DateTime.Now;
            }
            else
            {
                PaymentDate = DateTime.MinValue;
            }
        }
        /*
        constractor
        */
        public Order(int ON, int CN, int WN, int TN, bool pay, int q, DateTime od, DateTime pd,bool a)
        {
            OrderNumber = ON;
            ClientNumber = CN;
            WorkerNumber = WN;
            TourNumber = TN;
            OrderDate = od;
            Payment = pay;
            Quantity = q;
            PaymentDate = pd;
            Active = a;
        }
        /*
        get and set
        */
        public void SetOrderNumber(int ON)
        {
            OrderNumber = ON;
        }
        public void SetClientNumber(int CN)
        {
            ClientNumber = CN;
        }
        public void SetWorkerNumber(int WN)
        {
            WorkerNumber = WN;
        }
        public void SetTourNumber(int WN)
        {
            TourNumber = WN;
        }
        public void SetActive(bool a)
        {
            Active = a;
        }
        public void SetOrderDate(DateTime OD)
        {
            OrderDate = OD;
        }
        public void SetPaymentDate(DateTime PD)
        {
            PaymentDate = PD;
        }
        public void SetPayment(bool p)
        {
            Payment = p;
        }
        public void SetQuantity(int q)
        {
            Quantity = q;
        }
        public int GetOrderNumber()
        {
            return OrderNumber;
        }
        public int GetClientNumber()
        {
            return ClientNumber;
        }
        public int GetWorkerNumber()
        {
            return WorkerNumber;
        }
        public int GetTourNumber()
        {
            return TourNumber;
        }
        public DateTime GetOrderDate()
        {
            return OrderDate;
        }
        public DateTime GetPaymentDate()
        {
            return PaymentDate;
        }
        public bool GetPayment()
        {
            return Payment;
        }
        public bool GetActive()
        {
            return Active;
        }
        public int GetQuantity()
        {
            return Quantity;
        }
        /*
        print data for other uses
        */
        public string PrintOrder()
        {
            string str = "";
            str = "Order number:" + OrderNumber + "\nClient number:" + ClientNumber + "\nWorker number:" + WorkerNumber + "\nTour number" + TourNumber + "\nOrder date:" + OrderDate.ToString() + "\nPayment date:"+PaymentDate+ "\nPayment Status:"+Payment + "\nQuantity:" + Quantity;
            return str;
        }
        public string PrintOrderForClientPDF()
        {
            string str = "";
            str = "Order number:" + OrderNumber + "\nOrder date:" + OrderDate.ToString() + "\nPayment date:" + PaymentDate;
            return str;
        }
        /*
        add order to database
        */
        public void AddOrderToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("INSERT INTO Orders VALUES ( " + OrderNumber + ", " + ClientNumber + ", " + WorkerNumber + ", " + TourNumber + ", '" + OrderDate.ToString() + "', '" + PaymentDate.ToString() + "', "  + Payment + ", "+Quantity+ ", " + Active + " );");
            dr.Close();
            connec.closeCon();
        }
        /*
        update order as paid
        */
        public void PayOrder()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("UPDATE Orders SET Payment = true  , PaymentDate='" + DateTime.Now + "' WHERE PKID = " + OrderNumber + "; ");
            dr.Close();
            connec.closeCon();
        }
        /*
        update order as cancaled
        */
        public void UnActiveOrder()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            Active = false;
            dr = connec.SandQuery("UPDATE Orders SET Active = False  " + " WHERE PKID = " + OrderNumber + "; ");
            dr.Close();
            connec.closeCon();
        }
    }
}
