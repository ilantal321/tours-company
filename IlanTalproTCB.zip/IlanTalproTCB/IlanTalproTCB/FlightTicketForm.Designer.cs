﻿namespace IlanTalproTCB
{
    partial class FlightTicketForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FlightTicketForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.TBPName = new System.Windows.Forms.TextBox();
            this.CBClass = new System.Windows.Forms.ComboBox();
            this.LDateAT = new System.Windows.Forms.Label();
            this.LGateAT = new System.Windows.Forms.Label();
            this.LFNAT = new System.Windows.Forms.Label();
            this.LTimeAT = new System.Windows.Forms.Label();
            this.CBSeats = new System.Windows.Forms.ComboBox();
            this.LFromBP = new System.Windows.Forms.Label();
            this.LCountryBP = new System.Windows.Forms.Label();
            this.LDateBP = new System.Windows.Forms.Label();
            this.LTimeBP = new System.Windows.Forms.Label();
            this.LGateBP = new System.Windows.Forms.Label();
            this.LFNBP = new System.Windows.Forms.Label();
            this.LFromAT = new System.Windows.Forms.Label();
            this.LCountryAT = new System.Windows.Forms.Label();
            this.CBTours = new System.Windows.Forms.ComboBox();
            this.PBPrintTicket = new System.Windows.Forms.PictureBox();
            this.SFDPDFTicket = new System.Windows.Forms.SaveFileDialog();
            this.CBSeatsTaken = new System.Windows.Forms.ComboBox();
            this.PBPrintTForTaken = new System.Windows.Forms.PictureBox();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPrintTicket)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPrintTForTaken)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 9);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(338, 40);
            this.LHeader.TabIndex = 1;
            this.LHeader.Text = "Enter Data to join as client";
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 761);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // TBPName
            // 
            this.TBPName.BackColor = System.Drawing.Color.BurlyWood;
            this.TBPName.Location = new System.Drawing.Point(104, 344);
            this.TBPName.Name = "TBPName";
            this.TBPName.Size = new System.Drawing.Size(213, 22);
            this.TBPName.TabIndex = 10;
            // 
            // CBClass
            // 
            this.CBClass.BackColor = System.Drawing.Color.BurlyWood;
            this.CBClass.FormattingEnabled = true;
            this.CBClass.Items.AddRange(new object[] {
            "First Class",
            "Business Class",
            "Premium Economy",
            "Regular Economy"});
            this.CBClass.Location = new System.Drawing.Point(103, 425);
            this.CBClass.Name = "CBClass";
            this.CBClass.Size = new System.Drawing.Size(174, 24);
            this.CBClass.TabIndex = 11;
            // 
            // LDateAT
            // 
            this.LDateAT.AutoSize = true;
            this.LDateAT.BackColor = System.Drawing.Color.Transparent;
            this.LDateAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDateAT.ForeColor = System.Drawing.Color.Black;
            this.LDateAT.Location = new System.Drawing.Point(517, 344);
            this.LDateAT.Name = "LDateAT";
            this.LDateAT.Size = new System.Drawing.Size(53, 20);
            this.LDateAT.TabIndex = 14;
            this.LDateAT.Text = "label1";
            // 
            // LGateAT
            // 
            this.LGateAT.AutoSize = true;
            this.LGateAT.BackColor = System.Drawing.Color.Transparent;
            this.LGateAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LGateAT.ForeColor = System.Drawing.Color.Black;
            this.LGateAT.Location = new System.Drawing.Point(517, 423);
            this.LGateAT.Name = "LGateAT";
            this.LGateAT.Size = new System.Drawing.Size(53, 20);
            this.LGateAT.TabIndex = 15;
            this.LGateAT.Text = "label2";
            // 
            // LFNAT
            // 
            this.LFNAT.AutoSize = true;
            this.LFNAT.BackColor = System.Drawing.Color.Transparent;
            this.LFNAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFNAT.ForeColor = System.Drawing.Color.Black;
            this.LFNAT.Location = new System.Drawing.Point(517, 504);
            this.LFNAT.Name = "LFNAT";
            this.LFNAT.Size = new System.Drawing.Size(53, 20);
            this.LFNAT.TabIndex = 16;
            this.LFNAT.Text = "label3";
            // 
            // LTimeAT
            // 
            this.LTimeAT.AutoSize = true;
            this.LTimeAT.BackColor = System.Drawing.Color.Transparent;
            this.LTimeAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTimeAT.ForeColor = System.Drawing.Color.Black;
            this.LTimeAT.Location = new System.Drawing.Point(711, 344);
            this.LTimeAT.Name = "LTimeAT";
            this.LTimeAT.Size = new System.Drawing.Size(53, 20);
            this.LTimeAT.TabIndex = 17;
            this.LTimeAT.Text = "label4";
            // 
            // CBSeats
            // 
            this.CBSeats.BackColor = System.Drawing.Color.BurlyWood;
            this.CBSeats.FormattingEnabled = true;
            this.CBSeats.Location = new System.Drawing.Point(715, 422);
            this.CBSeats.Name = "CBSeats";
            this.CBSeats.Size = new System.Drawing.Size(126, 24);
            this.CBSeats.TabIndex = 18;
            this.CBSeats.SelectedIndexChanged += new System.EventHandler(this.CBSeats_SelectedIndexChanged);
            // 
            // LFromBP
            // 
            this.LFromBP.AutoSize = true;
            this.LFromBP.BackColor = System.Drawing.Color.Transparent;
            this.LFromBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFromBP.ForeColor = System.Drawing.Color.Black;
            this.LFromBP.Location = new System.Drawing.Point(979, 354);
            this.LFromBP.Name = "LFromBP";
            this.LFromBP.Size = new System.Drawing.Size(53, 20);
            this.LFromBP.TabIndex = 20;
            this.LFromBP.Text = "label6";
            // 
            // LCountryBP
            // 
            this.LCountryBP.AutoSize = true;
            this.LCountryBP.BackColor = System.Drawing.Color.Transparent;
            this.LCountryBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCountryBP.ForeColor = System.Drawing.Color.Black;
            this.LCountryBP.Location = new System.Drawing.Point(979, 399);
            this.LCountryBP.Name = "LCountryBP";
            this.LCountryBP.Size = new System.Drawing.Size(53, 20);
            this.LCountryBP.TabIndex = 21;
            this.LCountryBP.Text = "label7";
            // 
            // LDateBP
            // 
            this.LDateBP.AutoSize = true;
            this.LDateBP.BackColor = System.Drawing.Color.Transparent;
            this.LDateBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDateBP.ForeColor = System.Drawing.Color.Black;
            this.LDateBP.Location = new System.Drawing.Point(979, 449);
            this.LDateBP.Name = "LDateBP";
            this.LDateBP.Size = new System.Drawing.Size(53, 20);
            this.LDateBP.TabIndex = 22;
            this.LDateBP.Text = "label8";
            // 
            // LTimeBP
            // 
            this.LTimeBP.AutoSize = true;
            this.LTimeBP.BackColor = System.Drawing.Color.Transparent;
            this.LTimeBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTimeBP.ForeColor = System.Drawing.Color.Black;
            this.LTimeBP.Location = new System.Drawing.Point(1120, 449);
            this.LTimeBP.Name = "LTimeBP";
            this.LTimeBP.Size = new System.Drawing.Size(53, 20);
            this.LTimeBP.TabIndex = 23;
            this.LTimeBP.Text = "label9";
            // 
            // LGateBP
            // 
            this.LGateBP.AutoSize = true;
            this.LGateBP.BackColor = System.Drawing.Color.Transparent;
            this.LGateBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LGateBP.ForeColor = System.Drawing.Color.Black;
            this.LGateBP.Location = new System.Drawing.Point(978, 496);
            this.LGateBP.Name = "LGateBP";
            this.LGateBP.Size = new System.Drawing.Size(62, 20);
            this.LGateBP.TabIndex = 24;
            this.LGateBP.Text = "label10";
            // 
            // LFNBP
            // 
            this.LFNBP.AutoSize = true;
            this.LFNBP.BackColor = System.Drawing.Color.Transparent;
            this.LFNBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFNBP.ForeColor = System.Drawing.Color.Black;
            this.LFNBP.Location = new System.Drawing.Point(979, 543);
            this.LFNBP.Name = "LFNBP";
            this.LFNBP.Size = new System.Drawing.Size(62, 20);
            this.LFNBP.TabIndex = 26;
            this.LFNBP.Text = "label12";
            // 
            // LFromAT
            // 
            this.LFromAT.AutoSize = true;
            this.LFromAT.BackColor = System.Drawing.Color.Transparent;
            this.LFromAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFromAT.ForeColor = System.Drawing.Color.Black;
            this.LFromAT.Location = new System.Drawing.Point(109, 504);
            this.LFromAT.Name = "LFromAT";
            this.LFromAT.Size = new System.Drawing.Size(62, 20);
            this.LFromAT.TabIndex = 27;
            this.LFromAT.Text = "label13";
            // 
            // LCountryAT
            // 
            this.LCountryAT.AutoSize = true;
            this.LCountryAT.BackColor = System.Drawing.Color.Transparent;
            this.LCountryAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCountryAT.ForeColor = System.Drawing.Color.Black;
            this.LCountryAT.Location = new System.Drawing.Point(109, 581);
            this.LCountryAT.Name = "LCountryAT";
            this.LCountryAT.Size = new System.Drawing.Size(62, 20);
            this.LCountryAT.TabIndex = 28;
            this.LCountryAT.Text = "label14";
            // 
            // CBTours
            // 
            this.CBTours.BackColor = System.Drawing.Color.BurlyWood;
            this.CBTours.FormattingEnabled = true;
            this.CBTours.Location = new System.Drawing.Point(79, 151);
            this.CBTours.Name = "CBTours";
            this.CBTours.Size = new System.Drawing.Size(1132, 24);
            this.CBTours.TabIndex = 29;
            this.CBTours.SelectedIndexChanged += new System.EventHandler(this.CBTours_SelectedIndexChanged);
            // 
            // PBPrintTicket
            // 
            this.PBPrintTicket.BackColor = System.Drawing.Color.Transparent;
            this.PBPrintTicket.Image = ((System.Drawing.Image)(resources.GetObject("PBPrintTicket.Image")));
            this.PBPrintTicket.Location = new System.Drawing.Point(885, 583);
            this.PBPrintTicket.Name = "PBPrintTicket";
            this.PBPrintTicket.Size = new System.Drawing.Size(100, 80);
            this.PBPrintTicket.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBPrintTicket.TabIndex = 30;
            this.PBPrintTicket.TabStop = false;
            this.PBPrintTicket.Click += new System.EventHandler(this.PBPrintTicket_Click);
            this.PBPrintTicket.MouseLeave += new System.EventHandler(this.PBPrintTicket_MouseLeave);
            this.PBPrintTicket.MouseHover += new System.EventHandler(this.PBPrintTicket_MouseHover);
            // 
            // CBSeatsTaken
            // 
            this.CBSeatsTaken.BackColor = System.Drawing.Color.BurlyWood;
            this.CBSeatsTaken.FormattingEnabled = true;
            this.CBSeatsTaken.Location = new System.Drawing.Point(715, 465);
            this.CBSeatsTaken.Name = "CBSeatsTaken";
            this.CBSeatsTaken.Size = new System.Drawing.Size(126, 24);
            this.CBSeatsTaken.TabIndex = 31;
            // 
            // PBPrintTForTaken
            // 
            this.PBPrintTForTaken.BackColor = System.Drawing.Color.Transparent;
            this.PBPrintTForTaken.Image = ((System.Drawing.Image)(resources.GetObject("PBPrintTForTaken.Image")));
            this.PBPrintTForTaken.Location = new System.Drawing.Point(727, 583);
            this.PBPrintTForTaken.Name = "PBPrintTForTaken";
            this.PBPrintTForTaken.Size = new System.Drawing.Size(100, 80);
            this.PBPrintTForTaken.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBPrintTForTaken.TabIndex = 32;
            this.PBPrintTForTaken.TabStop = false;
            this.PBPrintTForTaken.Click += new System.EventHandler(this.PBPrintTForTaken_Click);
            this.PBPrintTForTaken.MouseLeave += new System.EventHandler(this.PBPrintTForTaken_MouseLeave);
            this.PBPrintTForTaken.MouseHover += new System.EventHandler(this.PBPrintTForTaken_MouseHover);
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // FlightTicketForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.PBPrintTForTaken);
            this.Controls.Add(this.CBSeatsTaken);
            this.Controls.Add(this.PBPrintTicket);
            this.Controls.Add(this.CBTours);
            this.Controls.Add(this.LCountryAT);
            this.Controls.Add(this.LFromAT);
            this.Controls.Add(this.LFNBP);
            this.Controls.Add(this.LGateBP);
            this.Controls.Add(this.LTimeBP);
            this.Controls.Add(this.LDateBP);
            this.Controls.Add(this.LCountryBP);
            this.Controls.Add(this.LFromBP);
            this.Controls.Add(this.CBSeats);
            this.Controls.Add(this.LTimeAT);
            this.Controls.Add(this.LFNAT);
            this.Controls.Add(this.LGateAT);
            this.Controls.Add(this.LDateAT);
            this.Controls.Add(this.CBClass);
            this.Controls.Add(this.TBPName);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FlightTicketForm";
            this.Text = "Flight Tickets";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPrintTicket)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPrintTForTaken)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.TextBox TBPName;
        private System.Windows.Forms.ComboBox CBClass;
        private System.Windows.Forms.Label LDateAT;
        private System.Windows.Forms.Label LGateAT;
        private System.Windows.Forms.Label LFNAT;
        private System.Windows.Forms.Label LTimeAT;
        private System.Windows.Forms.ComboBox CBSeats;
        private System.Windows.Forms.Label LFromBP;
        private System.Windows.Forms.Label LCountryBP;
        private System.Windows.Forms.Label LDateBP;
        private System.Windows.Forms.Label LTimeBP;
        private System.Windows.Forms.Label LGateBP;
        private System.Windows.Forms.Label LFNBP;
        private System.Windows.Forms.Label LFromAT;
        private System.Windows.Forms.Label LCountryAT;
        private System.Windows.Forms.ComboBox CBTours;
        private System.Windows.Forms.PictureBox PBPrintTicket;
        private System.Windows.Forms.SaveFileDialog SFDPDFTicket;
        private System.Windows.Forms.ComboBox CBSeatsTaken;
        private System.Windows.Forms.PictureBox PBPrintTForTaken;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}