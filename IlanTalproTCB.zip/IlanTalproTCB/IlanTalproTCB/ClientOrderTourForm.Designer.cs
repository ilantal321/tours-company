﻿namespace IlanTalproTCB
{
    partial class ClientOrderTourForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClientOrderTourForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.LPrice = new System.Windows.Forms.Label();
            this.LTourName = new System.Windows.Forms.Label();
            this.LCountry = new System.Windows.Forms.Label();
            this.LFlightnumber = new System.Windows.Forms.Label();
            this.PBAddOrder = new System.Windows.Forms.PictureBox();
            this.LError = new System.Windows.Forms.Label();
            this.LDisdescription = new System.Windows.Forms.Label();
            this.LTourDate = new System.Windows.Forms.Label();
            this.LCapacity = new System.Windows.Forms.Label();
            this.LDays = new System.Windows.Forms.Label();
            this.LPicName = new System.Windows.Forms.Label();
            this.PBTourPic = new System.Windows.Forms.PictureBox();
            this.LPic = new System.Windows.Forms.Label();
            this.PBPlus = new System.Windows.Forms.PictureBox();
            this.PBMinus = new System.Windows.Forms.PictureBox();
            this.PBPicPlus = new System.Windows.Forms.PictureBox();
            this.PBPicMinus = new System.Windows.Forms.PictureBox();
            this.CBToursList = new System.Windows.Forms.ComboBox();
            this.LTourDatein = new System.Windows.Forms.Label();
            this.LTourID = new System.Windows.Forms.Label();
            this.TBTourID = new System.Windows.Forms.TextBox();
            this.PBFTID = new System.Windows.Forms.PictureBox();
            this.LTourFN = new System.Windows.Forms.Label();
            this.LTourPrice = new System.Windows.Forms.Label();
            this.LTourDays = new System.Windows.Forms.Label();
            this.LTourCap = new System.Windows.Forms.Label();
            this.LTourN = new System.Windows.Forms.Label();
            this.LTourCountry = new System.Windows.Forms.Label();
            this.TBQuantity = new System.Windows.Forms.TextBox();
            this.LQuantity = new System.Windows.Forms.Label();
            this.CBContinent = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LShowDisdescription = new System.Windows.Forms.Label();
            this.PBPrintTourPDF = new System.Windows.Forms.PictureBox();
            this.OFDAddPic = new System.Windows.Forms.OpenFileDialog();
            this.SFDTourPDF = new System.Windows.Forms.SaveFileDialog();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddOrder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBTourPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPlus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMinus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPicPlus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPicMinus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFTID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPrintTourPDF)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 9);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(244, 40);
            this.LHeader.TabIndex = 1;
            this.LHeader.Text = "Make a new order:";
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1171, 761);
            this.PBBack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // LPrice
            // 
            this.LPrice.AutoSize = true;
            this.LPrice.BackColor = System.Drawing.Color.Transparent;
            this.LPrice.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPrice.ForeColor = System.Drawing.Color.Black;
            this.LPrice.Location = new System.Drawing.Point(13, 107);
            this.LPrice.Name = "LPrice";
            this.LPrice.Size = new System.Drawing.Size(63, 29);
            this.LPrice.TabIndex = 13;
            this.LPrice.Text = "Price:";
            // 
            // LTourName
            // 
            this.LTourName.AutoSize = true;
            this.LTourName.BackColor = System.Drawing.Color.Transparent;
            this.LTourName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourName.ForeColor = System.Drawing.Color.Black;
            this.LTourName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourName.Location = new System.Drawing.Point(437, 110);
            this.LTourName.Name = "LTourName";
            this.LTourName.Size = new System.Drawing.Size(116, 29);
            this.LTourName.TabIndex = 15;
            this.LTourName.Text = "Tour Name:";
            // 
            // LCountry
            // 
            this.LCountry.AutoSize = true;
            this.LCountry.BackColor = System.Drawing.Color.Transparent;
            this.LCountry.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCountry.ForeColor = System.Drawing.Color.Black;
            this.LCountry.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCountry.Location = new System.Drawing.Point(437, 149);
            this.LCountry.Name = "LCountry";
            this.LCountry.Size = new System.Drawing.Size(86, 29);
            this.LCountry.TabIndex = 17;
            this.LCountry.Text = "Country:";
            // 
            // LFlightnumber
            // 
            this.LFlightnumber.AutoSize = true;
            this.LFlightnumber.BackColor = System.Drawing.Color.Transparent;
            this.LFlightnumber.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFlightnumber.ForeColor = System.Drawing.Color.Black;
            this.LFlightnumber.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LFlightnumber.Location = new System.Drawing.Point(13, 70);
            this.LFlightnumber.Name = "LFlightnumber";
            this.LFlightnumber.Size = new System.Drawing.Size(137, 29);
            this.LFlightnumber.TabIndex = 29;
            this.LFlightnumber.Text = "Flight number:";
            // 
            // PBAddOrder
            // 
            this.PBAddOrder.BackColor = System.Drawing.Color.Transparent;
            this.PBAddOrder.Image = ((System.Drawing.Image)(resources.GetObject("PBAddOrder.Image")));
            this.PBAddOrder.Location = new System.Drawing.Point(482, 284);
            this.PBAddOrder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBAddOrder.Name = "PBAddOrder";
            this.PBAddOrder.Size = new System.Drawing.Size(100, 80);
            this.PBAddOrder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAddOrder.TabIndex = 34;
            this.PBAddOrder.TabStop = false;
            this.PBAddOrder.Click += new System.EventHandler(this.PBAddOrder_Click);
            this.PBAddOrder.MouseLeave += new System.EventHandler(this.PBAddClient_MouseLeave);
            this.PBAddOrder.MouseHover += new System.EventHandler(this.PBAddClient_MouseHover);
            // 
            // LError
            // 
            this.LError.AutoSize = true;
            this.LError.BackColor = System.Drawing.Color.Transparent;
            this.LError.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LError.ForeColor = System.Drawing.Color.Black;
            this.LError.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LError.Location = new System.Drawing.Point(765, 113);
            this.LError.Name = "LError";
            this.LError.Size = new System.Drawing.Size(0, 29);
            this.LError.TabIndex = 36;
            // 
            // LDisdescription
            // 
            this.LDisdescription.AutoSize = true;
            this.LDisdescription.BackColor = System.Drawing.Color.Transparent;
            this.LDisdescription.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDisdescription.ForeColor = System.Drawing.Color.Black;
            this.LDisdescription.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LDisdescription.Location = new System.Drawing.Point(299, 369);
            this.LDisdescription.Name = "LDisdescription";
            this.LDisdescription.Size = new System.Drawing.Size(141, 29);
            this.LDisdescription.TabIndex = 19;
            this.LDisdescription.Text = "Disdescription:";
            // 
            // LTourDate
            // 
            this.LTourDate.AutoSize = true;
            this.LTourDate.BackColor = System.Drawing.Color.Transparent;
            this.LTourDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourDate.ForeColor = System.Drawing.Color.Black;
            this.LTourDate.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourDate.Location = new System.Drawing.Point(437, 192);
            this.LTourDate.Name = "LTourDate";
            this.LTourDate.Size = new System.Drawing.Size(105, 29);
            this.LTourDate.TabIndex = 10;
            this.LTourDate.Text = "Tour Date:";
            // 
            // LCapacity
            // 
            this.LCapacity.AutoSize = true;
            this.LCapacity.BackColor = System.Drawing.Color.Transparent;
            this.LCapacity.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LCapacity.ForeColor = System.Drawing.Color.Black;
            this.LCapacity.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LCapacity.Location = new System.Drawing.Point(13, 191);
            this.LCapacity.Name = "LCapacity";
            this.LCapacity.Size = new System.Drawing.Size(93, 29);
            this.LCapacity.TabIndex = 27;
            this.LCapacity.Text = "Capacity:";
            // 
            // LDays
            // 
            this.LDays.AutoSize = true;
            this.LDays.BackColor = System.Drawing.Color.Transparent;
            this.LDays.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDays.ForeColor = System.Drawing.Color.Black;
            this.LDays.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LDays.Location = new System.Drawing.Point(13, 150);
            this.LDays.Name = "LDays";
            this.LDays.Size = new System.Drawing.Size(62, 29);
            this.LDays.TabIndex = 25;
            this.LDays.Text = "Days:";
            // 
            // LPicName
            // 
            this.LPicName.AutoSize = true;
            this.LPicName.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPicName.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LPicName.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPicName.Location = new System.Drawing.Point(299, 536);
            this.LPicName.Name = "LPicName";
            this.LPicName.Size = new System.Drawing.Size(0, 29);
            this.LPicName.TabIndex = 43;
            this.LPicName.Visible = false;
            // 
            // PBTourPic
            // 
            this.PBTourPic.BackColor = System.Drawing.Color.Transparent;
            this.PBTourPic.Location = new System.Drawing.Point(69, 419);
            this.PBTourPic.Name = "PBTourPic";
            this.PBTourPic.Size = new System.Drawing.Size(203, 173);
            this.PBTourPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBTourPic.TabIndex = 42;
            this.PBTourPic.TabStop = false;
            // 
            // LPic
            // 
            this.LPic.AutoSize = true;
            this.LPic.BackColor = System.Drawing.Color.Transparent;
            this.LPic.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPic.ForeColor = System.Drawing.Color.Black;
            this.LPic.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPic.Location = new System.Drawing.Point(14, 419);
            this.LPic.Name = "LPic";
            this.LPic.Size = new System.Drawing.Size(45, 29);
            this.LPic.TabIndex = 40;
            this.LPic.Text = "Pic:";
            // 
            // PBPlus
            // 
            this.PBPlus.BackColor = System.Drawing.Color.Transparent;
            this.PBPlus.Image = ((System.Drawing.Image)(resources.GetObject("PBPlus.Image")));
            this.PBPlus.Location = new System.Drawing.Point(270, 284);
            this.PBPlus.Name = "PBPlus";
            this.PBPlus.Size = new System.Drawing.Size(59, 62);
            this.PBPlus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBPlus.TabIndex = 80;
            this.PBPlus.TabStop = false;
            this.PBPlus.Click += new System.EventHandler(this.PBPlus_Click);
            this.PBPlus.MouseLeave += new System.EventHandler(this.PBPlus_MouseLeave);
            this.PBPlus.MouseHover += new System.EventHandler(this.PBPlus_MouseHover);
            // 
            // PBMinus
            // 
            this.PBMinus.BackColor = System.Drawing.Color.Transparent;
            this.PBMinus.Image = ((System.Drawing.Image)(resources.GetObject("PBMinus.Image")));
            this.PBMinus.Location = new System.Drawing.Point(178, 284);
            this.PBMinus.Name = "PBMinus";
            this.PBMinus.Size = new System.Drawing.Size(59, 62);
            this.PBMinus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBMinus.TabIndex = 79;
            this.PBMinus.TabStop = false;
            this.PBMinus.Click += new System.EventHandler(this.PBMinus_Click);
            this.PBMinus.MouseLeave += new System.EventHandler(this.PBMinus_MouseLeave);
            this.PBMinus.MouseHover += new System.EventHandler(this.PBMinus_MouseHover);
            // 
            // PBPicPlus
            // 
            this.PBPicPlus.BackColor = System.Drawing.Color.Transparent;
            this.PBPicPlus.Image = ((System.Drawing.Image)(resources.GetObject("PBPicPlus.Image")));
            this.PBPicPlus.Location = new System.Drawing.Point(162, 598);
            this.PBPicPlus.Name = "PBPicPlus";
            this.PBPicPlus.Size = new System.Drawing.Size(59, 62);
            this.PBPicPlus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBPicPlus.TabIndex = 82;
            this.PBPicPlus.TabStop = false;
            this.PBPicPlus.Click += new System.EventHandler(this.PBPicPlus_Click);
            this.PBPicPlus.MouseLeave += new System.EventHandler(this.PBPicPlus_MouseLeave);
            this.PBPicPlus.MouseHover += new System.EventHandler(this.PBPicPlus_MouseHover);
            // 
            // PBPicMinus
            // 
            this.PBPicMinus.BackColor = System.Drawing.Color.Transparent;
            this.PBPicMinus.Image = ((System.Drawing.Image)(resources.GetObject("PBPicMinus.Image")));
            this.PBPicMinus.Location = new System.Drawing.Point(69, 598);
            this.PBPicMinus.Name = "PBPicMinus";
            this.PBPicMinus.Size = new System.Drawing.Size(59, 62);
            this.PBPicMinus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBPicMinus.TabIndex = 81;
            this.PBPicMinus.TabStop = false;
            this.PBPicMinus.Click += new System.EventHandler(this.PBPicMinus_Click);
            this.PBPicMinus.MouseLeave += new System.EventHandler(this.PBPicMinus_MouseLeave);
            this.PBPicMinus.MouseHover += new System.EventHandler(this.PBPicMinus_MouseHover);
            // 
            // CBToursList
            // 
            this.CBToursList.FormattingEnabled = true;
            this.CBToursList.Location = new System.Drawing.Point(442, 25);
            this.CBToursList.Name = "CBToursList";
            this.CBToursList.Size = new System.Drawing.Size(584, 24);
            this.CBToursList.TabIndex = 83;
            this.CBToursList.SelectedIndexChanged += new System.EventHandler(this.CBToursList_SelectedIndexChanged);
            // 
            // LTourDatein
            // 
            this.LTourDatein.AutoSize = true;
            this.LTourDatein.BackColor = System.Drawing.Color.Transparent;
            this.LTourDatein.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourDatein.ForeColor = System.Drawing.Color.Black;
            this.LTourDatein.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourDatein.Location = new System.Drawing.Point(594, 191);
            this.LTourDatein.Name = "LTourDatein";
            this.LTourDatein.Size = new System.Drawing.Size(0, 29);
            this.LTourDatein.TabIndex = 84;
            // 
            // LTourID
            // 
            this.LTourID.AutoSize = true;
            this.LTourID.BackColor = System.Drawing.Color.Transparent;
            this.LTourID.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourID.ForeColor = System.Drawing.Color.Black;
            this.LTourID.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourID.Location = new System.Drawing.Point(437, 69);
            this.LTourID.Name = "LTourID";
            this.LTourID.Size = new System.Drawing.Size(82, 29);
            this.LTourID.TabIndex = 85;
            this.LTourID.Text = "Tour ID:";
            // 
            // TBTourID
            // 
            this.TBTourID.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBTourID.Location = new System.Drawing.Point(599, 69);
            this.TBTourID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBTourID.MaxLength = 30;
            this.TBTourID.Name = "TBTourID";
            this.TBTourID.Size = new System.Drawing.Size(151, 27);
            this.TBTourID.TabIndex = 86;
            this.TBTourID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBTourID_KeyPress);
            // 
            // PBFTID
            // 
            this.PBFTID.BackColor = System.Drawing.Color.Transparent;
            this.PBFTID.Image = ((System.Drawing.Image)(resources.GetObject("PBFTID.Image")));
            this.PBFTID.Location = new System.Drawing.Point(756, 69);
            this.PBFTID.Name = "PBFTID";
            this.PBFTID.Size = new System.Drawing.Size(29, 27);
            this.PBFTID.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBFTID.TabIndex = 87;
            this.PBFTID.TabStop = false;
            this.PBFTID.Click += new System.EventHandler(this.PBFTID_Click);
            this.PBFTID.MouseLeave += new System.EventHandler(this.PBFTID_MouseLeave);
            this.PBFTID.MouseHover += new System.EventHandler(this.PBFTID_MouseHover);
            // 
            // LTourFN
            // 
            this.LTourFN.AutoSize = true;
            this.LTourFN.BackColor = System.Drawing.Color.Transparent;
            this.LTourFN.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourFN.ForeColor = System.Drawing.Color.Black;
            this.LTourFN.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourFN.Location = new System.Drawing.Point(244, 67);
            this.LTourFN.Name = "LTourFN";
            this.LTourFN.Size = new System.Drawing.Size(0, 29);
            this.LTourFN.TabIndex = 88;
            // 
            // LTourPrice
            // 
            this.LTourPrice.AutoSize = true;
            this.LTourPrice.BackColor = System.Drawing.Color.Transparent;
            this.LTourPrice.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourPrice.ForeColor = System.Drawing.Color.Black;
            this.LTourPrice.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourPrice.Location = new System.Drawing.Point(244, 113);
            this.LTourPrice.Name = "LTourPrice";
            this.LTourPrice.Size = new System.Drawing.Size(0, 29);
            this.LTourPrice.TabIndex = 89;
            // 
            // LTourDays
            // 
            this.LTourDays.AutoSize = true;
            this.LTourDays.BackColor = System.Drawing.Color.Transparent;
            this.LTourDays.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourDays.ForeColor = System.Drawing.Color.Black;
            this.LTourDays.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourDays.Location = new System.Drawing.Point(244, 150);
            this.LTourDays.Name = "LTourDays";
            this.LTourDays.Size = new System.Drawing.Size(0, 29);
            this.LTourDays.TabIndex = 90;
            // 
            // LTourCap
            // 
            this.LTourCap.AutoSize = true;
            this.LTourCap.BackColor = System.Drawing.Color.Transparent;
            this.LTourCap.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourCap.ForeColor = System.Drawing.Color.Black;
            this.LTourCap.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourCap.Location = new System.Drawing.Point(244, 191);
            this.LTourCap.Name = "LTourCap";
            this.LTourCap.Size = new System.Drawing.Size(0, 29);
            this.LTourCap.TabIndex = 91;
            // 
            // LTourN
            // 
            this.LTourN.AutoSize = true;
            this.LTourN.BackColor = System.Drawing.Color.Transparent;
            this.LTourN.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourN.ForeColor = System.Drawing.Color.Black;
            this.LTourN.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourN.Location = new System.Drawing.Point(594, 113);
            this.LTourN.Name = "LTourN";
            this.LTourN.Size = new System.Drawing.Size(0, 29);
            this.LTourN.TabIndex = 92;
            // 
            // LTourCountry
            // 
            this.LTourCountry.AutoSize = true;
            this.LTourCountry.BackColor = System.Drawing.Color.Transparent;
            this.LTourCountry.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LTourCountry.ForeColor = System.Drawing.Color.Black;
            this.LTourCountry.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LTourCountry.Location = new System.Drawing.Point(594, 150);
            this.LTourCountry.Name = "LTourCountry";
            this.LTourCountry.Size = new System.Drawing.Size(0, 29);
            this.LTourCountry.TabIndex = 93;
            // 
            // TBQuantity
            // 
            this.TBQuantity.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBQuantity.Location = new System.Drawing.Point(599, 234);
            this.TBQuantity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TBQuantity.MaxLength = 30;
            this.TBQuantity.Name = "TBQuantity";
            this.TBQuantity.Size = new System.Drawing.Size(151, 27);
            this.TBQuantity.TabIndex = 95;
            this.TBQuantity.Text = "1";
            this.TBQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBQuantity_KeyPress);
            // 
            // LQuantity
            // 
            this.LQuantity.AutoSize = true;
            this.LQuantity.BackColor = System.Drawing.Color.Transparent;
            this.LQuantity.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LQuantity.ForeColor = System.Drawing.Color.Black;
            this.LQuantity.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LQuantity.Location = new System.Drawing.Point(437, 234);
            this.LQuantity.Name = "LQuantity";
            this.LQuantity.Size = new System.Drawing.Size(89, 29);
            this.LQuantity.TabIndex = 94;
            this.LQuantity.Text = "Quantity:";
            // 
            // CBContinent
            // 
            this.CBContinent.FormattingEnabled = true;
            this.CBContinent.Location = new System.Drawing.Point(178, 237);
            this.CBContinent.Name = "CBContinent";
            this.CBContinent.Size = new System.Drawing.Size(151, 24);
            this.CBContinent.TabIndex = 97;
            this.CBContinent.SelectedIndexChanged += new System.EventHandler(this.CBContinent_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(11, 234);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 29);
            this.label1.TabIndex = 96;
            this.label1.Text = "Continent:";
            // 
            // LShowDisdescription
            // 
            this.LShowDisdescription.AutoSize = true;
            this.LShowDisdescription.BackColor = System.Drawing.Color.Transparent;
            this.LShowDisdescription.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LShowDisdescription.ForeColor = System.Drawing.Color.Black;
            this.LShowDisdescription.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LShowDisdescription.Location = new System.Drawing.Point(300, 398);
            this.LShowDisdescription.Name = "LShowDisdescription";
            this.LShowDisdescription.Size = new System.Drawing.Size(0, 29);
            this.LShowDisdescription.TabIndex = 98;
            // 
            // PBPrintTourPDF
            // 
            this.PBPrintTourPDF.BackColor = System.Drawing.Color.Transparent;
            this.PBPrintTourPDF.Image = ((System.Drawing.Image)(resources.GetObject("PBPrintTourPDF.Image")));
            this.PBPrintTourPDF.Location = new System.Drawing.Point(657, 284);
            this.PBPrintTourPDF.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBPrintTourPDF.Name = "PBPrintTourPDF";
            this.PBPrintTourPDF.Size = new System.Drawing.Size(100, 80);
            this.PBPrintTourPDF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBPrintTourPDF.TabIndex = 99;
            this.PBPrintTourPDF.TabStop = false;
            this.PBPrintTourPDF.Click += new System.EventHandler(this.PBPrintTourPDF_Click);
            this.PBPrintTourPDF.MouseLeave += new System.EventHandler(this.PBPrintTourPDF_MouseLeave);
            this.PBPrintTourPDF.MouseHover += new System.EventHandler(this.PBPrintTourPDF_MouseHover);
            // 
            // OFDAddPic
            // 
            this.OFDAddPic.FileName = "OFDAddPic";
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // ClientOrderTourForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.PBPrintTourPDF);
            this.Controls.Add(this.LShowDisdescription);
            this.Controls.Add(this.CBContinent);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TBQuantity);
            this.Controls.Add(this.LQuantity);
            this.Controls.Add(this.LTourCountry);
            this.Controls.Add(this.LTourN);
            this.Controls.Add(this.LTourCap);
            this.Controls.Add(this.LTourDays);
            this.Controls.Add(this.LTourPrice);
            this.Controls.Add(this.LTourFN);
            this.Controls.Add(this.PBFTID);
            this.Controls.Add(this.TBTourID);
            this.Controls.Add(this.LTourID);
            this.Controls.Add(this.LTourDatein);
            this.Controls.Add(this.CBToursList);
            this.Controls.Add(this.PBPicPlus);
            this.Controls.Add(this.PBPicMinus);
            this.Controls.Add(this.PBPlus);
            this.Controls.Add(this.PBMinus);
            this.Controls.Add(this.LPicName);
            this.Controls.Add(this.PBTourPic);
            this.Controls.Add(this.LPic);
            this.Controls.Add(this.LError);
            this.Controls.Add(this.PBAddOrder);
            this.Controls.Add(this.LFlightnumber);
            this.Controls.Add(this.LCapacity);
            this.Controls.Add(this.LDays);
            this.Controls.Add(this.LDisdescription);
            this.Controls.Add(this.LCountry);
            this.Controls.Add(this.LTourName);
            this.Controls.Add(this.LPrice);
            this.Controls.Add(this.LTourDate);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ClientOrderTourForm";
            this.Text = "Client oreder tours";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAddOrder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBTourPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPlus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBMinus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPicPlus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPicMinus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBFTID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBPrintTourPDF)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.Label LPrice;
        private System.Windows.Forms.Label LTourName;
        private System.Windows.Forms.Label LCountry;
        private System.Windows.Forms.Label LFlightnumber;
        private System.Windows.Forms.PictureBox PBAddOrder;
        private System.Windows.Forms.Label LError;
        private System.Windows.Forms.Label LDisdescription;
        private System.Windows.Forms.Label LTourDate;
        private System.Windows.Forms.Label LCapacity;
        private System.Windows.Forms.Label LDays;
        private System.Windows.Forms.Label LPicName;
        private System.Windows.Forms.PictureBox PBTourPic;
        private System.Windows.Forms.Label LPic;
        private System.Windows.Forms.PictureBox PBPlus;
        private System.Windows.Forms.PictureBox PBMinus;
        private System.Windows.Forms.PictureBox PBPicPlus;
        private System.Windows.Forms.PictureBox PBPicMinus;
        private System.Windows.Forms.ComboBox CBToursList;
        private System.Windows.Forms.Label LTourDatein;
        private System.Windows.Forms.Label LTourID;
        private System.Windows.Forms.TextBox TBTourID;
        private System.Windows.Forms.PictureBox PBFTID;
        private System.Windows.Forms.Label LTourFN;
        private System.Windows.Forms.Label LTourPrice;
        private System.Windows.Forms.Label LTourDays;
        private System.Windows.Forms.Label LTourCap;
        private System.Windows.Forms.Label LTourN;
        private System.Windows.Forms.Label LTourCountry;
        private System.Windows.Forms.TextBox TBQuantity;
        private System.Windows.Forms.Label LQuantity;
        private System.Windows.Forms.ComboBox CBContinent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LShowDisdescription;
        private System.Windows.Forms.PictureBox PBPrintTourPDF;
        private System.Windows.Forms.OpenFileDialog OFDAddPic;
        private System.Windows.Forms.SaveFileDialog SFDTourPDF;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}