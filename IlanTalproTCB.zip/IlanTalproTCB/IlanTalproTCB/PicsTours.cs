﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class PicsTours
    {
        int PKID;
        int TourID;
        string PicName;
        /*
        empty constractor
        */
        public PicsTours()
        {

        }
        /*
        constractor
        */
        public PicsTours(int pid,int tid,string pic)
        {
            PKID = pid;
            TourID = tid;
            PicName = pic;
        }
        /*
        get and set
        */
        public void SetPKID(int pk)
        {
            PKID = pk;
        }
        public void SetTourID(int tid)
        {
            TourID = tid;
        }
        public void SetPicName(string pic)
        {
            PicName = pic;
        }
        public int GetPKID()
        {
            return PKID;
        }
        public int GetTourID()
        {
            return TourID;
        }
        public string GetPicName()
        {
            return PicName;
        }
        /*
        add pic to data base
        */
        public void AddPicToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("INSERT INTO Pics_Tours VALUES ( '" + PKID + "', '" + PicName + "', " + TourID + ");");
            dr.Close();
            connec.closeCon();
        }
        /*
        delete pic from database
        */
        public void DeletePicToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("Delete from Pics_Tours where PKID = " + PKID + " ; ");
            dr.Close();
            connec.closeCon();
        }
    }
}
