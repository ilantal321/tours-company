﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
namespace IlanTalproTCB
{
    class Worker : Person
    {
        protected int Salary;
        protected DateTime DateAbsorption;
        /*
        empty constractor
        */
        public Worker()
        {
        }
        /*
         constractor
        */
        public Worker(int pid,string FN, string LN, string Add, string BD, string icity, string UN, string PS, string iPic, string id, int s,bool a) 
            : base (pid, FN,  LN,  Add,  BD,  icity,  UN,  PS,  iPic,  id,a)
        {
            Salary = s;
            DateAbsorption = DateTime.Now;
        }
        public Worker(int pid, string FN, string LN, string Add, string BD, string icity, string UN, string PS, string iPic, string id, int s, bool a,DateTime dd)
    : base(pid, FN, LN, Add, BD, icity, UN, PS, iPic, id, a)
        {
            Salary = s;
            DateAbsorption = dd;
        }
        /*
         constractor from pkid
        */
        public Worker(string CPKID)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Workers where PKID=" + CPKID + ";");
            while (dr.Read())
            {
                PKID = int.Parse(dr["PKID"].ToString());
                FirstName = dr["FirstName"].ToString();
                LastName = dr["LastName"].ToString();
                Address = dr["Address"].ToString();
                birthdate = dr["Birthdate"].ToString();
                City = dr["City"].ToString();
                UserName = dr["UserName"].ToString();
                Password = dr["Passw"].ToString();
                Pic = dr["Pic"].ToString();
                ID = dr["ID"].ToString();
                Salary = int.Parse(dr["Salary"].ToString());
                DateAbsorption= Convert.ToDateTime(dr["DateAbsorption"]);
                Activity = (bool)dr["active"];
            }
            dr.Close();
            connec.closeCon();
        }
        /*
         get and set
        */
        public void SetSalary(int s)
        {
            Salary = s;
        }
        public void SetDateAbs(DateTime D)
        {
            DateAbsorption = D;
        }
        public double GetSalary()
        {
            return Salary;
        }
        public DateTime GetADate()
        {
            return DateAbsorption;
        }
        /*
         print data
        */
        public string PrintWorker => base.PrintPerson()
                   + string.Format("\nSalary:" + Salary+ "\nAbsorption Date:"+DateAbsorption.ToString());
        public string PrintWorkerForClietPDF()
        {
            return "PKID:"+PKID+"\n"+"UserName:"+UserName;
        }
        /*
        update from database
        */
        public void UpdateWorkerToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("UPDATE Workers SET UserName = '" + UserName + "', FirstName = '" + FirstName + "' , LastName = '" + LastName + "' , Address = '" + Address + "' , City= '" + City + "' , Pic='" + Pic + "' , Salary=" + Salary + " WHERE PKID = " + PKID + " ;");
            dr.Close();
            connec.closeCon();
        }
        /*
        add to database
        */
        public void AddWorkerToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("INSERT INTO Workers VALUES("+PKID+", '"+UserName+"', '"+Password+"', '"+FirstName+"', '"+LastName+"', '"+Address+"', '"+ birthdate + "', '"+City+"', '"+Pic+"', '"+ID+"', "+Salary+", Now(),"+ Activity+");");
            dr.Close();
            connec.closeCon();
        }
        /*
        update password from database
        */
        public void UpdateWorkerPasswordToDB(string newpassword)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("UPDATE Workers SET Passw ='" + newpassword + "' WHERE PKID = " + PKID + "; ");
            dr.Close();
            connec.closeCon();
        }
        /*
        activate/deactivate
        */
        public void UpdateWorkerActivityToDB(bool Active)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("UPDATE Workers SET active =" + Active.ToString() + " WHERE PKID = " + PKID + "; ");
            dr.Close();
            connec.closeCon();
            Activity = Active;
        }
        /*
        show age by Birthday
        */
        public new int ShowAge()
        {
            return base.ShowAge();
        }
        /*
        get unpaid orders count
        */
        public int GetOrderCount()
        {
            int OrderCount = 0;
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("SELECT COUNT(WorkerPKID) AS [counter] FROM Orders Where WorkerPKID = " + PKID + " and Payment=false and Active= True;");
            while (dr.Read())
            {
                OrderCount = int.Parse(dr["counter"].ToString());
            }
            dr.Close();
            connec.closeCon();
            return OrderCount;

        }
        /*
        get paid orders count
        */
        public int GetOrderCount2()
        {
            int OrderCount = 0;
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("SELECT COUNT(WorkerPKID) AS [counter] FROM Orders Where WorkerPKID = " + PKID + " and Payment=True and Active= True;");
            while (dr.Read())
            {
                OrderCount = int.Parse(dr["counter"].ToString());
            }
            dr.Close();
            connec.closeCon();
            return OrderCount;
        }
        /*
        get canacelsed orders count
        */
        public int GetOrderCount3()
        {
            int OrderCount = 0;
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("SELECT COUNT(WorkerPKID) AS [counter] FROM Orders Where WorkerPKID = " + PKID + " and  Active= false;");
            while (dr.Read())
            {
                OrderCount = int.Parse(dr["counter"].ToString());
            }
            dr.Close();
            connec.closeCon();
            return OrderCount;
        }
        /*
        make worker pdf data
        */
        public void PrintWorkerDataPDF(string fileName, string ChartLocation, string FileLocation)
        {
            ReceiptList rl = new ReceiptList();
            Document doc = new Document(iTextSharp.text.PageSize.A4, 10, 10, 42, 35);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(FileLocation + "/" + fileName + ".pdf", FileMode.Create));
            int i,sum=0;
            doc.Open();

            iTextSharp.text.Image image = iTextSharp.text.Image.GetInstance("pic/plane.png");
            image.SetAbsolutePosition(doc.LeftMargin, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            image.ScaleAbsolute(40f, 40f);
            doc.Add(image);

            image = iTextSharp.text.Image.GetInstance("pic/Workers/" + Pic);
            image.SetAbsolutePosition(wri.PageSize.GetRight(doc.RightMargin) - 60f, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            image.ScaleAbsolute(50f, 50f);
            doc.Add(image);

            image = iTextSharp.text.Image.GetInstance("pic/IT.png");
            image.ScaleAbsolute(50f, 50f);
            image.SetAbsolutePosition((PageSize.A4.Width - image.ScaledWidth) / 2, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            doc.Add(image);

            Paragraph p = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, BaseColor.BLACK, Element.ALIGN_LEFT, 1)));
            doc.Add(p);

            Paragraph paragraph1 = new Paragraph("Worker Data From \nWorker: " + FirstName + " " + LastName + "\nPrint Time:" + DateTime.Now);
            paragraph1.Alignment = Element.ALIGN_CENTER;
            doc.Add(paragraph1);

            Worker w = new Worker(PKID.ToString());
            Paragraph paragraph2 = new Paragraph(w.PrintWorker);
            doc.Add(paragraph2);
            image = iTextSharp.text.Image.GetInstance(ChartLocation);
            image.ScaleAbsolute(250f, 250f);
            image.SetAbsolutePosition((PageSize.A4.Width - image.ScaledWidth) / 2, (PageSize.A4.Height - image.ScaledHeight) / 2);
            doc.Add(image);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            PdfPTable table = new PdfPTable(8);
            PdfPCell cell = new PdfPCell(new Phrase(FirstName + " " + LastName + " paid Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Tour ID");
            table.AddCell("Tour Name");
            table.AddCell("Tour Date");
            table.AddCell("Payment");
            table.AddCell("Price");
            table.AddCell("Quantity");
            table.AddCell("Total");
            rl.BuildReceiptsByWorkerpaidActive(PKID);
            int counter = rl.GetReceiptsList().Count;
            for (i = 0; i < counter; i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourID().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourname());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetPaymentDate().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetPrice().ToString() + "$");
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString() + "$");
                sum+= rl.GetReceiptsList()[i].GetOrder().GetQuantity() *(rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString()+"$");
            doc.Add(table);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            rl.BuildReceiptsByWorkerUnpaidActive(PKID);
            table = new PdfPTable(8);
            cell = new PdfPCell(new Phrase(FirstName + " " + LastName + " unpaid Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Tour ID");
            table.AddCell("Tour Name");
            table.AddCell("Tour Date");
            table.AddCell("Client ID");
            table.AddCell("Price");
            table.AddCell("Quantity");
            table.AddCell("Total");
            counter = rl.GetReceiptsList().Count;
            sum = 0;
            for (i = 0; i < counter; i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourID().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourname());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetClient().GetID());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetPrice().ToString() + "$");
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString() + "$");
                sum += rl.GetReceiptsList()[i].GetOrder().GetQuantity() * (rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString() + "$");
            doc.Add(table);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            rl.BuildReceiptsByWorkerUnpaidUnActive(PKID);
            table = new PdfPTable(8);
            cell = new PdfPCell(new Phrase(FirstName + " " + LastName + " Canceled Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Tour ID");
            table.AddCell("Tour Name");
            table.AddCell("Tour Date");
            table.AddCell("Client ID");
            table.AddCell("Price");
            table.AddCell("Quantity");
            table.AddCell("Total");
            counter = rl.GetReceiptsList().Count;
            sum = 0;
            for (i = 0; i < counter; i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourID().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourname());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetClient().GetID());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetPrice().ToString() + "$");
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString() + "$");
                sum += rl.GetReceiptsList()[i].GetOrder().GetQuantity() * (rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString() + "$");
            doc.Add(table);

            doc.Close();
        }
    }

}
