﻿namespace IlanTalproTCB
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.LWelcome = new System.Windows.Forms.Label();
            this.LUsername = new System.Windows.Forms.Label();
            this.TBUsername = new System.Windows.Forms.TextBox();
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.LPassword = new System.Windows.Forms.Label();
            this.TBPassword = new System.Windows.Forms.TextBox();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBLogin = new System.Windows.Forms.PictureBox();
            this.CBPermissions = new System.Windows.Forms.ComboBox();
            this.LPermission = new System.Windows.Forms.Label();
            this.LErrorUsername = new System.Windows.Forms.Label();
            this.LErrorPassword = new System.Windows.Forms.Label();
            this.LNotLogin = new System.Windows.Forms.Label();
            this.PBNewC = new System.Windows.Forms.PictureBox();
            this.LActivity = new System.Windows.Forms.Label();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBLogin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBNewC)).BeginInit();
            this.SuspendLayout();
            // 
            // LWelcome
            // 
            this.LWelcome.AutoSize = true;
            this.LWelcome.BackColor = System.Drawing.Color.Transparent;
            this.LWelcome.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LWelcome.ForeColor = System.Drawing.Color.Black;
            this.LWelcome.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LWelcome.Location = new System.Drawing.Point(12, 9);
            this.LWelcome.Name = "LWelcome";
            this.LWelcome.Size = new System.Drawing.Size(433, 40);
            this.LWelcome.TabIndex = 0;
            this.LWelcome.Text = "Welcome to I.T traveling company";
            // 
            // LUsername
            // 
            this.LUsername.AutoSize = true;
            this.LUsername.BackColor = System.Drawing.Color.Transparent;
            this.LUsername.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LUsername.ForeColor = System.Drawing.Color.Black;
            this.LUsername.Location = new System.Drawing.Point(90, 109);
            this.LUsername.Name = "LUsername";
            this.LUsername.Size = new System.Drawing.Size(114, 29);
            this.LUsername.TabIndex = 1;
            this.LUsername.Text = "User name:";
            // 
            // TBUsername
            // 
            this.TBUsername.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBUsername.Location = new System.Drawing.Point(210, 111);
            this.TBUsername.MaxLength = 8;
            this.TBUsername.Name = "TBUsername";
            this.TBUsername.Size = new System.Drawing.Size(151, 27);
            this.TBUsername.TabIndex = 2;
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 3;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // LPassword
            // 
            this.LPassword.AutoSize = true;
            this.LPassword.BackColor = System.Drawing.Color.Transparent;
            this.LPassword.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPassword.ForeColor = System.Drawing.Color.Black;
            this.LPassword.Location = new System.Drawing.Point(94, 161);
            this.LPassword.Name = "LPassword";
            this.LPassword.Size = new System.Drawing.Size(106, 29);
            this.LPassword.TabIndex = 4;
            this.LPassword.Text = "Password:";
            // 
            // TBPassword
            // 
            this.TBPassword.Font = new System.Drawing.Font("Arial Narrow", 10.2F);
            this.TBPassword.Location = new System.Drawing.Point(210, 161);
            this.TBPassword.MaxLength = 10;
            this.TBPassword.Name = "TBPassword";
            this.TBPassword.PasswordChar = '*';
            this.TBPassword.Size = new System.Drawing.Size(151, 27);
            this.TBPassword.TabIndex = 5;
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 6;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBLogin
            // 
            this.PBLogin.BackColor = System.Drawing.Color.Transparent;
            this.PBLogin.Image = ((System.Drawing.Image)(resources.GetObject("PBLogin.Image")));
            this.PBLogin.Location = new System.Drawing.Point(210, 272);
            this.PBLogin.Name = "PBLogin";
            this.PBLogin.Size = new System.Drawing.Size(100, 80);
            this.PBLogin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBLogin.TabIndex = 7;
            this.PBLogin.TabStop = false;
            this.PBLogin.Click += new System.EventHandler(this.PBLogin_Click);
            this.PBLogin.MouseLeave += new System.EventHandler(this.PBLogin_MouseLeave);
            this.PBLogin.MouseHover += new System.EventHandler(this.PBLogin_MouseHover);
            // 
            // CBPermissions
            // 
            this.CBPermissions.Font = new System.Drawing.Font("Arial Narrow", 10.2F);
            this.CBPermissions.FormattingEnabled = true;
            this.CBPermissions.Location = new System.Drawing.Point(210, 214);
            this.CBPermissions.Name = "CBPermissions";
            this.CBPermissions.Size = new System.Drawing.Size(151, 30);
            this.CBPermissions.TabIndex = 8;
            // 
            // LPermission
            // 
            this.LPermission.AutoSize = true;
            this.LPermission.BackColor = System.Drawing.Color.Transparent;
            this.LPermission.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPermission.ForeColor = System.Drawing.Color.Black;
            this.LPermission.Location = new System.Drawing.Point(94, 216);
            this.LPermission.Name = "LPermission";
            this.LPermission.Size = new System.Drawing.Size(115, 29);
            this.LPermission.TabIndex = 9;
            this.LPermission.Text = "Permission:";
            // 
            // LErrorUsername
            // 
            this.LErrorUsername.AutoSize = true;
            this.LErrorUsername.BackColor = System.Drawing.Color.Transparent;
            this.LErrorUsername.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LErrorUsername.ForeColor = System.Drawing.Color.DarkRed;
            this.LErrorUsername.Location = new System.Drawing.Point(206, 136);
            this.LErrorUsername.Name = "LErrorUsername";
            this.LErrorUsername.Size = new System.Drawing.Size(434, 22);
            this.LErrorUsername.TabIndex = 10;
            this.LErrorUsername.Text = "Username needs 8 characters long and first 3 characters are letters";
            this.LErrorUsername.Visible = false;
            // 
            // LErrorPassword
            // 
            this.LErrorPassword.AutoSize = true;
            this.LErrorPassword.BackColor = System.Drawing.Color.Transparent;
            this.LErrorPassword.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LErrorPassword.ForeColor = System.Drawing.Color.Maroon;
            this.LErrorPassword.Location = new System.Drawing.Point(206, 189);
            this.LErrorPassword.Name = "LErrorPassword";
            this.LErrorPassword.Size = new System.Drawing.Size(231, 22);
            this.LErrorPassword.TabIndex = 11;
            this.LErrorPassword.Text = "Password must have 10 chars long";
            this.LErrorPassword.Visible = false;
            // 
            // LNotLogin
            // 
            this.LNotLogin.AutoSize = true;
            this.LNotLogin.BackColor = System.Drawing.Color.Transparent;
            this.LNotLogin.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNotLogin.ForeColor = System.Drawing.Color.DarkRed;
            this.LNotLogin.Location = new System.Drawing.Point(206, 247);
            this.LNotLogin.Name = "LNotLogin";
            this.LNotLogin.Size = new System.Drawing.Size(161, 22);
            this.LNotLogin.TabIndex = 12;
            this.LNotLogin.Text = "Wrong Data! Cant Login";
            this.LNotLogin.Visible = false;
            // 
            // PBNewC
            // 
            this.PBNewC.BackColor = System.Drawing.Color.Transparent;
            this.PBNewC.Image = ((System.Drawing.Image)(resources.GetObject("PBNewC.Image")));
            this.PBNewC.Location = new System.Drawing.Point(1170, 761);
            this.PBNewC.Name = "PBNewC";
            this.PBNewC.Size = new System.Drawing.Size(100, 80);
            this.PBNewC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBNewC.TabIndex = 13;
            this.PBNewC.TabStop = false;
            this.PBNewC.Click += new System.EventHandler(this.PBNewC_Click);
            this.PBNewC.MouseLeave += new System.EventHandler(this.PBNewC_MouseLeave);
            this.PBNewC.MouseHover += new System.EventHandler(this.PBNewC_MouseHover);
            // 
            // LActivity
            // 
            this.LActivity.AutoSize = true;
            this.LActivity.BackColor = System.Drawing.Color.Transparent;
            this.LActivity.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LActivity.ForeColor = System.Drawing.Color.DarkRed;
            this.LActivity.Location = new System.Drawing.Point(206, 247);
            this.LActivity.Name = "LActivity";
            this.LActivity.Size = new System.Drawing.Size(191, 22);
            this.LActivity.TabIndex = 14;
            this.LActivity.Text = "You no longer an active user";
            this.LActivity.Visible = false;
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.LActivity);
            this.Controls.Add(this.PBNewC);
            this.Controls.Add(this.LNotLogin);
            this.Controls.Add(this.LErrorPassword);
            this.Controls.Add(this.LErrorUsername);
            this.Controls.Add(this.LPermission);
            this.Controls.Add(this.CBPermissions);
            this.Controls.Add(this.PBLogin);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.TBPassword);
            this.Controls.Add(this.LPassword);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.TBUsername);
            this.Controls.Add(this.LUsername);
            this.Controls.Add(this.LWelcome);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LoginForm";
            this.Text = "Login";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.LoginForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBLogin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBNewC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LWelcome;
        private System.Windows.Forms.Label LUsername;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.Label LPassword;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBLogin;
        private System.Windows.Forms.Label LPermission;
        private System.Windows.Forms.Label LErrorUsername;
        private System.Windows.Forms.Label LErrorPassword;
        private System.Windows.Forms.Label LNotLogin;
        private System.Windows.Forms.PictureBox PBNewC;
        public System.Windows.Forms.TextBox TBUsername;
        public System.Windows.Forms.TextBox TBPassword;
        public System.Windows.Forms.ComboBox CBPermissions;
        private System.Windows.Forms.Label LActivity;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}

