﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
namespace IlanTalproTCB
{
    class Client : Person
    {
        protected string EMail;
        protected string PhoneNumber;
        /*
        empty constractor
        */
        public Client()
        {

        }
        /*
        constractor from person 
        */
        public Client(int pid, string FN, string LN, string Add, string BD, string icity, string UN, string PS, string iPic, string id, string Mail, string PN, bool a)
    : base(pid, FN, LN, Add, BD, icity, UN, PS, iPic, id, a)
        {
            EMail = Mail;
            PhoneNumber = PN;
        }
        /*
        copy constractor
        */
        public Client(Client c)  
        {
            PKID = c.PKID;
            FirstName = c.FirstName;
            LastName = c.LastName;
            Address = c.Address;
            birthdate = c.birthdate;
            City = c.City;
            UserName = c.UserName;
            Password = c.Password;
            Pic = c.Pic;
            ID = c.ID;
            Activity = c.Activity;
            EMail = c.EMail;
            PhoneNumber = c.PhoneNumber;
        }
        /*
        constractor from Database
        */
        public Client(string CPKID)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("Select * from Clients where PKID=" + CPKID+";");
            while (dr.Read())
            {
                PKID= int.Parse(dr["PKID"].ToString());
                FirstName = dr["FirstName"].ToString();
                LastName = dr["LastName"].ToString();
                Address = dr["Address"].ToString();
                birthdate = dr["Birthdate"].ToString();
                City= dr["City"].ToString();
                UserName = dr["UserName"].ToString();
                Password = dr["Passw"].ToString();
                Pic = dr["Pic"].ToString();
                ID = dr["ID"].ToString();
                EMail = dr["Email"].ToString();
                PhoneNumber= dr["PhoneNumber"].ToString();
                Activity=(bool)dr["active"];
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        set and get
        */
        public void SetMail(string Mail)
        {
            EMail = Mail;
        }
        public void SetPhoneNumber(string PN)
        {
            PhoneNumber = PN;
        }
        public string GetMail()
        {
            return EMail;
        }
        public string GetPhoneNumber()
        {
            return PhoneNumber;
        }
        /*
        get client count of unpaid orders
        */
        public int GetOrderCount()
        {
            int OrderCount = 0;
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("SELECT COUNT(ClientPKID) AS [counter] FROM Orders Where ClientPKID = " + PKID + " and Payment=false and Active= True;");
            while (dr.Read())
            {
                OrderCount = int.Parse(dr["counter"].ToString());
            }
            dr.Close();
            connec.closeCon();
            return OrderCount;

        }
        /*
        get client count of paid orders
        */
        public int GetOrderCount2()
        {
            int OrderCount = 0;
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("SELECT COUNT(ClientPKID) AS [counter] FROM Orders Where ClientPKID = " + PKID + " and Payment=True and Active= True;");
            while (dr.Read())
            {
                OrderCount = int.Parse(dr["counter"].ToString());
            }
            dr.Close();
            connec.closeCon();
            return OrderCount;
        }
        /*
        get client count of canceled orders
        */
        public int GetOrderCount3()
        {
            int OrderCount = 0;
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("SELECT COUNT(ClientPKID) AS [counter] FROM Orders Where ClientPKID = " + PKID + " and  Active= false;");
            while (dr.Read())
            {
                OrderCount = int.Parse(dr["counter"].ToString());
            }
            dr.Close();
            connec.closeCon();
            return OrderCount;
        }
        /*
        print data
        */
        public string PrintClient => base.PrintPerson()
                   + string.Format("\nPhone number:"+PhoneNumber);
        /*
        add client to data base
        */
        public void AddClientToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("INSERT INTO Clients VALUES ( '" + UserName + "', '" + sh.GetSHA1(Password) + "', '" + FirstName + "', '" + LastName + "', '" + Address + "', '" + birthdate + "' , '" + City + "', '" + Pic + "', '" + ID + "','" + EMail + "', '" + PhoneNumber + "', "+Activity+" ,"+PKID+");");
            dr.Close();
            connec.closeCon();
        }
        /*
        update client on the data base
        */
        public void UpdateClientToDB()
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("UPDATE Clients SET UserName = '"+UserName+ "', FirstName = '" + FirstName + "' , LastName = '" + LastName+ "' , Address = '"+Address + "' , City= '"+ City+ "' , Pic='"+Pic+ "' , Email = '"+EMail+ "' , PhoneNumber ='"+PhoneNumber + "' WHERE PKID = "+PKID+" ;");
            dr.Close();
            connec.closeCon();
        }
        /*
        update client password on the data base
        */
        public void UpdateClientPasswordToDB(string newpassword)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            sha1ceypto sh = new sha1ceypto();
            dr = connec.SandQuery("UPDATE Clients SET Passw ='" + newpassword +"' WHERE PKID = "+PKID+"; ");
            dr.Close();
            connec.closeCon();
        }
        /*
        update client activity on the data base
        */
        public void UpdateClientActivityToDB(bool Active)
        {
            OleDbDataReader dr;
            Myconn connec = new Myconn();
            dr = connec.SandQuery("UPDATE Clients SET active =" + Active.ToString() + " WHERE PKID = " + PKID + "; ");
            dr.Close();
            connec.closeCon();
            Activity = Active;
        }
        /*
        show age by Birthday
        */
        public new int  ShowAge()
        {
            return base.ShowAge();
        }
        /*
        make client PDF data file
        */
        public void PrintClientDataPDF(string fileName, string ChartLocation,string FileLocation)
        {
            ReceiptList rl = new ReceiptList();
            Document doc = new Document(iTextSharp.text.PageSize.A4, 10, 10, 42, 35);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(FileLocation+"/"+fileName+ ".pdf",FileMode.Create));
            int i,sum=0;
            doc.Open();

            iTextSharp.text.Image image = iTextSharp.text.Image.GetInstance("pic/plane.png");
            image.SetAbsolutePosition(doc.LeftMargin, wri.PageSize.GetTop(doc.TopMargin)-15f);
            image.ScaleAbsolute(40f, 40f);
            doc.Add(image);

            image = iTextSharp.text.Image.GetInstance("pic/Clients/" + Pic);
            image.SetAbsolutePosition(wri.PageSize.GetRight(doc.RightMargin)-60f, wri.PageSize.GetTop(doc.TopMargin)-15f);
            image.ScaleAbsolute(50f, 50f);
            doc.Add(image);

            image = iTextSharp.text.Image.GetInstance("pic/IT.png");
            image.ScaleAbsolute(50f, 50f);
            image.SetAbsolutePosition((PageSize.A4.Width - image.ScaledWidth) / 2, wri.PageSize.GetTop(doc.TopMargin) - 15f);
            doc.Add(image);

            Paragraph p = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, BaseColor.BLACK, Element.ALIGN_LEFT, 1)));
            doc.Add(p);

            Paragraph paragraph1 = new Paragraph("Client Data From \nClient: "+FirstName+" "+LastName + "\nPrint Time:" + DateTime.Now);
            paragraph1.Alignment = Element.ALIGN_CENTER;
            doc.Add(paragraph1);

            Font link = FontFactory.GetFont(EMail, 12, Font.UNDERLINE,BaseColor.BLUE);
            Anchor anchor = new Anchor("Email:"+EMail, link);
            doc.Add(anchor);

            Paragraph paragraph2 = new Paragraph(PrintClient);
            doc.Add(paragraph2);
            image = iTextSharp.text.Image.GetInstance(ChartLocation);
            image.ScaleAbsolute(250f, 250f);
            image.SetAbsolutePosition((PageSize.A4.Width - image.ScaledWidth) / 2, (PageSize.A4.Height - image.ScaledHeight) / 2);
            doc.Add(image);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            PdfPTable table = new PdfPTable(8);
            PdfPCell cell = new PdfPCell(new Phrase(FirstName+" "+LastName+ " paid Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Tour ID");
            table.AddCell("Tour Name");
            table.AddCell("Tour Date");
            table.AddCell("Payment");
            table.AddCell("Price");
            table.AddCell("Quantity");
            table.AddCell("Total");
            rl.BuildReceiptsByClientpaidActive(PKID);
            int counter = rl.GetReceiptsList().Count;
            for(i=0;i<counter;i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourID().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourname());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetPaymentDate().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetPrice().ToString()+"$");
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity())* (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString()+"$");
                sum += (rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString()+"$");
            doc.Add(table);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            rl.BuildReceiptsByClientUnpaidActive(PKID);
            table = new PdfPTable(8);
            cell = new PdfPCell(new Phrase(FirstName + " " + LastName + " unpaid Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Tour ID");
            table.AddCell("Tour Name");
            table.AddCell("Tour Date");
            table.AddCell("Worker Name");
            table.AddCell("Price");
            table.AddCell("Quantity");
            table.AddCell("Total");
            counter = rl.GetReceiptsList().Count;
            sum = 0;
            for (i = 0; i < counter; i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourID().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourname());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetWorker().GetFirstName()+" "+ rl.GetReceiptsList()[i].GetWorker().GetLastName());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetPrice().ToString() + "$");
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString() + "$");
                sum += (rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString() + "$");
            doc.Add(table);
            doc.NewPage();
            doc.Add(paragraph1);
            doc.Add(p);
            rl.BuildReceiptsByClientUnpaidUnActive(PKID);
            table = new PdfPTable(8);
            cell = new PdfPCell(new Phrase(FirstName + " " + LastName + " Canceled Orders list"));
            cell.Colspan = 9;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            table.AddCell(cell);
            table.AddCell("Order ID");
            table.AddCell("Tour ID");
            table.AddCell("Tour Name");
            table.AddCell("Tour Date");
            table.AddCell("Worker Name");
            table.AddCell("Price");
            table.AddCell("Quantity");
            table.AddCell("Total");
            counter = rl.GetReceiptsList().Count;
            for (i = 0; i < counter; i++)
            {
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetOrderNumber().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourID().ToString());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetTourname());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetDate());
                table.AddCell(rl.GetReceiptsList()[i].GetWorker().GetFirstName() + " " + rl.GetReceiptsList()[i].GetWorker().GetLastName());
                table.AddCell(rl.GetReceiptsList()[i].GetTour().GetPrice().ToString() + "$");
                table.AddCell(rl.GetReceiptsList()[i].GetOrder().GetQuantity().ToString());
                table.AddCell(((rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice())).ToString() + "$");
                sum += (rl.GetReceiptsList()[i].GetOrder().GetQuantity()) * (rl.GetReceiptsList()[i].GetTour().GetPrice());
            }
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell("");
            table.AddCell(sum.ToString() + "$");
            doc.Add(table);

            doc.Close();
        }
    }
}
