﻿namespace IlanTalproTCB
{
    partial class ClientMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClientMenuForm));
            this.LHeader = new System.Windows.Forms.Label();
            this.LDate = new System.Windows.Forms.Label();
            this.TDate = new System.Windows.Forms.Timer(this.components);
            this.PBExit = new System.Windows.Forms.PictureBox();
            this.PBBack = new System.Windows.Forms.PictureBox();
            this.LShowClientData = new System.Windows.Forms.Label();
            this.PBUpDataClient = new System.Windows.Forms.PictureBox();
            this.PBClientOrderTours = new System.Windows.Forms.PictureBox();
            this.PBClientPaymentOrder = new System.Windows.Forms.PictureBox();
            this.PBClientPastOrders = new System.Windows.Forms.PictureBox();
            this.LUpdateData = new System.Windows.Forms.Label();
            this.LPayOrders = new System.Windows.Forms.Label();
            this.LOrderTour = new System.Windows.Forms.Label();
            this.LOrderHistory = new System.Windows.Forms.Label();
            this.TExit = new System.Windows.Forms.Timer(this.components);
            this.TTMouseHover = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpDataClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientOrderTours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientPaymentOrder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientPastOrders)).BeginInit();
            this.SuspendLayout();
            // 
            // LHeader
            // 
            this.LHeader.AutoSize = true;
            this.LHeader.BackColor = System.Drawing.Color.Transparent;
            this.LHeader.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LHeader.ForeColor = System.Drawing.Color.Black;
            this.LHeader.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LHeader.Location = new System.Drawing.Point(12, 9);
            this.LHeader.Name = "LHeader";
            this.LHeader.Size = new System.Drawing.Size(0, 40);
            this.LHeader.TabIndex = 1;
            // 
            // LDate
            // 
            this.LDate.AutoSize = true;
            this.LDate.BackColor = System.Drawing.Color.Transparent;
            this.LDate.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDate.ForeColor = System.Drawing.Color.Black;
            this.LDate.Location = new System.Drawing.Point(1060, 9);
            this.LDate.Name = "LDate";
            this.LDate.Size = new System.Drawing.Size(54, 29);
            this.LDate.TabIndex = 7;
            this.LDate.Text = "Date";
            this.LDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // TDate
            // 
            this.TDate.Tick += new System.EventHandler(this.TDate_Tick);
            // 
            // PBExit
            // 
            this.PBExit.BackColor = System.Drawing.Color.Transparent;
            this.PBExit.Image = ((System.Drawing.Image)(resources.GetObject("PBExit.Image")));
            this.PBExit.Location = new System.Drawing.Point(12, 761);
            this.PBExit.Name = "PBExit";
            this.PBExit.Size = new System.Drawing.Size(100, 80);
            this.PBExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBExit.TabIndex = 8;
            this.PBExit.TabStop = false;
            this.PBExit.Click += new System.EventHandler(this.PBExit_Click);
            this.PBExit.MouseLeave += new System.EventHandler(this.PBExit_MouseLeave);
            this.PBExit.MouseHover += new System.EventHandler(this.PBExit_MouseHover);
            // 
            // PBBack
            // 
            this.PBBack.BackColor = System.Drawing.Color.Transparent;
            this.PBBack.Image = ((System.Drawing.Image)(resources.GetObject("PBBack.Image")));
            this.PBBack.Location = new System.Drawing.Point(1170, 761);
            this.PBBack.Name = "PBBack";
            this.PBBack.Size = new System.Drawing.Size(100, 80);
            this.PBBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBBack.TabIndex = 9;
            this.PBBack.TabStop = false;
            this.PBBack.Click += new System.EventHandler(this.PBBack_Click);
            this.PBBack.MouseLeave += new System.EventHandler(this.PBBack_MouseLeave);
            this.PBBack.MouseHover += new System.EventHandler(this.PBBack_MouseHover);
            // 
            // LShowClientData
            // 
            this.LShowClientData.AutoSize = true;
            this.LShowClientData.BackColor = System.Drawing.Color.Transparent;
            this.LShowClientData.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LShowClientData.ForeColor = System.Drawing.Color.Black;
            this.LShowClientData.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LShowClientData.Location = new System.Drawing.Point(14, 487);
            this.LShowClientData.Name = "LShowClientData";
            this.LShowClientData.Size = new System.Drawing.Size(0, 29);
            this.LShowClientData.TabIndex = 37;
            // 
            // PBUpDataClient
            // 
            this.PBUpDataClient.BackColor = System.Drawing.Color.Transparent;
            this.PBUpDataClient.Image = ((System.Drawing.Image)(resources.GetObject("PBUpDataClient.Image")));
            this.PBUpDataClient.Location = new System.Drawing.Point(19, 127);
            this.PBUpDataClient.Name = "PBUpDataClient";
            this.PBUpDataClient.Size = new System.Drawing.Size(150, 96);
            this.PBUpDataClient.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBUpDataClient.TabIndex = 76;
            this.PBUpDataClient.TabStop = false;
            this.PBUpDataClient.Click += new System.EventHandler(this.PBUpDateClient_Click);
            this.PBUpDataClient.MouseLeave += new System.EventHandler(this.PBUpDateClient_MouseLeave);
            this.PBUpDataClient.MouseHover += new System.EventHandler(this.PBUpDateClient_MouseHover);
            // 
            // PBClientOrderTours
            // 
            this.PBClientOrderTours.BackColor = System.Drawing.Color.Transparent;
            this.PBClientOrderTours.Image = ((System.Drawing.Image)(resources.GetObject("PBClientOrderTours.Image")));
            this.PBClientOrderTours.Location = new System.Drawing.Point(448, 127);
            this.PBClientOrderTours.Name = "PBClientOrderTours";
            this.PBClientOrderTours.Size = new System.Drawing.Size(150, 96);
            this.PBClientOrderTours.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBClientOrderTours.TabIndex = 77;
            this.PBClientOrderTours.TabStop = false;
            this.PBClientOrderTours.Click += new System.EventHandler(this.PBClientOrderTours_Click);
            this.PBClientOrderTours.MouseLeave += new System.EventHandler(this.PBClientOrderTours_MouseLeave);
            this.PBClientOrderTours.MouseHover += new System.EventHandler(this.PBClientOrderTours_MouseHover);
            // 
            // PBClientPaymentOrder
            // 
            this.PBClientPaymentOrder.BackColor = System.Drawing.Color.Transparent;
            this.PBClientPaymentOrder.Image = ((System.Drawing.Image)(resources.GetObject("PBClientPaymentOrder.Image")));
            this.PBClientPaymentOrder.Location = new System.Drawing.Point(19, 356);
            this.PBClientPaymentOrder.Name = "PBClientPaymentOrder";
            this.PBClientPaymentOrder.Size = new System.Drawing.Size(150, 96);
            this.PBClientPaymentOrder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBClientPaymentOrder.TabIndex = 78;
            this.PBClientPaymentOrder.TabStop = false;
            this.PBClientPaymentOrder.Click += new System.EventHandler(this.PBClientPaymentOrder_Click);
            this.PBClientPaymentOrder.MouseLeave += new System.EventHandler(this.PBClientPaymentOrder_MouseLeave);
            this.PBClientPaymentOrder.MouseHover += new System.EventHandler(this.PBClientPaymentOrder_MouseHover);
            // 
            // PBClientPastOrders
            // 
            this.PBClientPastOrders.BackColor = System.Drawing.Color.Transparent;
            this.PBClientPastOrders.Image = ((System.Drawing.Image)(resources.GetObject("PBClientPastOrders.Image")));
            this.PBClientPastOrders.Location = new System.Drawing.Point(448, 356);
            this.PBClientPastOrders.Name = "PBClientPastOrders";
            this.PBClientPastOrders.Size = new System.Drawing.Size(150, 96);
            this.PBClientPastOrders.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBClientPastOrders.TabIndex = 79;
            this.PBClientPastOrders.TabStop = false;
            this.PBClientPastOrders.Click += new System.EventHandler(this.PBClientPastOrders_Click);
            this.PBClientPastOrders.MouseLeave += new System.EventHandler(this.PBClientPastOrders_MouseLeave);
            this.PBClientPastOrders.MouseHover += new System.EventHandler(this.PBClientPastOrders_MouseHover);
            // 
            // LUpdateData
            // 
            this.LUpdateData.AutoSize = true;
            this.LUpdateData.BackColor = System.Drawing.Color.Transparent;
            this.LUpdateData.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LUpdateData.ForeColor = System.Drawing.Color.Black;
            this.LUpdateData.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LUpdateData.Location = new System.Drawing.Point(12, 69);
            this.LUpdateData.Name = "LUpdateData";
            this.LUpdateData.Size = new System.Drawing.Size(235, 40);
            this.LUpdateData.TabIndex = 80;
            this.LUpdateData.Text = "Update your data:";
            // 
            // LPayOrders
            // 
            this.LPayOrders.AutoSize = true;
            this.LPayOrders.BackColor = System.Drawing.Color.Transparent;
            this.LPayOrders.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LPayOrders.ForeColor = System.Drawing.Color.Black;
            this.LPayOrders.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LPayOrders.Location = new System.Drawing.Point(12, 274);
            this.LPayOrders.Name = "LPayOrders";
            this.LPayOrders.Size = new System.Drawing.Size(218, 40);
            this.LPayOrders.TabIndex = 81;
            this.LPayOrders.Text = "Pay your orders:";
            // 
            // LOrderTour
            // 
            this.LOrderTour.AutoSize = true;
            this.LOrderTour.BackColor = System.Drawing.Color.Transparent;
            this.LOrderTour.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOrderTour.ForeColor = System.Drawing.Color.Black;
            this.LOrderTour.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LOrderTour.Location = new System.Drawing.Point(441, 69);
            this.LOrderTour.Name = "LOrderTour";
            this.LOrderTour.Size = new System.Drawing.Size(163, 40);
            this.LOrderTour.TabIndex = 82;
            this.LOrderTour.Text = "Order tours:";
            // 
            // LOrderHistory
            // 
            this.LOrderHistory.AutoSize = true;
            this.LOrderHistory.BackColor = System.Drawing.Color.Transparent;
            this.LOrderHistory.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOrderHistory.ForeColor = System.Drawing.Color.Black;
            this.LOrderHistory.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.LOrderHistory.Location = new System.Drawing.Point(441, 274);
            this.LOrderHistory.Name = "LOrderHistory";
            this.LOrderHistory.Size = new System.Drawing.Size(202, 40);
            this.LOrderHistory.TabIndex = 83;
            this.LOrderHistory.Text = "Orders History:";
            // 
            // TExit
            // 
            this.TExit.Tick += new System.EventHandler(this.TExit_Tick);
            // 
            // TTMouseHover
            // 
            this.TTMouseHover.Draw += new System.Windows.Forms.DrawToolTipEventHandler(this.TTMouseHover_Draw);
            // 
            // ClientMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1282, 853);
            this.Controls.Add(this.LOrderHistory);
            this.Controls.Add(this.LOrderTour);
            this.Controls.Add(this.LPayOrders);
            this.Controls.Add(this.LUpdateData);
            this.Controls.Add(this.PBClientPastOrders);
            this.Controls.Add(this.PBClientPaymentOrder);
            this.Controls.Add(this.PBClientOrderTours);
            this.Controls.Add(this.PBUpDataClient);
            this.Controls.Add(this.LShowClientData);
            this.Controls.Add(this.PBBack);
            this.Controls.Add(this.PBExit);
            this.Controls.Add(this.LDate);
            this.Controls.Add(this.LHeader);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ClientMenuForm";
            this.Text = "Client menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddClientForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.PBExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBUpDataClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientOrderTours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientPaymentOrder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBClientPastOrders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LHeader;
        private System.Windows.Forms.Label LDate;
        private System.Windows.Forms.Timer TDate;
        private System.Windows.Forms.PictureBox PBExit;
        private System.Windows.Forms.PictureBox PBBack;
        private System.Windows.Forms.Label LShowClientData;
        private System.Windows.Forms.PictureBox PBUpDataClient;
        private System.Windows.Forms.PictureBox PBClientOrderTours;
        private System.Windows.Forms.PictureBox PBClientPaymentOrder;
        private System.Windows.Forms.PictureBox PBClientPastOrders;
        private System.Windows.Forms.Label LUpdateData;
        private System.Windows.Forms.Label LPayOrders;
        private System.Windows.Forms.Label LOrderTour;
        private System.Windows.Forms.Label LOrderHistory;
        private System.Windows.Forms.Timer TExit;
        private System.Windows.Forms.ToolTip TTMouseHover;
    }
}