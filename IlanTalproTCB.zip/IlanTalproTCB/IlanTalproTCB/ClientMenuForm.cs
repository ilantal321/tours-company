﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    /*
    this is clients menu he can go to all of his forms
    update data, order tour, payments, orders history
    */
    public partial class ClientMenuForm : Form
    {
        Function f1 = new Function();
        Client c = new Client(LoginForm.PKID.ToString());
        ReceiptList rl = new ReceiptList();
        public ClientMenuForm()
        {
            try
            {
                this.BackgroundImage = Properties.Resources.background;
                InitializeComponent();
                TDate.Start();
                rl.BuildReceiptsByClientUnpaidActive(LoginForm.PKID);
                if (rl.GetReceiptsList().Count != 0)//client get massege on orders that he didnt pay
                {
                    LShowClientData.Text = rl.PrintReceiptsData();
                }
                LHeader.Text = "Welcome " + c.GetFirstName() + " " + c.GetLastName() + " to I.T travel company";
                TTMouseHover.OwnerDraw = true;
                TTMouseHover.ForeColor = Color.Black;
                TTMouseHover.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERROR");
            }
        }
        /*
        date timer
        */
        private void TDate_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            LDate.Text = time.ToString("dd-MM-yyyy HH:mm:ss");
        }
        /*
        exit with fade timer
        */
        private void PBExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                TExit.Start();
            }
        }
        private void AddClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to exit", "EXIT", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                e.Cancel = true;
                TExit.Start();
            }
            else if (confirm == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        /*
         
        */ 
        private void PBExit_MouseHover(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Exit", PBExit);
        }
        private void PBExit_MouseLeave(object sender, EventArgs e)
        {
            PBExit.BackColor = Color.Transparent;
        }

        private void PBBack_MouseHover(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Back", PBBack);
        }
        private void PBBack_MouseLeave(object sender, EventArgs e)
        {
            PBBack.BackColor = Color.Transparent;
        }

        private void PBUpDateClient_MouseHover(object sender, EventArgs e)
        {
            PBUpDataClient.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Update your data", PBUpDataClient);
        }
        private void PBUpDateClient_MouseLeave(object sender, EventArgs e)
        {
            PBUpDataClient.BackColor = Color.Transparent;
        }

        private void PBClientOrderTours_MouseHover(object sender, EventArgs e)
        {
            PBClientOrderTours.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Order tour", PBClientOrderTours);
        }
        private void PBClientOrderTours_MouseLeave(object sender, EventArgs e)
        {
            PBClientOrderTours.BackColor = Color.Transparent;
        }

        private void PBClientPaymentOrder_MouseHover(object sender, EventArgs e)
        {
            PBClientPaymentOrder.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Orders Payment", PBClientPaymentOrder);
        }
        private void PBClientPaymentOrder_MouseLeave(object sender, EventArgs e)
        {
            PBClientPaymentOrder.BackColor = Color.Transparent;
        }

        private void PBClientPastOrders_MouseHover(object sender, EventArgs e)
        {
            PBClientPastOrders.BackColor = Color.WhiteSmoke;
            TTMouseHover.Show("Orders history", PBClientPastOrders);
        }
        private void PBClientPastOrders_MouseLeave(object sender, EventArgs e)
        {
            PBClientPastOrders.BackColor = Color.Transparent;
        }
        /*
        go to the forms 
        */
        private void PBBack_Click(object sender, EventArgs e)
        {

            var LoginForm = new LoginForm();
            LoginForm.Closed += (s, args) => this.Close();
            LoginForm.Show();
            this.Hide();
        }
        private void PBUpDateClient_Click(object sender, EventArgs e)
        {
            var UpdateClientForm = new UpdateClientForm();
            UpdateClientForm.Closed += (s, args) => this.Close();
            UpdateClientForm.Show();
            this.Hide();
        }
        private void PBClientOrderTours_Click(object sender, EventArgs e)
        {
            var OrderTour = new ClientOrderTourForm();
            OrderTour.Closed += (s, args) => this.Close();
            OrderTour.Show();
            this.Hide();
        }
        private void PBClientPaymentOrder_Click(object sender, EventArgs e)
        {
            var ClientUnpaidOrders = new ClientUnpaidOrders();
            ClientUnpaidOrders.Closed += (s, args) => this.Close();
            ClientUnpaidOrders.Show();
            this.Hide();
        }
        private void PBClientPastOrders_Click(object sender, EventArgs e)
        {
            var ClientOrdersForm = new ClientOrdersForm();
            ClientOrdersForm.Closed += (s, args) => this.Close();
            ClientOrdersForm.Show();
            this.Hide();
        }
        /*
        fade timer
        */
        private void TExit_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.075;
            }
            else
            {
                TExit.Stop();
                Application.ExitThread();
            }
        }
        /*
        tool tip drow background
        */
        private void TTMouseHover_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }
    }
}
