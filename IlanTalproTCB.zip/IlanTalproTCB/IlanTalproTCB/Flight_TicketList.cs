﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
namespace IlanTalproTCB
{
    class Flight_TicketList
    {
        public List<Flight_Ticket> Flight_Tickets = new List<Flight_Ticket>();
        /*
        empty constractor
        */
        public Flight_TicketList()
        {
        }
        /*
        get and set
        */
        public List<Flight_Ticket> GetFlightTicketList()
        {
            return Flight_Tickets;
        }
        public void SetFlightTicketList(List<Flight_Ticket> ft)
        {
            Flight_Tickets = ft;
        }
        /*
        constractor by tour id
        */
        public void Flight_TicketListByTourID(int TourID)
        {
            Flight_Tickets.Clear();
            Flight_Ticket FT = new Flight_Ticket();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Flight_Ticket where TourID= " + TourID + "and OrderID= 0 ORDER BY PKID;");
            while (dr.Read())
            {
                FT = new Flight_Ticket(int.Parse(dr["PKID"].ToString()), int.Parse(dr["OrderID"].ToString()), dr["Seat"].ToString(), int.Parse(dr["TourID"].ToString()));
                Flight_Tickets.Add(FT);
            }
            dr.Close();
            connec.closeCon();
        }
        /*
        constractor by tour id and order id
        */
        public void Flight_TicketTakenListByTourID(int TourID,int OrderID)
        {
            Flight_Tickets.Clear();
            Flight_Ticket FT = new Flight_Ticket();
            Myconn connec = new Myconn();
            OleDbDataReader dr = connec.SandQuery("Select * from Flight_Ticket where TourID= " + TourID + "and OrderID= "+OrderID+" ORDER BY PKID;");
            while (dr.Read())
            {
                FT = new Flight_Ticket(int.Parse(dr["PKID"].ToString()), int.Parse(dr["OrderID"].ToString()), dr["Seat"].ToString(), int.Parse(dr["TourID"].ToString()));
                Flight_Tickets.Add(FT);
            }
            dr.Close();
            connec.closeCon();
        }
    }
}
