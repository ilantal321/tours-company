﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
namespace IlanTalproTCB
{
    class sha1ceypto
    {
        SHA1CryptoServiceProvider sh = new SHA1CryptoServiceProvider();
        /*
        empty constractor
        */
        public sha1ceypto()
        {
        }
        /*
        encode to sha1
        */
        public string GetSHA1(string str)
        {
            SHA1CryptoServiceProvider sh = new SHA1CryptoServiceProvider();
            sh.ComputeHash(ASCIIEncoding.ASCII.GetBytes(str));
            byte[] re = sh.Hash;
            StringBuilder sb = new StringBuilder();
            foreach (byte b in re)
            {
                sb.Append(b.ToString("X2"));
            }
            return sb.ToString();
        }
    }
}
